<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller
{
    function __construct()
	{
		parent::__construct();
        //error_reporting(0);
        //load api
		$this->load->model('m_apipass');
		
    }

    public function index()
    {

        echo "something wrong ya";
        
    }

    ### Login User
	public function loginuser()
	{
		header("Access-Control-Allow-Origin: *");
		header("Content-Type: application/json; charset=UTF-8");
		http_response_code(200);
		
        $username = $this->input->post('username');
        $password = $this->input->post('password');
		if($username == "" || $password == "") {
			echo json_encode( 
				array(
				)
			 ) ;
		}
		else {

			$result = $this->m_apipass->loginuser($username, $password);
			if($result){
				echo json_encode($result);
				// $resultData = array('status' => true, 'message' => 'Login Berhasil');
			} else {
				// $resultData = array('status' => false, 'message' => 'Login Gagal');
				// echo json_encode($resultData);
				echo json_encode( 
				array(
				)
			) ;   
			}
		}
    }
    
    ### Login User Officer
	public function loginofficer()
	{
		header("Access-Control-Allow-Origin: *");
		header("Content-Type: application/json; charset=UTF-8");
		http_response_code(200);
		
        $username = $this->input->post('username');
        $password = $this->input->post('password');
		if($username == "" || $password == "") {
			echo json_encode( 
				array(
				)
			 ) ;
		}
		else {

			$result = $this->m_apipass->loginofficer($username, $password);
			if($result){
				echo json_encode($result);
				// $resultData = array('status' => true, 'message' => 'Login Berhasil');
			} else {
				// $resultData = array('status' => false, 'message' => 'Login Gagal');
				// echo json_encode($resultData);
				echo json_encode( 
				array(
				)
			) ;   
			}
		}
    }
    
    ## INPUT DATA
	public function input_pass(){
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        http_response_code(200);
		
		$data['user_id'] = $this->input->post('user_id');
		$data['createdate'] = date("Y-m-d h:i:s");
        $data['destination'] = $this->input->post('destination');
        $data['purpose'] = $this->input->post('purpose');
        $data['gate_id'] = $this->input->post('gate_id');
		$data['officer_id'] = $this->input->post('officer_id');
		
		$result = $this->m_apipass->input_pass($data);
		
		// if($result){
			$resultData[] = array('status'=> TRUE,
								  'message'=> 'Input Data Berhasil'
								  );
			echo json_encode($resultData, JSON_PRETTY_PRINT);
		// } else {
				
			// $resultData[] = array('status'=> FALSE,
								  // 'message'=> 'Input Notifikasi Tidak Berhasil'
								  // );
			// echo json_encode($resultData, JSON_PRETTY_PRINT);
		// }
		
    }
    
    ##GET DATA BY QRCODE
    public function getByQRcode(){
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        http_response_code(200);
		
        $data=array('usercode'	=>	$this->input->get('usercode'));
					  
		$result = $this->m_apipass->getByQRcode($data['usercode']);
		if($result){
			echo json_encode($result);
		} else {
			
			 echo json_encode( 
			 array(
			 )
		  ) ;   
		}
      
    }
    
    ##GET DATA BY NIK
    public function getByNIK(){
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        http_response_code(200);
		
        $data=array('nik'	=>	$this->input->get('nik'));
					  
		$result = $this->m_apipass->getByNIK($data['nik']);
		if($result){
			echo json_encode($result);
		} else {
			
			 echo json_encode( 
			 array(
			 )
		  ) ;   
		}
      
    }
    
    ##GET DATA PASS USER
    public function getPassByUser(){
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        http_response_code(200);
		
        $data=array('nik'	=>	$this->input->get('nik'));
					  
		$result = $this->m_apipass->getPassByUser($data['nik']);
		if($result){
			echo json_encode($result);
		} else {
			
			 echo json_encode( 
			 array(
			 )
		  ) ;   
		}
      
	}

    ##GET DATA PASS OFFICER
    public function getPassByOfficer(){
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        http_response_code(200);
		
        $data=array('officer_id'	=>	$this->input->get('officer_id'));
					  
		$result = $this->m_apipass->getPassByOfficer($data['officer_id']);
		if($result){
			echo json_encode($result);
		} else {
			
			 echo json_encode( 
			 array(
			 )
		  ) ;   
		}
      
    }
    
    ##GET DATA PASS OFFICER
    public function getPassByOfficerDate(){
        header("Access-Control-Allow-Origin: *");
        header("Content-Type: application/json; charset=UTF-8");
        http_response_code(200);
		
        $data=array('officer_id'	=>	$this->input->get('officer_id'));
        $data=array('createdate'	=>	$this->input->get('createdate'));
					  
		$result = $this->m_apipass->getPassByOfficerDate($data['officer_id'], $data['createdate']);
		if($result){
			echo json_encode($result);
		} else {
			
			 echo json_encode( 
			 array(
			 )
		  ) ;   
		}
      
	}


}
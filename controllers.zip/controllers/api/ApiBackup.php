<?php

date_default_timezone_set("Asia/Makassar");
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller {
  function __construct() {
    parent:: __construct();
    $this->load->model('m_api');
  }

  public function index() {
    echo "something wrong ya";
  }

  public function loginuser() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

    $username = $this->input->post('username');
    $password = md5($this->input->post('password'));
    if ($username == "" || $password == "") {
      echo json_encode(array());
    } else {

      $result = $this->m_api->loginuser($username, $password);
      if ($result) {
        echo json_encode($result);
      } else {
        echo json_encode(array());
      }
    }
  }

  public function loginofficer() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

    $username = $this->input->post('username');
    $password = md5($this->input->post('password'));
    if ($username == "" || $password == "") {
      echo json_encode(array());
    } else {

      $result = $this->m_api->loginofficer($username, $password);
      if ($result) {
        echo json_encode($result);
      } else {
        echo json_encode(array());
      }
    }
  }

  /* ABSEN PAGI WFO */
  public function absence_pagi() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

    $nip     = $this->input->post('nip');
    $kd_skpd = $this->input->post('kd_skpd');

    $result = $this->m_api->wasAbsenced_pagi($nip, date('Y-m-d'));

    if ($result) {
      echo json_encode(array("message" => "Anda Sudah Pernah Absen"));
    } else {
      //get today
      $today1 = date('Y-m-d');

      //get datetime when absence
      $today2       = date('Y-m-d');
      $time         = date("H:i:s");
      $timecomplete = date("Y-m-d H:i:s");

      $masukawal      = "07:00:00";
      $masukakhir     = "08:30:00";
      $terlambatawal  = "08:30:01";
      $terlambatakhir = "09:00:00";

      if ($today1 == $today2) {
        if ($time >= $masukawal && $time <= $masukakhir) {
          //hadir[1]
          $status = 1;
        } else if ($time > $terlambatawal && $time <= $terlambatakhir) {
          //terlambat[2]
          $status = 2;
        } else {
          //alpha[3] - [perintah BKPSDM untuk diubah jadi terlambat]
          $status = 2;
        }
      }

      $data = array('nip' => $nip,
        'kd_skpd'        => $kd_skpd,
        'checkin_status' => $status,
        'checkin_time'   => $timecomplete,
        'today'          => $today1,
      );


      $validasiSKPD = $this->m_api->getByNIP($nip);



      //INPUT TO ABSENSI TBL
      $x = $this->m_api->cekDouble($nip , $today1); 
      if($x){
        //echo $g->nip." - Sudah Ada<br>";
      }else{
        
        $hari    = $this->getDay($today1);

        if($hari == 'Sabtu' OR $hari == 'Minggu'){
          $status_hari  = 'Extra Day';
        }else{
          $status_hari  = 'Work Day';
        }

        $dataxx['absensi_id']       = "";
        $dataxx['absensi_tanggal']  = $today1;
        $dataxx['nip']              = $nip;
        $dataxx['kd_skpd']          = $kd_skpd;
        $dataxx['jam_masuk']        = $time;
        $dataxx['status_berkantor'] = 1;
        $dataxx['status_kehadiran'] = 0;
        $dataxx['hari']             = $hari;
        $dataxx['status_hari']      = $status_hari;

        $this->m_api->input($dataxx);

      }

      if($validasiSKPD[0]['kd_skpd'] == $kd_skpd){
        $result = $this->m_api->absence_pagi($data);
        echo json_encode(
          array("message" => "Absen Berhasil",
          )
        );
      }else{
        
        echo json_encode(
          array("message" => "Maaf, Pegawai yang anda Scan bukan berasal dari SKPD anda!!!",
          )
        );
      }

      
    }
  }

  /* ABSEN PAGI WFH */
  public function absence_pagi_wfh() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

    $nip     = $this->input->post('nip');
    $kd_skpd = $this->input->post('kd_skpd');
    $kondisi = $this->input->post('kondisi');

    //cek lokasinya dulu apakah di dalam lingkarannya
    $getlocation     = $this->m_api->fetchdata($this->input->post('nip'));
    $mylocation      = $getlocation[0]->coordinate;
    $currentlocation = $this->input->post('lokasi');

    $pecah_mylocation      = explode(',', $mylocation);
    $pecah_currentlocation = explode(',', $currentlocation);

    $cek    = $this->hitungJarak($pecah_mylocation[0], $pecah_mylocation[1], $pecah_currentlocation[0], $pecah_currentlocation[1]);
    $radius = ($cek * 1000);

    if ($radius > 20) {

      $data['nip']                = $this->input->post('nip');
      $data['coordinate_history'] = $this->input->post('lokasi');
      $data['today']              = date('Y-m-d');
      $data['createdate']         = date('Y-m-d H:i:s');
      $this->m_api->addHistoryCoordinate($data);

      /*  */
      $resultData = array(
        'respon_code' => 'RC200',
        'status'      => true,
        'message'     => 'Anda Berada di luar zona WFH anda (radius 20 Meter). Segera Kembali ke Titik WFH Anda',
        'data'        => array(
          'mylocation'      => $mylocation,
          'currentlocation' => $currentlocation,
          'distance'        => $radius . " Meter",
        ),
      );

      echo json_encode(
        $resultData
      );

    } else {

      //absen
      //check kalo sudah absen ato belum
      $result = $this->m_api->wasAbsenced_pagi($nip,
        date('Y-m-d'));
      if ($result) {
        echo json_encode(
          array("message" => "Anda Sudah Pernah Absen",
          )
        );
      } else {
        //get today
        $today1 = date('Y-m-d');
        //get datetime when absence
        $today2       = date('Y-m-d');
        $time         = date("H:i:s");
        $timecomplete = date("Y-m-d H:i:s");
        //$time = "07:40:00";

        $masukawal      = "07:00:00";
        $masukakhir     = "08:30:00";
        $terlambatawal  = "08:30:01";
        $terlambatakhir = "09:00:00";

        if ($today1 == $today2) {
          if ($time >= $masukawal && $time <= $masukakhir) {
            //hadir
            $status = 1;
          } else if ($time > $terlambatawal && $time <= $terlambatakhir) {
            //terlambat
            $status = 2;
          } else {
            //alpha[3] - [perintah BKPSDM untuk diubah jadi terlambat]
            $status = 2;
          }
        }

        $data = array(
          'nip'            => $nip,
          'kd_skpd'        => $kd_skpd,
          'checkin_status' => $status,
          'checkin_time'   => $timecomplete,
          'sick_status'    => $kondisi,
          'today'          => $today1);


        //INPUT TO ABSENSI TBL
        $x = $this->m_api->cekDouble($nip , $today1); 
        if($x){
          //echo $g->nip." - Sudah Ada<br>";
        }else{
          
          $hari    = $this->getDay($today1);

          if($hari == 'Sabtu' OR $hari == 'Minggu'){
            $status_hari  = 'Extra Day';
          }else{
            $status_hari  = 'Work Day';
          }

          $dataxx['absensi_id']       = "";
          $dataxx['absensi_tanggal']  = $today1;
          $dataxx['nip']              = $nip;
          $dataxx['kd_skpd']          = $kd_skpd;
          $dataxx['jam_masuk']        = $time;
          $dataxx['status_berkantor'] = 2;
          $dataxx['status_kehadiran'] = 0;
          $dataxx['hari']             = $hari;
          $dataxx['status_hari']      = $status_hari;

          $this->m_api->input($dataxx);

        }


        $result = $this->m_api->absence_pagi($data);
        echo json_encode(
          array("message" => "Absen Berhasil",
          )
        );
      }

    }

  }

  /* ABSEN PAGI WFH */
  public function inputabsenlapangan() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

    $data['nip']               = $this->input->post('nip');
    $data['kd_skpd']           = $this->input->post('kd_skpd');
    $data['checkin_time']      = date("Y-m-d H:i:s");
    $data['today']             = date("Y-m-d");
    $data['status_verifikasi'] = 0;

    $today1 = date('Y-m-d');
    //get datetime when absence
    $today2 = date('Y-m-d');
    $time   = date("H:i:s");
    //$time = "07:40:00";

    $masukawal      = "07:00:00";
    $masukakhir     = "08:30:00";
    $terlambatawal  = "08:30:01";
    $terlambatakhir = "09:00:00";

    if ($today1 == $today2) {
      if ($data['checkin_time'] >= $masukawal && $data['checkin_time'] <= $masukakhir) {
        //hadir
        $data['checkin_status'] = 1;
      } else if ($data['checkin_time'] > $terlambatawal && $data['checkin_time'] <= $terlambatakhir) {
        //terlambat
        $data['checkin_status'] = 2;
      } else {
        //alpha[3] - [perintah BKPSDM untuk diubah jadi terlambat]
        $data['checkin_status'] = 2;
      }
    }



    $checkAbsencelap = $this->m_api->wasAbsenced_pagi_lapangan($data['nip'],$data['today']);

    if($checkAbsencelap){
      //Jika sudah absen
      $resultData[] = array('status' => TRUE,
        'message' => 'ANDA SUDAH ABSEN PAGI INI',
        'photo'   => '',
      );
    }else{


      //INPUT TO ABSENSI TBL
      $x = $this->m_api->cekDouble($data['nip'] , $today1); 
      if($x){
        //echo $g->nip." - Sudah Ada<br>";
      }else{
        
        $hari    = $this->getDay($today1);

        if($hari == 'Sabtu' OR $hari == 'Minggu'){
          $status_hari  = 'Extra Day';
        }else{
          $status_hari  = 'Work Day';
        }

        $dataxx['absensi_id']       = "";
        $dataxx['absensi_tanggal']  = $today1;
        $dataxx['nip']              = $data['nip'];
        $dataxx['kd_skpd']          = $data['kd_skpd'];
        $dataxx['jam_masuk']        = $time;
        $dataxx['status_berkantor'] = 3;
        $dataxx['status_kehadiran'] = 0;
        $dataxx['hari']             = $hari;
        $dataxx['status_hari']      = $status_hari;

        $this->m_api->input($dataxx);

      }


      //jika belum absen
      if ($this->input->post('image') == "") {
        $filename = '';
      } else {
        $gambar       = base64_decode($this->input->post('image'));
        $name         = $this->input->post('name');
        $getExtention = explode(".", $name);
        $filename     = "pic-" . $data['nip'] . "-" . date('YmdHis') . rand(1000, 99999) . "." . $getExtention[1];
        $path         = './upload/pegawai/foto_lapangan/';
  
        file_put_contents($path . $filename, $gambar);
        $data['foto_lapangan'] = $filename;
      }
  
      $this->m_api->inputabsenlapangan($data);
      $resultData[] = array('status' => TRUE,
        'message' => 'TAMBAH DATA BERHASIL',
        'photo'   => $filename,
      );

    }

    echo json_encode($resultData, JSON_PRETTY_PRINT);

  }

  ##GET DATA PASS OFFICER
  public function getAbsenLapangan() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

    $kd_skpd = $this->input->get('kd_skpd');
    $today   = $this->input->get('today');

    $result = $this->m_api->getAbsenLapangan($kd_skpd, $today);
    if ($result) {
      echo json_encode($result);
    } else {

      echo json_encode(
        array(
        )
      );
    }

  }

  public function jarakWFH() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

    //get data
    $nip     = $this->input->post('nip');
    $kd_skpd = $this->input->post('kd_skpd');

    //cek lokasinya dulu apakah di dalam lingkarannya
    $getlocation = $this->m_api->fetchdata($this->input->post('nip'));

    $mylocation      = $getlocation[0]->coordinate;
    $currentlocation = $this->input->post('lokasi');

    $pecah_mylocation      = explode(',', $mylocation);
    $pecah_currentlocation = explode(',', $currentlocation);

    $cek    = $this->hitungJarak($pecah_mylocation[0], $pecah_mylocation[1], $pecah_currentlocation[0], $pecah_currentlocation[1]);
    $radius = ($cek * 1000);

    if ($radius > 20) {

      $data['nip']                = $this->input->post('nip');
      $data['coordinate_history'] = $this->input->post('lokasi');
      $data['today']              = date('Y-m-d');
      $data['createdate']         = date('Y-m-d H:i:s');
      $this->m_api->addHistoryCoordinate($data);

      /*  */
      $resultData = array(
        'respon_code' => 'RC200',
        'status'      => true,
        'message'     => 'Anda Berada di luar zona WFH anda (radius 20 Meter). Segera Kembali ke Titik WFH Anda',
        'data'        => array(
          'mylocation'      => $mylocation,
          'currentlocation' => $currentlocation,
          'distance'        => $radius . " Meter",
        ),
      );

      echo json_encode(
        $resultData
      );

      /* Kirim Pesan */
      $msg = array
        (
        'body'  => 'Anda melanggar jarak WFH (20 Meter), segera kembali ke titik WFH anda',
        'title' => 'PERINGATAN',
      );

      $server_key = 'AAAAwPv5Y0w:APA91bHxxALvm3bHttNknPeb9ItQ-hD0Zxb2Q46sfRhMNn_WvKLmFh5x3rEhxVCgZ4fbMwUvP_ISrYOmMReLbl-deZ59FHw2M1zRIZmbi92TCd9VILfapVXHvgN1U6GmmIfgHV4Bndhx';

              $url            = 'https://fcm.googleapis.com/fcm/send';
      $fields['to']           = '/topics/' . $data['nip'];
      $fields['notification'] = $msg;
              $headers        = array(
        'Content-Type:application/json',
        'Authorization:key=' . $server_key,
      );

      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_POST, true);
      curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
      curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
      $result = curl_exec($ch);
      curl_close($ch);
      var_dump($result);
      exit;

    }
  }

  ## INPUT DATA
  public function absence_sore() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

    //get data
    $nip     = $this->input->post('nip');
    $kd_skpd = $this->input->post('kd_skpd');

    //check kalo sudah absen ato belum
    $result = $this->m_api->wasAbsenced_sore($nip,
      date('Y-m-d'));
    if ($result) {
      echo json_encode(
        array("message" => "Anda Sudah Pernah Absen",
        )
      );
    } else {
      //get today
      $today1 = date('Y-m-d');
      //get datetime when absence
      $today2       = date('Y-m-d');
      $time         = date("H:i:s");
      $timecomplete = date("Y-m-d H:i:s");
      //$time = "07:40:00";

      $masukawal      = "15:00:00";
      $masukakhir     = "17:00:00";
      $terlambatawal  = "17:00:01";
      $terlambatakhir = "23:59:59";

      if ($today1 == $today2) {
        if ($time < $masukawal) {
          //pulang cepat//larikan absen
          $status = 3;
        }elseif ($time >= $masukawal && $time <= $masukakhir) {
          //pulang tepat waktu
          $status = 1;
        } else {
          //tidak absen pulang
          $status = 2;
        }
      }

      $data = array('nip' => $nip,
        'kd_skpd'        => $kd_skpd,
        'checkin_status' => $status,
        'checkin_time'   => $timecomplete,
        'today'          => $today1);


      $validasiSKPD = $this->m_api->getByNIP($nip);
      

      // UPDATE JAM PULANG ABSENSI
      $dataxx['absensi_tanggal']  = $today1;
      $dataxx['nip']              = $nip;
      $dataxx['jam_pulang']       = $time;

      $this->m_api->edit($dataxx);

      // END UPDATE JAM PULANG ABSENSI

      if($validasiSKPD[0]['kd_skpd'] == $kd_skpd){
        $result = $this->m_api->absence_sore($data);
        echo json_encode(
          array("message" => "Absen Berhasil",
          )
        );
      }else{
        echo json_encode(
          array("message" => "Maaf, Pegawai yang anda Scan bukan berasal dari SKPD anda!!!",
          )
        );
      }
    }
  }

  public function wasAbsenced_pagi() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

    $data = array('nip' => $this->input->post('nip'),
      'date'              => $this->input->post('date'));

    $result = $this->m_api->wasAbsenced_pagi($data['nip'], $data['date']);
    if ($result) {
      echo json_encode($result);
      // $resultData = array('status' => true, 'message' => 'Login Berhasil');
    } else {
      // $resultData = array('status' => false, 'message' => 'Login Gagal');
      // echo json_encode($resultData);
      echo json_encode(
        array(
        )
      );
    }

  }

  public function wasAbsenced_sore() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

    $data = array('nip' => $this->input->post('nip'),
      'date'              => $this->input->post('date'));

    $result = $this->m_api->wasAbsenced_sore($data['nip'], $data['date']);
    if ($result) {
      echo json_encode($result);
      // $resultData = array('status' => true, 'message' => 'Login Berhasil');
    } else {
      // $resultData = array('status' => false, 'message' => 'Login Gagal');
      // echo json_encode($resultData);
      echo json_encode(
        array(
        )
      );
    }

  }

  ##GET DATA BY QRCODE
  public function getByQRcode() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

    $data = array('nip' => $this->input->get('nip'));

    $result = $this->m_api->getByQRcode($data['nip']);
    if ($result) {
      echo json_encode($result);
    } else {

      echo json_encode(
        array(
        )
      );
    }

  }

  ##GET DATA BY nip
  public function getByNIP() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

    $data = array('nip' => $this->input->get('nip'));

    $result = $this->m_api->getByNIP($data['nip']);
    if ($result) {
      echo json_encode($result);
    } else {

      echo json_encode(
        array(
        )
      );
    }
  }

  ##GET DATA PASS USER
  public function getPassByUser() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

    $data = array('nip' => $this->input->get('nip'));

    $pagi = $this->m_api->getPassByUser($data['nip']);
    $sore = $this->m_api->getPassByUserSore($data['nip']);
    /* $result = $this->m_api->getPassByUser($data['nip']); */
    $result = array(
      'pagi' => $pagi,
      'sore' => $sore,
    );
    if ($result) {
      echo json_encode($result, JSON_PRETTY_PRINT);
    } else {

      echo json_encode(
        array(
        )
      );
    }

  }

  ##GET DATA PASS OFFICER
  public function getPassBySKPD() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

    $data = array('kd_skpd' => $this->input->get('kd_skpd'));


    $today = $this->input->get('today');
    $nama  = $this->input->get('nama');
    /* $result = $this->m_api->getPassBySKPD($data['kd_skpd']); */
    $pagi   = $this->m_api->getPassBySKPD($data['kd_skpd'], $today, $nama);
    $sore   = $this->m_api->getPassBySKPDsore($data['kd_skpd'], $today, $nama);
    $result = array(
      'pagi' => $pagi,
      'sore' => $sore,
    );
    if ($result) {
      echo json_encode($result, JSON_PRETTY_PRINT);
    } else {

      echo json_encode(
        array(
        )
      );
    }

  }

  ##GET DATA PASS OFFICER
  public function getPassByOfficerDate() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

    $kd_skpd = $this->input->get('kd_skpd');
    $today   = $this->input->get('today');

    $result = $this->m_api->getPassByOfficerDate($kd_skpd, $today);
    if ($result) {
      echo json_encode($result);
    } else {

      echo json_encode(
        array(
        )
      );
    }

  }

  ## UPDATE PROFILE USER
  public function updateprofiluser() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

    $nip = $this->input->post('nip');

    //$data['username'] = $this->input->post('username');
    if ($this->input->post('password') == "") {

    } else {
      $data['password'] = md5($this->input->post("password"));
    }

    if ($this->input->post('image') == "") {
      $filename = '';
    } else {
      $gambar       = base64_decode($this->input->post('image'));
      $name         = $this->input->post('name');
      $getExtention = explode(".", $name);
      $filename     = $nip . "." . $getExtention[1];
      $path         = './upload/pegawai/';
      //hapus foto lama
      unlink("./upload/pegawai/" . $this->input->post('old_image'));
      //upload foto baru
      file_put_contents($path . $filename, $gambar);
      $datap['picture'] = $filename;

      $this->m_api->updateprofilphoto($datap, $nip);

    }

    $this->m_api->updateprofiluser($data, $nip);
    $resultData[] = array('status' => TRUE,
      'message' => 'UBAH DATA BERHASIL',
      'photo'   => $filename,
    );
    echo json_encode($resultData, JSON_PRETTY_PRINT);

  }

  ## UPDATE PROFILE OFFICER
  public function updateprofilofficer() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

    $nip = $this->input->post('nip');
    //$data['username'] = $this->input->post('username');

    if ($this->input->post('image') == "") {
      $filename = '';
    } else {
      $gambar       = base64_decode($this->input->post('image'));
      $name         = $this->input->post('name');
      $getExtention = explode(".", $name);
      $filename     = $nip . "." . $getExtention[1];
      $path         = './upload/pegawai/';
      //hapus foto lama
      unlink("./upload/pegawai/" . $this->input->post('old_image'));
      //upload foto baru
      file_put_contents($path . $filename, $gambar);
      $data['photo'] = $filename;
    }

    if ($this->input->post('password') == "") {

    } else {
      $data['password'] = md5($this->input->post("password"));
    }

    $this->m_api->updateprofilofficer($data, $nip);
    $resultData[] = array('status' => TRUE,
      'message' => 'UBAH DATA BERHASIL',
      'photo'   => $filename,
    );
    echo json_encode($resultData, JSON_PRETTY_PRINT);

  }

  ## UPDATE COORDINATE
  public function updatecoordinate() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

          $nip          = $this->input->post('nip');
    $data['coordinate'] = $this->input->post('coordinate');

    $this->m_api->updatecoordinate($data, $nip);
    $resultData[] = array('status' => TRUE,
      'message'    => 'UBAH DATA BERHASIL',
      'coordinate' => $data['coordinate']);
    echo json_encode($resultData, JSON_PRETTY_PRINT);

  }

  ## UPDATE LAPANGAN
  public function updateabsenlapanganyes() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

    $nip   = $this->input->post('nip');
    $today = $this->input->post('today');

    $data['status_verifikasi'] = 1;
    $data['verifikasi_time']   = date("Y-m-d H:i:s");

    $this->m_api->updateabsenlapangan($data, $nip, $today);
    /* $resultData[] = array('status' => TRUE,
    'message'                      => 'UBAH DATA BERHASIL');
    echo json_encode($resultData, JSON_PRETTY_PRINT); */

    //input data absen
    $checkin_time = $this->input->post('checkin_time');
    //get data
    $kd_skpd = $this->input->post('kd_skpd');

    //check kalo sudah absen ato belum
    $result = $this->m_api->wasAbsenced_pagi($nip,
      date('Y-m-d'));
    if ($result) {
      /* echo json_encode(
      array("message" => "Anda Sudah Pernah Absen",
      )
      ); */
      $resultData[] = array('status' => TRUE,
        'message'                      => 'Anda Sudah Pernah Absen');
      echo json_encode($resultData, JSON_PRETTY_PRINT);
    } else {
      //get today
      $today1 = date('Y-m-d');
      //get datetime when absence
      $today2       = date('Y-m-d');
      $time         = date("H:i:s");
      $timecomplete = $checkin_time;
      //$time = "07:40:00";

      $masukawal      = "07:00:00";
      $masukakhir     = "08:30:00";
      $terlambatawal  = "08:30:01";
      $terlambatakhir = "09:00:00";

      if ($today1 == $today2) {
        if ($time >= $masukawal && $time <= $masukakhir) {
          //hadir
          $status = 1;
        } else if ($time > $terlambatawal && $time <= $terlambatakhir) {
          //terlambat
          $status = 2;
        } else {
          //alpha[3] - [perintah BKPSDM untuk diubah jadi terlambat]
          $status = 2;
        }
      }

      $datas = array('nip' => $nip,
        'kd_skpd'        => $kd_skpd,
        'checkin_status' => $status,
        'checkin_time'   => $timecomplete,
        'today'          => $today1);

      //$result = $this->m_api->absence_pagi($datas);
      /* echo json_encode(
      array("message" => "Absen Berhasil",
      )
      ); */

      $resultData[] = array('status' => TRUE,
        'message'                      => 'Absen Berhasil');
      echo json_encode($resultData, JSON_PRETTY_PRINT);

    }

  }

  ## UPDATE LAPANGAN
  public function updateabsenlapanganno() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

          $nip                 = $this->input->post('nip');
          $today               = $this->input->post('today');
    $data['status_verifikasi'] = 2;
    $data['verifikasi_time']   = date("Y-m-d H:i:s");

    $this->m_api->updateabsenlapangan($data, $nip, $today);
    $resultData[] = array('status' => TRUE,
      'message'                      => 'UBAH DATA BERHASIL');
    echo json_encode($resultData, JSON_PRETTY_PRINT);

  }

  function hitungJarak($lokasi1_lat, $lokasi1_long, $lokasi2_lat, $lokasi2_long, $unit = 'km', $desimal = 2) {

    $derajat = rad2deg(acos((sin(deg2rad($lokasi1_lat)) * sin(deg2rad($lokasi2_lat))) + (cos(deg2rad($lokasi1_lat)) * cos(deg2rad($lokasi2_lat)) * cos(deg2rad($lokasi1_long - $lokasi2_long)))));

    switch ($unit) {
    case 'km': 
      $jarak = $derajat * 111.13384;  // 1 derajat = 111.13384 km, berdasarkan diameter rata-rata bumi (12,735 km)
      break;
    case 'mi': 
      $jarak = $derajat * 69.05482;  // 1 derajat = 69.05482 miles(mil), berdasarkan diameter rata-rata bumi (7,913.1 miles)
      break;
    case 'nmi': 
      $jarak = $derajat * 59.97662;  // 1 derajat = 59.97662 nautic miles(mil laut), berdasarkan diameter rata-rata bumi (6,876.3 nautical miles)
    }
    return round($jarak, $desimal);
  }



  /* API for Lapangan Sore */
  public function inputabsenlapangansore() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

    $data['nip']               = $this->input->post('nip');
    $data['kd_skpd']           = $this->input->post('kd_skpd');
    $data['checkin_time']      = date("Y-m-d H:i:s");
    $data['today']             = date("Y-m-d");
    $data['status_verifikasi'] = 0;


    //get today
    $today1 = date('Y-m-d');
    //get datetime when absence
    $today2 = date('Y-m-d');
    $time   = date("H:i:s");
    //$time = "07:40:00";

    $masukawal      = "15:00:00";
    $masukakhir     = "18:30:00";
    $terlambatawal  = "18:30:01";
    $terlambatakhir = "23:59:59";

    if ($today1 == $today2) {
      if ($data['checkin_time'] >= $masukawal && $data['checkin_time'] <= $masukakhir) {
        //hadir
        $data['checkin_status'] = 1;
      } else if ($data['checkin_time'] > $terlambatawal && $data['checkin_time'] <= $terlambatakhir) {
        //terlambat
        $data['checkin_status'] = 2;
      } else {
        //alpha[3] - [perintah BKPSDM untuk diubah jadi terlambat]
        $data['checkin_status'] = 2;
      }
    }

    $checkAbsencelap = $this->m_api->wasAbsenced_sore_lapangan($data['nip'],$data['today']);

    // UPDATE JAM PULANG ABSENSI
    $dataxx['absensi_tanggal']  = $today1;
    $dataxx['nip']              = $data['nip'];
    $dataxx['jam_pulang']       = $time;

    $this->m_api->edit($dataxx);

    // END UPDATE JAM PULANG ABSENSI

    if($checkAbsencelap){
      //Jika sudah absen
      $resultData[] = array('status' => TRUE,
        'message' => 'ANDA SUDAH ABSEN SORE INI',
        'photo'   => '',
      );
    }else{
      //Jika belum absen
      if ($this->input->post('image') == "") {
        $filename = '';
      } else {
        $gambar       = base64_decode($this->input->post('image'));
        $name         = $this->input->post('name');
        $getExtention = explode(".", $name);
        $filename     = "pic-" . $data['nip'] . "-" . date('YmdHis') . rand(1000, 99999) . "." . $getExtention[1];
        $path         = './upload/pegawai/foto_lapangan/';

        file_put_contents($path . $filename, $gambar);
        $data['foto_lapangan'] = $filename;
      }

      $this->m_api->inputabsenlapangansore($data);
      $resultData[] = array('status' => TRUE,
        'message' => 'TAMBAH DATA BERHASIL',
        'photo'   => $filename,
      );
    }
    echo json_encode($resultData, JSON_PRETTY_PRINT);

  }

  ##GET DATA PASS OFFICER
  public function getAbsenLapangansore() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

    $kd_skpd = $this->input->get('kd_skpd');
    $today   = $this->input->get('today');

    $result = $this->m_api->getAbsenLapangansore($kd_skpd, $today);
    if ($result) {
      echo json_encode($result);
    } else {

      echo json_encode(
        array(
        )
      );
    }

  }



  public function updateabsenlapangansoreno() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

          $nip                 = $this->input->post('nip');
          $today               = $this->input->post('today');
    $data['status_verifikasi'] = 2;
    $data['verifikasi_time']   = date("Y-m-d H:i:s");

    $this->m_api->updateabsenlapangansore($data, $nip, $today);
    $resultData[] = array('status' => TRUE,
      'message'                      => 'UBAH DATA BERHASIL');
    echo json_encode($resultData, JSON_PRETTY_PRINT);

  }


  public function updateabsenlapangansoreyes() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

    $nip   = $this->input->post('nip');
    $today = $this->input->post('today');

    $data['status_verifikasi'] = 1;
    $data['verifikasi_time']   = date("Y-m-d H:i:s");

    $this->m_api->updateabsenlapangansore($data, $nip, $today);
    /* $resultData[] = array('status' => TRUE,
    'message'                      => 'UBAH DATA BERHASIL');
    echo json_encode($resultData, JSON_PRETTY_PRINT); */

    //input data absen
    $checkin_time = $this->input->post('checkin_time');
    //get data
    $kd_skpd = $this->input->post('kd_skpd');

    //check kalo sudah absen ato belum
    $result = $this->m_api->wasAbsenced_sore($nip,
      date('Y-m-d'));
    if ($result) {
      /* echo json_encode(
      array("message" => "Anda Sudah Pernah Absen",
      )
      ); */
      $resultData[] = array('status' => TRUE,
        'message'                      => 'Anda Sudah Pernah Absen');
      echo json_encode($resultData, JSON_PRETTY_PRINT);
    } else {
      //get today
      $today1 = date('Y-m-d');
      //get datetime when absence
      $today2       = date('Y-m-d');
      $time         = date("H:i:s");
      $timecomplete = $checkin_time;
      //$time = "07:40:00";

      $masukawal      = "15:00:00";
      $masukakhir     = "18:30:00";
      $terlambatawal  = "18:30:01";
      $terlambatakhir = "23:59:59";

      if ($today1 == $today2) {
        if ($time >= $masukawal && $time <= $masukakhir) {
          //hadir
          $status = 1;
        } else if ($time > $terlambatawal && $time <= $terlambatakhir) {
          //terlambat
          $status = 2;
        } else {
          //alpha[3] - [perintah BKPSDM untuk diubah jadi terlambat]
          $status = 2;
        }
      }

      $datas = array('nip' => $nip,
        'kd_skpd'        => $kd_skpd,
        'checkin_status' => $status,
        'checkin_time'   => $timecomplete,
        'today'          => $today1);

      //$result = $this->m_api->absence_sore($datas);
      /* echo json_encode(
      array("message" => "Absen Berhasil",
      )
      ); */

      $resultData[] = array('status' => TRUE,
        'message'                      => 'Absen Berhasil');
      echo json_encode($resultData, JSON_PRETTY_PRINT);

    }

  }



  /**
   * GET ABSEN BY NIP
   * @param nip : NIP Pegawai
   * @param bulan : Bulan Absensi
   * @param tahun : Tahun Absensi
   * 
   */

  public function getAttendanceByNip() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);

    $nip   = $this->input->post('nip');
    $bulan = $this->input->post('bulan');
    $tahun = $this->input->post('tahun');


    if(strlen($bulan)==1){
      $newBulan = "0".$bulan;
    }else{
      $newBulan = $bulan;
    }
    
    $format = $tahun."-".$newBulan."-";

    $result = $this->m_api->getAttendanceByNip($nip, $format);
    if ($result) {
      $resultData = array(
        'errcode' => '00',
        'status'  => true,
        'data'    => $result,
      );
      echo json_encode($resultData, JSON_PRETTY_PRINT);

    } else {
      $resultData = array(
        'errcode' => '99',
        'status'  => false,
        'data'    => NULL,
      );
      echo json_encode($resultData, JSON_PRETTY_PRINT);
    }

  }



  // FUNCTION DAY
  public function getDay($date){
    $daftar_hari = array(
      'Sunday'    => 'Minggu',
      'Monday'    => 'Senin',
      'Tuesday'   => 'Selasa',
      'Wednesday' => 'Rabu',
      'Thursday'  => 'Kamis',
      'Friday'    => 'Jumat',
      'Saturday'  => 'Sabtu'
    );
    
    $namahari = date('l', strtotime($date));
    
    return $daftar_hari[$namahari];
  }

}
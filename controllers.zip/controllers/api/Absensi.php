
<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Absensi extends CI_Controller {
  function __construct() {
    parent::__construct();
    $this->load->model('m_api');
  }

  /**
   * =================================================================
   * AUTHOR : TECHNO'S STUDIO
   * =================================================================
   * */

  /**
   * =================================================================
   * Get Token For Access All API Function
   * INPUT  : CLIENT ID & CLIENT SECRET
   * OUTPUT : ACCESS TOKEN
   * METHOD : GET
   * =================================================================
   * */
  public function getAccessToken() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);
    $client_id     = $this->input->get('client_id');
    $client_secret = $this->input->get('client_secret');
    $cek           = $this->m_api->check_token($client_id, $client_secret);
    if ($cek) {
      if ($cek[0]->validity_time == '0000-00-00 00:00:00') {
        /* This Function Running if firstime using API */
        $token                 = sha1(mt_rand(1, 90000) . 'SALT');
        $validity              = 3600;
        $data['client_id']     = $cek[0]->client_id;
        $data['access_token']  = $token;
        $data['validity_time'] = date('Y-m-d H:i:s', strtotime('+1 hour', strtotime(date('Y-m-d H:i:s'))));
        $this->m_api->update_token($data);
      } else {
        $validity = strtotime($cek[0]->validity_time) - time();
        if ($validity < 0) {
          $token                 = sha1(mt_rand(1, 90000) . 'SALT');
          $validity              = 3600;
          $data['client_id']     = $cek[0]->client_id;
          $data['access_token']  = $token;
          $data['validity_time'] = date('Y-m-d H:i:s', strtotime('+1 hour', strtotime(date('Y-m-d H:i:s'))));
          $this->m_api->update_token($data);
        } else {
          $token    = $cek[0]->access_token;
          $validity = strtotime($cek[0]->validity_time) - time();
        }
      }
      $resultData = array(
        'respon_code'  => 'RC200',
        'status'       => true,
        'message'      => 'success',
        'access_token' => $token,
        'validity'     => $validity,
      );
    } else {
      $resultData = array(
        'respon_code' => 'RC401',
        'status'      => false,
        'message'     => 'Oops. Mungkin ada yang salah dengan akun anda',
      );
    }
    echo json_encode($resultData, JSON_PRETTY_PRINT);
  }

  /**
   * =================================================================
   * Method For Get Attendance Data
   * INPUT  : USERNAME & PASSWORD
   * OUTPUT : Officer DATA, WIDGET
   * METHOD : POST
   * =================================================================
   * */
  public function AttendanceByNip() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);
    $headers = apache_request_headers();
    $token = (isset($headers['Access-Token'])) ? $headers['Access-Token'] : $headers['access-token']; 
    if (isset($token)) {
      $cek = $this->m_api->check_token_validity($token);
      if ($cek) {
        $validity = strtotime($cek[0]->validity_time) - time();
        if ($validity < 0) {
          $resultData = array(
            'respon_code' => 'RC401',
            'status'      => false,
            'message'     => 'Oops. Token Expired',
          );
        } else {
          
          // PRECESS INPUT
          $nip   = $this->input->post('nip');
          $bulan = $this->input->post('bulan');
          $tahun = $this->input->post('tahun');
          
          if(strlen($bulan)==1){
            $newBulan = "0".$bulan;
          }else{
            $newBulan = $bulan;
          }
          
          $format = $tahun."-".$newBulan."-";

          $result = $this->m_api->getAttendanceByNip($nip, $format);
          if ($result) {
            $resultData = array(
              'errcode' => '00',
              'status'  => true,
              'message' => 'Berhasil',
              'data'    => $result,
            );

          } else {
            $resultData = array(
              'errcode' => '99',
              'status'  => false,
              'message' => 'Data Pegawai Tidak Ada',
              'data'    => NULL,
            );
          }


        }
      } else {
        $resultData = array(
          'respon_code' => 'RC401',
          'status'      => false,
          'message'     => 'Oops. Token Tidak Valid',
        );
      }
    } else {
      $resultData = array(
        'respon_code' => 'RC401',
        'status'      => false,
        'message'     => 'Anda tidak menyertakan atau memiliki Access Token',
      );
    }
    echo json_encode($resultData, JSON_PRETTY_PRINT);
    
  }

  

  // FOR CRONJOB
  public function push_tidakhadir() {
    $time = date('H');
    //Push semua ke absen ketika jam 11 Malam
    if($time == 23){

      $tanggal       = date('Y-m-d');
      $getTidakHadir = $this->m_api->getNotAttendance($tanggal);

      $hari    = $this->getDay($tanggal);

      if($hari == 'Sabtu' OR $hari == 'Minggu'){
        $status_hari      = 'Extra Day';
        $status_kehadiran = 5;
      }else{
        $status_hari      = 'Work Day';
        $status_kehadiran = 3;
      }


      foreach ($getTidakHadir as $g){

        //echo $g->nip."<br>";

        $x = $this->m_api->cekDouble($g->nip , $tanggal);
        if($x){
          echo $g->nip." - Sudah Ada<br>";
        }else{
          //echo $g->nip."<br>";
          $explodeDate  = explode(' ',$g->checkin_time);

          $data['absensi_id']       = "";
          $data['absensi_tanggal']  = $tanggal;
          $data['nip']              = $g->nip;
          $data['kd_skpd']          = $g->kd_skpd;
          $data['status_berkantor'] = 1;
          $data['status_kehadiran'] = $status_kehadiran;
          $data['hari']             = $hari;
          $data['status_hari']      = $status_hari;

          $this->m_api->input($data);

        }
        
      }


      print("<pre>".print_r($getTidakHadir,true)."</pre>");
    
    }else{
      echo "Belum Saatnya";
    }

  }



  public function testing() {
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    http_response_code(200);
    $headers = apache_request_headers();
    if (isset($headers['Access-Token'])) {
      $cek = $this->m_api->check_token_validity($headers['Access-Token']);
      if ($cek) {
        $validity = strtotime($cek[0]->validity_time) - time();
        if ($validity < 0) {
          $resultData = array(
            'respon_code' => 'RC401',
            'status'      => false,
            'message'     => 'Oops. Token Expired',
          );
        } else {
          
          // PRECESS INPUT
          $nip   = $this->input->post('nip');
          $bulan = $this->input->post('bulan');
          $tahun = $this->input->post('tahun');
          
          if(strlen($bulan)==1){
            $newBulan = "0".$bulan;
          }else{
            $newBulan = $bulan;
          }
          
          $format = $tahun."-".$newBulan."-";

          $result = $this->m_api->getAttendanceByNip($nip, $format);
          if ($result) {
            $resultData = array(
              'errcode' => '00',
              'status'  => true,
              'message' => 'Berhasil',
              'data'    => $result,
            );

          } else {
            $resultData = array(
              'errcode' => '99',
              'status'  => false,
              'message' => 'Data Pegawai Tidak Ada',
              'data'    => NULL,
            );
          }


        }
      } else {
        $resultData = array(
          'respon_code' => 'RC401',
          'status'      => false,
          'message'     => 'Oops. Token Tidak Valid',
        );
      }
    } else {
      $resultData = array(
        'respon_code' => 'RC401',
        'status'      => false,
        'message'     => 'Anda tidak menyertakan atau memiliki Access Token',
      );
    }
    echo json_encode($resultData, JSON_PRETTY_PRINT);
  }


  // FUNCTION DAY
  public function getDay($date){
    $daftar_hari = array(
      'Sunday'    => 'Minggu',
      'Monday'    => 'Senin',
      'Tuesday'   => 'Selasa',
      'Wednesday' => 'Rabu',
      'Thursday'  => 'Kamis',
      'Friday'    => 'Jumat',
      'Saturday'  => 'Sabtu'
    );
    
    $namahari = date('l', strtotime($date));
    
    return $daftar_hari[$namahari];
  }

  

}
?>
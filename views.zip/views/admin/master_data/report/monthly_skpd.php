<div class="container-fluid">
  <?php 
    if($this->session->flashdata('add')){ 
      $message = $this->session->flashdata('add');
      $heading = '#Tambah Barang Sumbangan';
    }else if($this->session->flashdata('update')){ 
      $message = $this->session->flashdata('update');
      $heading = '#Update Barang Sumbangan';
    }else if($this->session->flashdata('delete')){
      $message = $this->session->flashdata('delete');
      $heading = '#Delete Barang Sumbangan';  
    } 
  ?>
  <?php if(isset($message)){ ?>
  <script>
    $(document).ready(function(){
      $.toast({
        text : '<?php echo $message;?>',
        heading : '<?php echo $heading;?>',
        position : 'top-right',
        width : 'auto',
        showHideTransition : 'slide',
        icon: 'info',
        hideAfter: 5000
      })
    });
  </script>
  <?php } ?>
  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800">Laporan Data Absensi Bulanan SKPD</h1>
  <p class="mb-4">Cetak Data Basis PDF (.pdf)</p>
  <hr>

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      


      <a href="<?php echo site_url('report/monthly_skpd')?>" class="btn btn-success btn-icon-split btn-sm">
        <span class="icon text-white-50">
          <i class="fa fa-refresh"></i>
        </span>
        <span class="text">Refresh Halaman</span>
      </a>
    </div>
    <div class="card-body">
      <?php echo form_open_multipart("report/print_monthly_skpd")?>
        <?php if($this->session->userdata('skpd_id')==0){?>
        <div class="form-group">
          <label for=""><b>SKPD</b></label>
          <select id="skpd" class="form-control" name="skpd_id" style="width:100%" required>
            <option value="">.:: Pilih SKPD ::.</option>
            <!-- <option value="0">-Cetak Semua Pegawai-</option> -->
            <?php foreach($skpd as $s){ ?>
            <option value="<?php echo $s->kd_skpd;?>"><?php echo $s->nama;?></option>
            <?php } ?>
          </select>
        </div>
        
        <div class="form-group">
          <label for=""><b>Bulan</b></label>
          <select class="form-control" name="month" style="width:100%" required>
            <option value="">.:: Pilih Bulan ::.</option>
            <option value="01">Januari</option>
            <option value="02">Februari</option>
            <option value="03">Maret</option>
            <option value="04">April</option>
            <option value="05">Mei</option>
            <option value="06">Juni</option>
            <option value="07">Juli</option>
            <option value="08">Agustus</option>
            <option value="09">September</option>
            <option value="10">Okotber</option>
            <option value="11">November</option>
            <option value="12">Desember</option>
            
          </select>
        </div>
        
        <div class="form-group">
          <label for=""><b>Tahun</b></label>
          <select class="form-control" name="year" style="width:100%" required>
            <option value="">.:: Pilih Tahun ::.</option>
            <?php for($i=date('Y');$i>=2019;$i--){ ?>
            <option value="<?php echo $i;?>"><?php echo $i;?></option>
            <?php }?>
            
          </select>

        </div>


        <?php }else{?>
          <div class="form-group">
            <label for=""><b>Bulan</b></label>
            <select class="form-control" name="month" style="width:100%" required>
              <option value="">.:: Pilih Bulan ::.</option>
              <option value="01">Januari</option>
              <option value="02">Februari</option>
              <option value="03">Maret</option>
              <option value="04">April</option>
              <option value="05">Mei</option>
              <option value="06">Juni</option>
              <option value="07">Juli</option>
              <option value="08">Agustus</option>
              <option value="09">September</option>
              <option value="10">Okotber</option>
              <option value="11">November</option>
              <option value="12">Desember</option>
              
            </select>
          </div>
          
          <div class="form-group">
            <label for=""><b>Tahun</b></label>
            <select class="form-control" name="year" style="width:100%" required>
              <option value="">.:: Pilih Tahun ::.</option>
              <?php for($i=date('Y');$i>=2019;$i--){ ?>
              <option value="<?php echo $i;?>"><?php echo $i;?></option>
              <?php }?>
              
            </select>

          </div>
        <input type="hidden" name="skpd_id" value="<?php echo $this->session->userdata('skpd_id')?>">
        <?php }?>
        <button class="btn btn-primary" type="submit" style="width:100%"><i class="fa fa-print"></i> Cetak Data Absensi Bulanan SKPD</button>
      <?php echo form_close(); ?>
    </div>
  </div>

</div>
<!-- /.container-fluid -->
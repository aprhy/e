<div class="container-fluid">
  <?php 
    if($this->session->flashdata('add')){ 
      $message = $this->session->flashdata('add');
      $heading = '#Tambah Barang Sumbangan';
    }else if($this->session->flashdata('update')){ 
      $message = $this->session->flashdata('update');
      $heading = '#Update Barang Sumbangan';
    }else if($this->session->flashdata('delete')){
      $message = $this->session->flashdata('delete');
      $heading = '#Delete Barang Sumbangan';  
    } 
  ?>
  <?php if(isset($message)){ ?>
  <script>
    $(document).ready(function(){
      $.toast({
        text : '<?php echo $message;?>',
        heading : '<?php echo $heading;?>',
        position : 'top-right',
        width : 'auto',
        showHideTransition : 'slide',
        icon: 'info',
        hideAfter: 5000
      })
    });
  </script>
  <?php } ?>
  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800">Laporan Data Absensi Pagi ASN Kota Kendari</h1>
  <p class="mb-4">Cetak Data Absen Dengan Basis Excel (.xls)</p>
  <hr>

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <a href="<?php echo site_url('report/attendance')?>" class="btn btn-success btn-icon-split btn-sm">
        <span class="icon text-white-50">
          <i class="fa fa-refresh"></i>
        </span>
        <span class="text">Refresh Halaman</span>
      </a>
    </div>
    <div class="card-body">
      <?php echo form_open_multipart("report/print_daily_attendance")?>
        <div class="form-group">
          <label for=""><b>Tanggal Absensi</b></label>
          <input type="date" placeholder="Pilih Tanggal Absensi" class="form-control" name="tanggal" required> 
        </div>
        <?php if($this->session->userdata('skpd_id')==0){?>
        <div class="form-group">
          <label for=""><b>SKPD</b></label>
          <select id="skpd" class="form-control" name="skpd" style="width:100%" required>
            <option value="">.:: Pilih SKPD ::.</option>
            <!-- <option value="0">-Cetak Semua Pegawai-</option> -->
            <?php foreach($skpd as $s){ ?>
            <option value="<?php echo $s->kd_skpd;?>"><?php echo $s->nama;?></option>
            <?php } ?>
          </select>
        </div>
        <?php }else{?>
        <input type="hidden" name="skpd" value="<?php echo $this->session->userdata('skpd_id')?>">
        <?php }?>
        <button class="btn btn-primary" type="submit" style="width:100%"><i class="fa fa-print"></i> Cetak Absensi Harian</button>
      <?php echo form_close(); ?>
    </div>
  </div>

</div>
<!-- /.container-fluid -->
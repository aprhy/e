<?php ob_start(); ?>

  <page backbottom="0mm" backleft="15mm" backright="15mm" backtop="5mm">
    <table border="0" cellpadding="0" cellspacing="0" style="width:100%;">
      <tbody>
        <tr>
          <td style="width: 10%;"><img src="./upload/setting/settinglogo12.png" height="50"></td>
          <td style="width: 90%; text-align: center;"><strong style="font-size: 14px; text-align: center;">PEMERINTAH KOTA KENDARI</strong><br style="font-size: 14px; text-align: center;" />
            <strong style="font-size: 14px; text-align: center; line-height: 15.8px;"><?php echo strtoupper($getNama[0]->nama)?><br />
            KOTA KENDARI</strong>
          </td>
        </tr>
      </tbody>
    </table>
    <hr>
    <table border="0" cellpadding="0" cellspacing="0" style="width: 100%;">
      <tbody>
        <tr>
          <td style="width: 25%;"><span style="font-size:12;">PERIODE ABSENSI (bln/thn)</span></td>
          <td style="width: 5%;"><span style="font-size:12;">:</span></td>
          <td style="width: 70%;"><span style="font-size:12;"><?php echo $date;?></span></td>
        </tr>
      </tbody>
    </table>
    <br><br>
    <table border="1" cellpadding="0" cellspacing="0" style="width: 100%;table-layout:fixed;">
      <tbody>
        <tr>
          <td style="width: 5%; text-align: center;" rowspan="2"><span style="font-size:14px;"><b>NO</b></span></td>
          <td style="width: 15%; text-align: center;" rowspan="2"><span style="font-size:14px;"><b>NIP</b></span></td>
          <td style="width: 30%; text-align: center;" rowspan="2"><span style="font-size:14px;"><b>NAMA</b></span></td>
          <td style="width: 10%; text-align: center;" rowspan="2"><span style="font-size:14px;"><b>HADIR</b></span></td>
          <td style="width: 40%; text-align: center;" colspan="4"><span style="font-size:14px;"><b>TIDAK HADIR</b></span></td>
        </tr>
        <tr>
          <td style="width: 10%; text-align: center;"><span style="font-size:14px;"><b>Cuti Sakit</b></span></td>
          <td style="width: 10%; text-align: center;"><span style="font-size:14px;"><b>Cuti Bersalin</b></span></td>
          <td style="width: 10%; text-align: center;"><span style="font-size:14px;"><b>Alpa</b></span></td>
          <td style="width: 10%; text-align: center;"><span style="font-size:14px;"><b>Sakit/Izin</b></span></td>
        </tr>
        <?php $no=1; foreach($value as $v){ ?>

          <tr>
            <td><?php echo $no++; ?></td>
            <td><?php echo $v->nip ?></td>
            <td><?php echo $v->nama ?></td>
            <td style="text-align: center;"><?php echo $v->hadir ?></td>
            <td style="text-align: center;"><?php echo $v->cuti ?></td>
            <td style="text-align: center;"><?php echo $v->bersalin ?></td>
            <td style="text-align: center;"><?php echo $v->alpa ?></td>
            <td style="text-align: center;"><?php echo $v->izin ?></td>
          </tr>
        <?php }?>
      
      </tbody>
    </table>
  </page>
    
  

<?php
  $content = ob_get_contents();
  ob_clean();

  try
  {
    
    $html2pdf = new HTML2PDF('L', 'A4', 'en');
    $html2pdf->pdf->SetDisplayMode('fullpage');
    $html2pdf->setDefaultFont('Arial'); 
    $html2pdf->writeHTML($content);
    $html2pdf->Output('Absensi '.$date.'-'.$getNama[0]->nama.'.pdf');
  }
  catch(HTML2PDF_exception $e) {
    echo $e;
    exit;
  }
?>
<?php ob_start(); ?>

  <page backbottom="0mm" backleft="15mm" backright="15mm" backtop="5mm">
    <table border="0" cellpadding="0" cellspacing="0" style="width:100%;">
      <tbody>
        <tr>
          <td style="width: 10%;"><img src="./upload/setting/settinglogo12.png" height="50"></td>
          <td style="width: 90%; text-align: center;"><strong style="font-size: 14px; text-align: center;">PEMERINTAH KOTA KENDARI</strong><br style="font-size: 14px; text-align: center;" />
            <strong style="font-size: 14px; text-align: center; line-height: 15.8px;"><?php echo strtoupper($getNama[0]->nama)?><br />
            KOTA KENDARI</strong>
          </td>
        </tr>
      </tbody>
    </table>
    <hr>
    <table border="0" cellpadding="0" cellspacing="0" style="width: 100%;">
      <tbody>
        <tr>
          <td style="width: 25%;"><span style="font-size:12px;"><b>PEGAWAI</b></span></td>
          <td style="width: 5%;"><span style="font-size:12;"><b>:</b></span></td>
          <td style="width: 70%;"><span style="font-size:12;"><b><?php echo $namaPegawai[0]->nip."-".$namaPegawai[0]->nama;?></b></span></td>
        </tr>
        <tr>
          <td style="width: 25%;"><span style="font-size:12;">PERIODE ABSENSI</span></td>
          <td style="width: 5%;"><span style="font-size:12;">:</span></td>
          <td style="width: 70%;"><span style="font-size:12;"><?php echo $date;?></span></td>
        </tr>
      </tbody>
    </table>
    <br><br>
    <table border="1" cellpadding="0" cellspacing="0" style="width: 100%;">
      <tbody>
        <tr>
          <th style="width: 15%; text-align: center;"><span style="font-size:14px;">Tanggal</span></th>
          <th style="width: 15%; text-align: center;"><span style="font-size:14px;">Jam Masuk</span></th>
          <th style="width: 15%; text-align: center;"><span style="font-size:14px;">Jam Pulang</span></th>
          <th style="width: 25%; text-align: center;"><span style="font-size:14px;">Status</span></th>
          <th style="width: 15%; text-align: center;"><span style="font-size:14px;">Hari</span></th>
          <th style="width: 15%; text-align: center;"><span style="font-size:14px;">Status Hari</span></th>
        </tr>
        <?php foreach($value as $v){
          
          if($v->status_kehadiran==0){
            $status = 'HADIR';
          }elseif($v->status_kehadiran==1){
            $status = 'CUTI SAKIT';
          }elseif($v->status_kehadiran==2){
            $status = 'CUTI BESAR/ BERSALIN / KARNA HAL PENTING';
          }elseif($v->status_kehadiran==3){
            $status = 'ANPA KETERANGAN (ALPA)';
          }elseif($v->status_kehadiran==4){
            $status = 'SAKIT / IZIN DENGAN KETERANGAN';
          }else{
            $status = 'LIBUR';
          }


          if($v->jam_masuk=="00:00:00"){
            $status_hari = 'EXTRA DAY';
          }else{
            $status_hari = strtoupper($v->status_hari);
          }
        
        ?>
        <tr>
          <td style="width: 15%; text-align: center;"><span style="font-size:14px;"><?php echo $v->absensi_tanggal; ?></span></td>
          <td style="width: 15%; text-align: center;"><span style="font-size:14px;"><?php echo $v->jam_masuk; ?></span></td>
          <td style="width: 15%; text-align: center;"><span style="font-size:14px;"><?php echo $v->jam_pulang; ?></span></td>
          <td style="width: 25%; text-align: center;"><span style="font-size:14px;"><?php echo $status; ?></span></td>
          <td style="width: 15%; text-align: center;"><span style="font-size:14px;"><?php echo strtoupper($v->hari); ?></span></td>
          <td style="width: 15%; text-align: center;"><span style="font-size:14px;"><?php echo $status_hari; ?></span></td>
        </tr>
        <?php }?>
      </tbody>
    </table>
  </page>
    
  

<?php
  $content = ob_get_contents();
  ob_clean();

  try
  {
    
    $html2pdf = new HTML2PDF('P', 'A4', 'en');
    $html2pdf->pdf->SetDisplayMode('fullpage');
    $html2pdf->setDefaultFont('Arial'); 
    $html2pdf->writeHTML($content);
    $html2pdf->Output('Absensi '.$date.'-'.$namaPegawai[0]->nip.'.pdf');
  }
  catch(HTML2PDF_exception $e) {
    echo $e;
    exit;
  }
?>
<!-- Begin Page Content -->
<div class="container-fluid">
  
  <!-- Page Heading -->
  <h1 class="h3 mb-4 text-gray-800">Grafik </h1>
  <div class="row">
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/series-label.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>

    <div class="col-md-12 mb-4">
      <div class="card shadow mb-4">
        <div class="card-header py-3">
          <h6 class="m-0 font-weight-bold text-primary">Grafik Presentase Ketidakhadiran Bulan <?php echo date('m Y')?></h6>
        </div>
        <div class="card-body">
          
          <?php rsort($total_ketidakhadiranSKPD);?>
          <div class="row">
            <div class="col-md-7">
              <center><span>.:: 10 Teratas Dinas dengan Tingkat KetidakHadiran Paling Tinggi ::</span></center>
              <div id="grafikPerforma"></div>
                <script type="text/javascript">
                Highcharts.chart('grafikPerforma', {
                    chart: {
                        type: 'bar'
                    },
                    title: {
                        text: 'Presentase Per-SKPD'
                    },
                    subtitle: {
                        text: 'Source: Data Absensi Pegawai'
                    },
                    xAxis: {
                        categories: ['Dinas Kota Kendari'],
                        title: {
                            text: null
                        }
                    },
                    yAxis: {
                        min: 0,
                        title: {
                            text: 'Presentase (%)',
                            align: 'high'
                        },
                        labels: {
                            overflow: 'justify'
                        }
                    },
                    tooltip: {
                        valueSuffix: ' Persen'
                    },
                    plotOptions: {
                        bar: {
                            dataLabels: {
                                enabled: true
                            }
                        }
                    },
                    
                    credits: {
                        enabled: false
                    },
                    series: [
                      <?php $xxx =1; foreach($total_ketidakhadiranSKPD as $tks) {?>
                      {
                        name: '<?php echo $tks->nama;?>',
                        data: [<?php echo number_format(($tks->total / $total_ketidakhadiran[0]->total)*100, 2);?>]
                      },
                      
                      <?php $xxx++; if($xxx==11) break;  }?>
                      ]
                });
              </script>
            </div>
            <div class="col-md-1"></div>
            <div class="col-md-4">
              <center><span>.:: Persentase Perbandingan Hadir dan Tidak Hadir ::</span></center>
              <div id="grafikPerbandingan"></div>
              <script>
                Highcharts.chart('grafikPerbandingan', {
                    chart: {
                        plotBackgroundColor: null,
                        plotBorderWidth: null,
                        plotShadow: false,
                        type: 'pie'
                    },
                    title: {
                        text: 'Perbandingan Kehadiran'
                    },
                    tooltip: {
                        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
                    },
                    accessibility: {
                        point: {
                            valueSuffix: '%'
                        }
                    },
                    plotOptions: {
                        pie: {
                            allowPointSelect: true,
                            cursor: 'pointer',
                            dataLabels: {
                                enabled: true,
                                format: '<b>{point.name}</b>: {point.percentage:.1f} %'
                            }
                        }
                    },
                    series: [{
                        name: 'Total Presentase',
                        colorByPoint: true,
                        data: [
                        {
                            name: 'Hadir',
                            y: <?php echo number_format( ($total_kehadiran[0]->total / $total_seluruhkehadiran[0]->total)*100,2);?>,
                            sliced: true,
                            selected: true,
                            color: '#4ead05'
                        }, {
                            name: 'Tidak Hadir',
                            y: <?php echo number_format( ($total_ketidakhadiran[0]->total / $total_seluruhkehadiran[0]->total)*100,2);?>,
                            color: '#fc0303'
                        }]
                    }]
                });
              </script>
            </div>
          </div>
          
          
        </div>
      </div>
    </div>


    <div class="col-md-6 mb-4">
      <div class="card shadow mb-4">
        <div class="card-header py-3">
          <h6 class="m-0 font-weight-bold text-primary">Aktifitas Online Hari Ini</h6>
        </div>
        <div class="card-body">
          <span>.:: Total Kunjungan ::.</span>
          <div id="grafikjam"></div>
          
          <script type="text/javascript">
            Highcharts.chart('grafikjam', {
                title: {
                    text: 'Kunjugan Web Hari Ini Per-Jam'
                },
                subtitle: {
                    text: 'Sumber: Website Absen Online Kota Kendari'
                },
                yAxis: {
                  allowDecimals: false,
                    title: {
                        text: 'Jumlah Kunjungan (<b>per-jam</b>)'
                    },
                    
                },
                legend: {
                    layout: 'vertical',
                    align: 'right',
                    verticalAlign: 'middle'
                },
                plotOptions: {
                    series: {
                        label: {
                            connectorAllowed: false
                        },
                        pointStart: 0
                    }
                },
                series: [{
                    name: 'Kunjungan Hari Ini',
                    data: [
                      <?php 
                        for($i=0;$i<=23;$i++){
                          echo $jam[$i].",";
                        }
                      ?>
                    ]
                }],
                responsive: {
                    rules: [{
                        condition: {
                            maxWidth: 500
                        },
                        chartOptions: {
                            legend: {
                                layout: 'horizontal',
                                align: 'center',
                                verticalAlign: 'bottom'
                            }
                        }
                    }]
                }
            });
          </script>
        </div>
      </div>
    </div>
    <div class="col-md-6 mb-4">
      <div class="card shadow mb-4">
        <div class="card-header py-3">
          <h6 class="m-0 font-weight-bold text-primary">Log Sistem Terbaru</h6>
        </div>
        <div class="card-body">
          <?php foreach ($log as $key) { ?>
            <small class="text-danger"><b><?php echo $key->user_name?></b><br><?php echo $key->log_time?></small><br>
            <?php echo $key->log_message?><hr>
            <?php  } ?>
        </div>
      </div>
    </div>
  </div>
  
  

  <script type="text/javascript">
    function getkecamatan(angka){
      var kecamatan = angka;
      console.log(kecamatan);
      $.ajax({
        success:function(){
          
          location.href='<?php echo base_url()?>home/index/'+angka;
          
        }
      });
    }
  </script>

</div>

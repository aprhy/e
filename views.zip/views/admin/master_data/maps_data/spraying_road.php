<div class="container-fluid">
  <?php 
    if($this->session->flashdata('add')){ 
      $message = $this->session->flashdata('add');
      $heading = '#Tambah Penyemprotan Jalan';
    }else if($this->session->flashdata('update')){ 
      $message = $this->session->flashdata('update');
      $heading = '#Update Penyemprotan Jalan';
    }else if($this->session->flashdata('delete')){
      $message = $this->session->flashdata('delete');
      $heading = '#Delete Penyemprotan Jalan';  
    } 
  ?>
  <?php if(isset($message)){ ?>
  <script>
    $(document).ready(function(){
      $.toast({
        text : '<?php echo $message;?>',
        heading : '<?php echo $heading;?>',
        position : 'top-right',
        width : 'auto',
        showHideTransition : 'slide',
        icon: 'info',
        hideAfter: 5000
      })
    });
  </script>
  <?php } ?>
  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800">Data Penyemprotan Jalan</h1>
  <p class="mb-4">Data berikut merupakan kumpulan Penyemprotan Jalan Disinfektan - Kota Kendari</p>
  <a href="<?php echo site_url('spraying')?>" class="btn btn-secondary btn-icon-split btn-sm">  
    <span class="text">Data Penyemprotan Disinfektan Fasilitas Kota (Dinas Kesehatan & BPBD)</span>
  </a>
  <a href="<?php echo site_url('spraying_road')?>" class="btn btn-warning btn-icon-split btn-sm">  
    <span class="text">Data Penyemprotan Jalan Disinfektan Jalan (Dinas Kebakaran)</span>
  </a>
  <hr>
  
  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <a href="#" class="btn btn-primary btn-icon-split btn-sm" data-toggle="modal" data-target="#spraying_roadModal">
        <span class="icon text-white-50">
          <i class="fas fa-plus"></i>
        </span>
        <span class="text">Tambah Data</span>
      </a>

      <!-- spraying_road Modal-->
      <div class="modal fade" id="spraying_roadModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Tambah Penyemprotan Jalan Baru</h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <?php echo form_open_multipart("spraying_road/input")?>
            <div class="modal-body">
              <div class="form-group">
                <label for=""><b>Lokasi Penyemprotan Jalan</b></label>
                <input type="text" class="form-control" placeholder="Masukkan Lokasi Penyemprotan Jalan..." name="spraying_road_location" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>Tanggal Penyemprotan Jalan</b></label>
                <input type="date" class="form-control" placeholder="Masukkan Kordinat Penyemprotan Jalan..." name="spraying_road_date" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>Dinas Penyemprotan Jalan</b></label>
                <select name="spraying_road_opd" class="form-control" required>
                  <option value="">.:: Pilih Dinas ::.</option>
                  <option value="1">Dinas Kebakaran</option>
                </select>
              </div>
              
              <div class="form-group">
                <label for=""><b>Keterangan Penyemprotan Jalan</b></label>
                <textarea class="form-control" name="spraying_road_description" placeholder="Keterangan Penyemprotan Jalan..."></textarea>
              </div>
              
              <div class="form-group">
                <label for=""><b>Foto Penyemprotan Jalan</b></label>
                <input type="file" class="form-control" name="userfile">
              </div>
              
            </div>
            <div class="modal-footer">
              <button class="btn btn-primary" type="submit">Tambah</button>
            <?php echo form_close(); ?>
              <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
              
            </div>
          </div>
        </div>
      </div>


      <a href="<?php echo site_url('spraying_road')?>" class="btn btn-success btn-icon-split btn-sm">
        <span class="icon text-white-50">
          <i class="fa fa-refresh"></i>
        </span>
        <span class="text">Refresh Halaman</span>
      </a>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th style="width: 5%;">No</th>
              <th style="width: 19%;">#</th>
              <th>Lokasi</th>
              <th>OPD</th>
            </tr>
          </thead>
          
          <tbody>
            <?php $no=1; foreach($spraying_road as $key){?>
            <tr>
              <td><?php echo $no;?></td>
              <td>
                <a href="<?php echo site_url('spraying_road/detail/'.$key->spraying_road_id);?>" class="btn btn-success btn-icon-split btn-sm">
                  <span class="text">
                    <i class="fa fa-map-marker"></i>
                  </span>
                </a>
                |
                <a href="#" class="btn btn-info btn-icon-split btn-sm" data-toggle="modal" data-target="#spraying_roadDetailModal<?php echo $key->spraying_road_id?>">
                  <span class="text">
                    <i class="fa fa-image"></i>
                  </span>
                </a>
                <a href="#" class="btn btn-warning btn-icon-split btn-sm" data-toggle="modal" data-target="#spraying_roadEditModal<?php echo $key->spraying_road_id?>">
                  <span class="text">
                    <i class="fa fa-edit"></i>
                  </span>
                </a>
                <a href="#" class="btn btn-danger btn-icon-split btn-sm" data-toggle="modal" data-target="#spraying_roadRemoveModal<?php echo $key->spraying_road_id?>">
                  <span class="text">
                    <i class="fa fa-trash"></i>
                  </span>
                </a>


              </td>
              <td><?php echo $key->spraying_road_location?></td>
              <td>
                <?php 
                  if($key->spraying_road_opd==1){
                    echo "Dinas Kebakaran";
                  }else{
                    echo "";
                  } 
                ?>
              </td>
            </tr>

            <!-- Looping Modal Area -->

            <!-- spraying_road Modal Edit-->
            <div class="modal fade" id="spraying_roadEditModal<?php echo $key->spraying_road_id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Penyemprotan Jalan</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                  </div>
                  <?php echo form_open_multipart("spraying_road/edit")?>
                  <div class="modal-body">
                    <div class="form-group">
                      <label for=""><b>Nama Penyemprotan Jalan</b></label>
                      <input type="hidden" class="form-control" name="spraying_road_id" value="<?php echo $key->spraying_road_id?>">
                      <input type="hidden" class="form-control" name="spraying_road_photo" value="<?php echo $key->spraying_road_photo?>">
                      <input type="text" class="form-control" placeholder="Masukkan Lokasi Penyemprotan Jalan..." name="spraying_road_location" value="<?php echo $key->spraying_road_location?>" required="required">
                    </div>
                    
                    
                    <div class="form-group">
                      <label for=""><b>Tanggal Penyemprotan Jalan</b></label>
                      <input type="date" class="form-control" placeholder="Masukkan Kordinat Penyemprotan Jalan..." name="spraying_road_date" required="required" value="<?php echo $key->spraying_road_date;?>">
                    </div>
                    <div class="form-group">
                      <label for=""><b>Dinas Penyemprotan Jalan</b></label>
                      <select name="spraying_road_opd" class="form-control" required>
                        <option value="">.:: Pilih Dinas ::.</option>
                        <option value="1" selected>Dinas Kebakaran</option>
                      </select>
                    </div>
                    
                    <div class="form-group">
                      <label for=""><b>Keterangan Penyemprotan Jalan</b></label>
                      <textarea class="form-control" name="spraying_road_description" placeholder="Keterangan Penyemprotan Jalan..."><?php echo $key->spraying_road_description; ?></textarea>
                    </div>
                    
                    <div class="form-group">
                      <label for=""><b>Foto Penyemprotan Jalan</b></label>
                      <input type="file" class="form-control" name="userfile">
                    </div>
                    
                  </div>
                  <div class="modal-footer">
                    <button class="btn btn-warning" type="submit">Edit</button>
                  <?php echo form_close(); ?>
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    
                  </div>
                </div>
              </div>
            </div>

            <!-- spraying_road Modal Remove-->
            <div class="modal fade" id="spraying_roadRemoveModal<?php echo $key->spraying_road_id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Hapus Penyemprotan Jalan</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                  </div>
                  <?php echo form_open("spraying_road/delete")?>
                  <div class="modal-body">
                    Apakah anda yakin akan menghapus data Penyemprotan Jalan <b><?php echo $key->spraying_road_location ?></b> ?
                    <input type="hidden" class="form-control" name="spraying_road_id" value="<?php echo $key->spraying_road_id?>">
                    <input type="hidden" class="form-control" name="spraying_road_location" value="<?php echo $key->spraying_road_location?>">
                    <input type="hidden" class="form-control" name="spraying_road_photo" value="<?php echo $key->spraying_road_photo?>">
                  </div>
                  <div class="modal-footer">
                    <button class="btn btn-danger" type="submit">Hapus</button>
                  <?php echo form_close(); ?>
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    
                  </div>
                </div>
              </div>
            </div>



            <!-- spraying_road Modal Remove-->
            <div class="modal fade" id="spraying_roadDetailModal<?php echo $key->spraying_road_id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Foto Penyemprotan Jalan</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                  </div>
                 
                  <div class="modal-body">
                    <center>
                      <img src="<?php echo base_url()?>upload/spraying/road/<?php echo $key->spraying_road_photo?>" width="300">
                      <hr> <b><?php echo $key->spraying_road_location?></b>
                    </center>
                  </div>
                  <div class="modal-footer">
                    
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    
                  </div>
                </div>
              </div>
            </div>

            <!-- End Looping -->


            <?php $no++; } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->
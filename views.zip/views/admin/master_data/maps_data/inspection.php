<div class="container-fluid">
  <?php 
    if($this->session->flashdata('add')){ 
      $message = $this->session->flashdata('add');
      $heading = '#Tambah Pemeriksaan Sosial';
    }else if($this->session->flashdata('update')){ 
      $message = $this->session->flashdata('update');
      $heading = '#Update Pemeriksaan Sosial';
    }else if($this->session->flashdata('delete')){
      $message = $this->session->flashdata('delete');
      $heading = '#Delete Pemeriksaan Sosial';  
    } 
  ?>
  <?php if(isset($message)){ ?>
  <script>
    $(document).ready(function(){
      $.toast({
        text : '<?php echo $message;?>',
        heading : '<?php echo $heading;?>',
        position : 'top-right',
        width : 'auto',
        showHideTransition : 'slide',
        icon: 'info',
        hideAfter: 5000
      })
    });
  </script>
  <?php } ?>
  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800">Data Pemeriksaan Sosial</h1>
  <p class="mb-4">Data berikut merupakan kumpulan Pemeriksaan Sosial - Kota Kendari</p>
  <a href="<?php echo site_url('inspection')?>" class="btn btn-warning btn-icon-split btn-sm">  
    <span class="text">Data Pemeriksaan Sosial (Dinas Kesehatan)</span>
  </a>
  <a href="<?php echo site_url('inspection_vehicle')?>" class="btn btn-secondary btn-icon-split btn-sm">  
    <span class="text">Data Pemeriksaan Titik Masuk (Dinas Perhubungan)</span>
  </a>
  <hr>
  
  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <a href="#" class="btn btn-primary btn-icon-split btn-sm" data-toggle="modal" data-target="#inspectionModal">
        <span class="icon text-white-50">
          <i class="fas fa-plus"></i>
        </span>
        <span class="text">Tambah Data</span>
      </a>

      <!-- inspection Modal-->
      <div class="modal fade" id="inspectionModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Tambah Pemeriksaan Sosial Baru</h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <?php echo form_open_multipart("inspection/input")?>
            <div class="modal-body">
              <div class="form-group">
                <label for=""><b>Lokasi Pemeriksaan Sosial</b></label>
                <input type="text" class="form-control" placeholder="Masukkan Lokasi Pemeriksaan Sosial..." name="inspection_location" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>Titik Kordinat Pemeriksaan Sosial</b></label>
                <input type="text" class="form-control" placeholder="Masukkan Kordinat Pemeriksaan Sosial..." name="inspection_coordinate" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>Tanggal Pemeriksaan Sosial</b></label>
                <input type="date" class="form-control" placeholder="Masukkan Kordinat Pemeriksaan Sosial..." name="inspection_date" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>Dinas Pemeriksaan Sosial</b></label>
                <select name="inspection_opd" class="form-control" required>
                  <option value="">.:: Pilih Dinas ::.</option>
                  <option value="1">Dinas Kesehatan</option>
                </select>
              </div>
              
              <div class="form-group">
                <label for=""><b>Keterangan Pemeriksaan Sosial</b></label>
                <textarea class="form-control" name="inspection_description" placeholder="Keterangan Pemeriksaan Sosial..."></textarea>
              </div>
              
              <div class="form-group">
                <label for=""><b>Foto Pemeriksaan Sosial</b></label>
                <input type="file" class="form-control" name="userfile">
              </div>
              <hr>
              <div class="form-group">
                <label for=""><b>Jumlah Sosialisasi & Himbauan</b></label>
                <input type="number" class="form-control" placeholder="Jumlah Sosial dan Himbauan..." name="inspection_socialization_qty" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>Jumlah Screening</b></label>
                <input type="number" class="form-control" placeholder="Jumlah Screening..." name="inspection_screening_qty" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>Jumlah Pembagian Masker</b></label>
                <input type="number" class="form-control" placeholder="Jumlah Pembagian Masker..." name="inspection_mask_distribution_qty" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>Jumlah Pembagian APD</b></label>
                <input type="number" class="form-control" placeholder="Jumlah Pembagian APD..." name="inspection_apd_distribution_qty" required="required">
              </div>
              
            </div>
            <div class="modal-footer">
              <button class="btn btn-primary" type="submit">Tambah</button>
            <?php echo form_close(); ?>
              <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
              
            </div>
          </div>
        </div>
      </div>


      <a href="<?php echo site_url('inspection')?>" class="btn btn-success btn-icon-split btn-sm">
        <span class="icon text-white-50">
          <i class="fa fa-refresh"></i>
        </span>
        <span class="text">Refresh Halaman</span>
      </a>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th style="width: 5%;">No</th>
              <th style="width: 19%;">#</th>
              <th>Lokasi</th>
              <th>Sosialisasi</th>
              <th>Screening</th>
              <th>Pembagian Masker</th>
              <th>Pembagian APD</th>
              <th>OPD</th>
            </tr>
          </thead>
          
          <tbody>
            <?php $no=1; foreach($inspection as $key){?>
            <tr>
              <td><?php echo $no;?></td>
              <td>
                <a href="#" class="btn btn-info btn-icon-split btn-sm" data-toggle="modal" data-target="#inspectionDetailModal<?php echo $key->inspection_id?>">
                  <span class="text">
                    <i class="fa fa-image"></i>
                  </span>
                </a>
                <a href="#" class="btn btn-warning btn-icon-split btn-sm" data-toggle="modal" data-target="#inspectionEditModal<?php echo $key->inspection_id?>">
                  <span class="text">
                    <i class="fa fa-edit"></i>
                  </span>
                </a>
                <a href="#" class="btn btn-danger btn-icon-split btn-sm" data-toggle="modal" data-target="#inspectionRemoveModal<?php echo $key->inspection_id?>">
                  <span class="text">
                    <i class="fa fa-trash"></i>
                  </span>
                </a>


              </td>
              <td><?php echo $key->inspection_location?></td>
              <td><?php echo $key->inspection_socialization_qty?></td>
              <td><?php echo $key->inspection_screening_qty?></td>
              <td><?php echo $key->inspection_mask_distribution_qty?></td>
              <td><?php echo $key->inspection_apd_distribution_qty?></td>
              <td>
                <?php 
                  if($key->inspection_opd==1){
                    echo "Dinas Kesehatan";
                  }else{
                    echo "BPBD";
                  } 
                ?>
              </td>
            </tr>

            <!-- Looping Modal Area -->

            <!-- inspection Modal Edit-->
            <div class="modal fade" id="inspectionEditModal<?php echo $key->inspection_id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Pemeriksaan Sosial</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                  </div>
                  <?php echo form_open_multipart("inspection/edit")?>
                  <div class="modal-body">
                    <div class="form-group">
                      <label for=""><b>Lokasi Pemeriksaan Sosial</b></label>
                      <input type="hidden" class="form-control" name="inspection_id" value="<?php echo $key->inspection_id?>">
                      <input type="hidden" class="form-control" name="inspection_photo" value="<?php echo $key->inspection_photo?>">
                      <input type="text" class="form-control" placeholder="Masukkan Lokasi Pemeriksaan Sosial..." name="inspection_location" value="<?php echo $key->inspection_location?>" required="required">
                    </div>
                    
                    <div class="form-group">
                      <label for=""><b>Titik Kordinat Pemeriksaan Sosial</b></label>
                      <input type="text" class="form-control" placeholder="Masukkan Kordinat Pemeriksaan Sosial..." name="inspection_coordinate" required="required" value="<?php echo $key->inspection_coordinate?>">
                    </div>
                    <div class="form-group">
                      <label for=""><b>Tanggal Pemeriksaan Sosial</b></label>
                      <input type="date" class="form-control" placeholder="Masukkan Kordinat Pemeriksaan Sosial..." name="inspection_date" required="required" value="<?php echo $key->inspection_date?>">
                    </div>
                    <div class="form-group">
                      <label for=""><b>Dinas Pemeriksaan Sosial</b></label>
                      <select name="inspection_opd" class="form-control" required>
                        <option value="">.:: Pilih Dinas ::.</option>
                        <option value="1" selected>Dinas Kesehatan</option>
                      </select>
                    </div>
                    
                    <div class="form-group">
                      <label for=""><b>Keterangan Pemeriksaan Sosial</b></label>
                      <textarea class="form-control" name="inspection_description" placeholder="Keterangan Pemeriksaan Sosial..."><?php echo $key->inspection_description?></textarea>
                    </div>
                    
                    <div class="form-group">
                      <label for=""><b>Foto Pemeriksaan Sosial</b></label>
                      <input type="file" class="form-control" name="userfile">
                    </div>
                    <hr>
                    <div class="form-group">
                      <label for=""><b>Jumlah Sosialisasi & Himbauan</b></label>
                      <input type="number" class="form-control" placeholder="Jumlah Sosial dan Himbauan..." name="inspection_socialization_qty" required="required" value="<?php echo $key->inspection_socialization_qty?>">
                    </div>
                    <div class="form-group">
                      <label for=""><b>Jumlah Screening</b></label>
                      <input type="number" class="form-control" placeholder="Jumlah Screening..." name="inspection_screening_qty" required="required" value="<?php echo $key->inspection_screening_qty?>">
                    </div>
                    <div class="form-group">
                      <label for=""><b>Jumlah Pembagian Masker</b></label>
                      <input type="number" class="form-control" placeholder="Jumlah Pembagian Masker..." name="inspection_mask_distribution_qty" required="required" value="<?php echo $key->inspection_mask_distribution_qty?>">
                    </div>
                    <div class="form-group">
                      <label for=""><b>Jumlah Pembagian APD</b></label>
                      <input type="number" class="form-control" placeholder="Jumlah Pembagian APD..." name="inspection_apd_distribution_qty" required="required" value="<?php echo $key->inspection_apd_distribution_qty?>">
                    </div>
                    
                  </div>
                  <div class="modal-footer">
                    <button class="btn btn-warning" type="submit">Edit</button>
                  <?php echo form_close(); ?>
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    
                  </div>
                </div>
              </div>
            </div>

            <!-- inspection Modal Remove-->
            <div class="modal fade" id="inspectionRemoveModal<?php echo $key->inspection_id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Hapus Pemeriksaan Sosial</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                  </div>
                  <?php echo form_open("inspection/delete")?>
                  <div class="modal-body">
                    Apakah anda yakin akan menghapus data Pemeriksaan Sosial <b><?php echo $key->inspection_name ?></b> ?
                    <input type="hidden" class="form-control" name="inspection_id" value="<?php echo $key->inspection_id?>">
                    <input type="hidden" class="form-control" name="inspection_location" value="<?php echo $key->inspection_location?>">
                    <input type="hidden" class="form-control" name="inspection_photo" value="<?php echo $key->inspection_photo?>">
                  </div>
                  <div class="modal-footer">
                    <button class="btn btn-danger" type="submit">Hapus</button>
                  <?php echo form_close(); ?>
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    
                  </div>
                </div>
              </div>
            </div>



            <!-- inspection Modal Remove-->
            <div class="modal fade" id="inspectionDetailModal<?php echo $key->inspection_id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Foto Pemeriksaan Sosial</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                  </div>
                 
                  <div class="modal-body">
                    <center>
                      <img src="<?php echo base_url()?>upload/inspection/social/<?php echo $key->inspection_photo?>" width="300">
                      <hr> <b><?php echo $key->inspection_location?></b>
                    </center>
                  </div>
                  <div class="modal-footer">
                    
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    
                  </div>
                </div>
              </div>
            </div>

            <!-- End Looping -->


            <?php $no++; } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->
<div class="container-fluid">
  <?php 
    if($this->session->flashdata('add')){ 
      $message = $this->session->flashdata('add');
      $heading = '#Tambah Kasus';
    }else if($this->session->flashdata('update')){ 
      $message = $this->session->flashdata('update');
      $heading = '#Update Kasus';
    }else if($this->session->flashdata('delete')){
      $message = $this->session->flashdata('delete');
      $heading = '#Delete Kasus';  
    } 
  ?>
  <?php if(isset($message)){ ?>
  <script>
    $(document).ready(function(){
      $.toast({
        text : '<?php echo $message;?>',
        heading : '<?php echo $heading;?>',
        position : 'top-right',
        width : 'auto',
        showHideTransition : 'slide',
        icon: 'info',
        hideAfter: 5000
      })
    });
  </script>
  <?php } ?>
  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800">Data Kasus Covid-19</h1>
  <p class="mb-4">Data berikut merupakan kumpulan Kasus Covid-19 - Kota Kendari</p>
  <hr>
  
  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <!-- <a href="#" class="btn btn-primary btn-icon-split btn-sm" data-toggle="modal" data-target="#casesModal">
        <span class="icon text-white-50">
          <i class="fas fa-plus"></i>
        </span>
        <span class="text">Tambah Data</span>
      </a> -->

      <!-- cases Modal-->
      <!-- <div class="modal fade" id="casesModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Tambah Kasus Baru</h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <?php echo form_open_multipart("cases/input")?>
            <div class="modal-body">
              <div class="form-group">
                <label for=""><b>Lokasi Kasus</b></label>
                <input type="text" class="form-control" placeholder="Masukkan Lokasi Kasus..." name="cases_location" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>Titik Kordinat Kasus</b></label>
                <input type="text" class="form-control" placeholder="Masukkan Kordinat Kasus..." name="cases_coordinate" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>Tanggal Kasus</b></label>
                <input type="date" class="form-control" placeholder="Masukkan Kordinat Kasus..." name="cases_date" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>Dinas Kasus</b></label>
                <select name="cases_opd" class="form-control" required>
                  <option value="">.:: Pilih Dinas ::.</option>
                  <option value="1">Dinas Kesehatan</option>
                </select>
              </div>
              
              <div class="form-group">
                <label for=""><b>Keterangan Kasus</b></label>
                <textarea class="form-control" name="cases_description" placeholder="Keterangan Kasus..."></textarea>
              </div>
              
              <div class="form-group">
                <label for=""><b>Foto Kasus</b></label>
                <input type="file" class="form-control" name="userfile">
              </div>
              <hr>
              <div class="form-group">
                <label for=""><b>Jumlah Sosialisasi & Himbauan</b></label>
                <input type="number" class="form-control" placeholder="Jumlah Sosial dan Himbauan..." name="cases_socialization_qty" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>Jumlah Screening</b></label>
                <input type="number" class="form-control" placeholder="Jumlah Screening..." name="cases_screening_qty" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>Jumlah Pembagian Masker</b></label>
                <input type="number" class="form-control" placeholder="Jumlah Pembagian Masker..." name="cases_mask_distribution_qty" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>Jumlah Pembagian APD</b></label>
                <input type="number" class="form-control" placeholder="Jumlah Pembagian APD..." name="cases_apd_distribution_qty" required="required">
              </div>
              
            </div>
            <div class="modal-footer">
              <button class="btn btn-primary" type="submit">Tambah</button>
            <?php echo form_close(); ?>
              <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
              
            </div>
          </div>
        </div>
      </div> -->


      <a href="<?php echo site_url('cases')?>" class="btn btn-success btn-icon-split btn-sm">
        <span class="icon text-white-50">
          <i class="fa fa-refresh"></i>
        </span>
        <span class="text">Refresh Halaman</span>
      </a>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th style="width: 5%;">No</th>
              <th style="width: 10%;">#</th>
              <th>Kecamatan</th>
              <th>Jumlah ODP</th>
              <th>ODP Selesai</th>
              <th style="background-color:yellow;color:black;">ODP Proses</th>
              <th>Jumlah PDP</th>
              <th>PDP Selesai</th>
              <th style="background-color:orange;color:black;">PDP Proses</th>
              <th style="background-color:red;color:black;">Positif Covid-19</th>
            </tr>
          </thead>
          
          <tbody>
            <?php $no=1; foreach($cases as $key){?>
            <tr>
              <td><?php echo $no;?></td>
              <td>
               
                <a href="#" class="btn btn-warning btn-icon-split btn-sm" data-toggle="modal" data-target="#casesEditModal<?php echo $key->cases_id?>">
                  <span class="text">
                    <i class="fa fa-edit"></i>
                  </span>
                </a>
               


              </td>
              <td><?php echo $key->sub_district_name?></td>
              <td><?php echo $key->cases_odp?></td>
              <td><?php echo $key->cases_odp_finish?></td>
              <td style="background-color:yellow;color:black;"><?php echo "<b>".$key->cases_odp_process."</b>"?></td>
              <td><?php echo $key->cases_pdp?></td>
              <td><?php echo $key->cases_pdp_finish?></td>
              <td style="background-color:orange;color:black;"><?php echo  "<b>".$key->cases_pdp_process."</b>"?></td>
              <td style="background-color:red;color:black;"><?php echo  "<b>".$key->cases_positif."</b>"?></td>
              
            </tr>

            <!-- Looping Modal Area -->

            <!-- cases Modal Edit-->
            <div class="modal fade" id="casesEditModal<?php echo $key->cases_id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Kasus di <?php echo $key->sub_district_name?></h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                  </div>
                  <?php echo form_open_multipart("cases/edit")?>
                  <div class="modal-body">
                    <div class="form-group">
                      <label for=""><b>Total ODP</b></label>
                      <input type="hidden" class="form-control" name="cases_id" value="<?php echo $key->cases_id?>">
                      <input type="hidden" class="form-control" name="sub_district_id" value="<?php echo $key->sub_district_id?>">
                      <input type="hidden" class="form-control" name="sub_district_name" value="<?php echo $key->sub_district_name?>">
                      <input type="number" class="form-control" placeholder="Masukkan ODP Kasus..." name="cases_odp" value="<?php echo $key->cases_odp?>" required="required">
                    </div>
                    
                    <div class="form-group">
                      <label for=""><b>ODP Selesai</b></label>
                      <input type="number" class="form-control" placeholder="Masukkan ODP Kasus Selesai..." name="cases_odp_finish" required="required" value="<?php echo $key->cases_odp_finish?>">
                    </div>

                    <div class="form-group">
                      <label for=""><b>ODP Proses</b></label>
                      <input type="number" class="form-control" placeholder="Masukkan ODP Kasus Proses..." name="cases_odp_process" required="required" value="<?php echo $key->cases_odp_process?>">
                    </div>
                    <hr>
                    <div class="form-group">
                      <label for=""><b>Total PDP</b></label>
                      <input type="number" class="form-control" placeholder="Masukkan PDP Kasus..." name="cases_pdp" value="<?php echo $key->cases_pdp?>" required="required">
                    </div>

                    <div class="form-group">
                      <label for=""><b>PDP Selesai</b></label>
                      <input type="number" class="form-control" placeholder="Masukkan PDP Kasus Selesai..." name="cases_pdp_finish" required="required" value="<?php echo $key->cases_pdp_finish?>">
                    </div>

                    <div class="form-group">
                      <label for=""><b>PDP Proses</b></label>
                      <input type="number" class="form-control" placeholder="Masukkan PDP Kasus Proses..." name="cases_pdp_process" required="required" value="<?php echo $key->cases_pdp_process?>">
                    </div>

                    <div class="form-group">
                      <label for=""><b>Positif Covid-19</b></label>
                      <input type="number" class="form-control" placeholder="Masukkan Kasus Positif..." name="cases_positif" required="required" value="<?php echo $key->cases_positif?>">
                    </div>
                    
                    
                  </div>
                  <div class="modal-footer">
                    <button class="btn btn-warning" type="submit">Edit</button>
                  <?php echo form_close(); ?>
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    
                  </div>
                </div>
              </div>
            </div>

            <!-- cases Modal Remove-->
            <div class="modal fade" id="casesRemoveModal<?php echo $key->cases_id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Hapus Kasus</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                  </div>
                  <?php echo form_open("cases/delete")?>
                  <div class="modal-body">
                    Apakah anda yakin akan menghapus data Kasus <b><?php echo $key->cases_name ?></b> ?
                    <input type="hidden" class="form-control" name="cases_id" value="<?php echo $key->cases_id?>">
                    <input type="hidden" class="form-control" name="cases_location" value="<?php echo $key->cases_location?>">
                    <input type="hidden" class="form-control" name="cases_photo" value="<?php echo $key->cases_photo?>">
                  </div>
                  <div class="modal-footer">
                    <button class="btn btn-danger" type="submit">Hapus</button>
                  <?php echo form_close(); ?>
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    
                  </div>
                </div>
              </div>
            </div>



            <!-- cases Modal Remove-->
            <div class="modal fade" id="casesDetailModal<?php echo $key->cases_id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Foto Kasus</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                  </div>
                 
                  <div class="modal-body">
                    <center>
                      <img src="<?php echo base_url()?>upload/cases/social/<?php echo $key->cases_photo?>" width="300">
                      <hr> <b><?php echo $key->cases_location?></b>
                    </center>
                  </div>
                  <div class="modal-footer">
                    
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    
                  </div>
                </div>
              </div>
            </div>

            <!-- End Looping -->


            <?php $no++; } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->
<div class="container-fluid">
  <?php 
    if($this->session->flashdata('add')){ 
      $message = $this->session->flashdata('add');
      $heading = '#Tambah Penyemprotan Jalan';
    }else if($this->session->flashdata('update')){ 
      $message = $this->session->flashdata('update');
      $heading = '#Update Penyemprotan Jalan';
    }else if($this->session->flashdata('delete')){
      $message = $this->session->flashdata('delete');
      $heading = '#Delete Penyemprotan Jalan';  
    } 
  ?>
  <?php if(isset($message)){ ?>
  <script>
    $(document).ready(function(){
      $.toast({
        text : '<?php echo $message;?>',
        heading : '<?php echo $heading;?>',
        position : 'top-right',
        width : 'auto',
        showHideTransition : 'slide',
        icon: 'info',
        hideAfter: 5000
      })
    });
  </script>
  <?php } ?>
  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800">Data Titik Penyemprotan Jalan : <?php echo $spraying_road[0]->spraying_road_location?></h1>
  <p class="mb-4">Data berikut merupakan kumpulan Penyemprotan Jalan - Kota Kendari</p>
  
  
  
  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <a href="<?php echo site_url('spraying_road')?>" class="btn btn-warning btn-icon-split btn-sm">
        <span class="icon text-white-50">
          <i class="fa fa-arrow-left"></i>
        </span>
        <span class="text">Kembali</span>
      </a>
      <a href="#" class="btn btn-primary btn-icon-split btn-sm" data-toggle="modal" data-target="#spraying_roadModal">
        <span class="icon text-white-50">
          <i class="fas fa-plus"></i>
        </span>
        <span class="text">Tambah Data</span>
      </a>

      <!-- spraying_road Modal-->
      <div class="modal fade" id="spraying_roadModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Tambah Titik Penyemprotan Jalan Baru</h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <?php echo form_open_multipart("spraying_road/input_detail")?>
            <div class="modal-body">
              <div class="form-group">
                <label for=""><b>Titik Kordinat Penyemprotan</b></label>
                <input type="hidden" class="form-control" name="spraying_road_id" required="required" value="<?php echo $spraying_road[0]->spraying_road_id ?>">
                <input type="text" class="form-control" name="coordinate" required="required" placeholder="Masukkan Titik Kordinat Penyemprotan Jalan">
                
              </div>
              <div class="form-group">
                <label for=""><b>Nama Titik</b></label>
                <input type="text" class="form-control" placeholder="Masukkan Nama Titik..." name="coordinate_name" required="required">
              </div>
              
              
            </div>
            <div class="modal-footer">
              <button class="btn btn-primary" type="submit">Tambah</button>
            <?php echo form_close(); ?>
              <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
              
            </div>
          </div>
        </div>
      </div>


      <a href="<?php echo site_url('spraying_road/detail/'.$spraying_road[0]->spraying_road_id)?>" class="btn btn-success btn-icon-split btn-sm">
        <span class="icon text-white-50">
          <i class="fa fa-refresh"></i>
        </span>
        <span class="text">Refresh Halaman</span>
      </a>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th style="width: 5%;">No</th>
              <th style="width: 19%;">#</th>
              <th>Kordinat Penyemprotan</th>
              <th>Nama Titik</th>
            </tr>
          </thead>
          
          <tbody>
            <?php $no=1; foreach($spraying_road_detail as $key){?>
            <tr>
              <td><?php echo $no;?></td>
              <td>
                
                <a href="#" class="btn btn-warning btn-icon-split btn-sm" data-toggle="modal" data-target="#spraying_road_detailEditModal<?php echo $key->spraying_road_detail_id?>">
                  <span class="text">
                    <i class="fa fa-edit"></i>
                  </span>
                </a>
                <a href="#" class="btn btn-danger btn-icon-split btn-sm" data-toggle="modal" data-target="#spraying_road_detailRemoveModal<?php echo $key->spraying_road_detail_id?>">
                  <span class="text">
                    <i class="fa fa-trash"></i>
                  </span>
                </a>
                


              </td>
              <td><?php echo $key->coordinate?></td>
              <td><?php echo $key->coordinate_name?></td>
              
            </tr>

            <!-- Looping Modal Area -->

            <!-- spraying_road Modal Edit-->
            <div class="modal fade" id="spraying_road_detailEditModal<?php echo $key->spraying_road_detail_id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Penyemprotan Jalan</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                  </div>
                  <?php echo form_open_multipart("spraying_road/edit_detail")?>
                  <div class="modal-body">
                    <div class="form-group">
                      <label for=""><b>Kendaraan yang Diperikas</b></label>
                      <input type="hidden" class="form-control" name="spraying_road_detail_id" required="required" value="<?php echo $key->spraying_road_detail_id ?>">
                      <input type="hidden" class="form-control" name="spraying_road_id" required="required" value="<?php echo $spraying_road[0]->spraying_road_id ?>">
                      <input type="text" class="form-control" name="coordinate" required="required" palceholder="Masukkan Titik Penyemprotan... " value="<?php echo $key->coordinate ?>">
                      
                    </div>
                    <div class="form-group">
                      <label for=""><b>Nama Titik Penyemprotan</b></label>
                      <input type="text" class="form-control" placeholder="Masukkan Nama Titik Penyemprotan..." name="coordinate_name" required="required" value="<?php echo $key->coordinate_name ?>">
                    </div>
                    
                    
                    
                  </div>
                  <div class="modal-footer">
                    <button class="btn btn-warning" type="submit">Edit</button>
                  <?php echo form_close(); ?>
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    
                  </div>
                </div>
              </div>
            </div>

            <!-- spraying_road Modal Remove-->
            <div class="modal fade" id="spraying_road_detailRemoveModal<?php echo $key->spraying_road_detail_id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Hapus Titik Penyemprotan Jalan</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                  </div>
                  <?php echo form_open("spraying_road/delete_detail")?>
                  <div class="modal-body">
                    Apakah anda yakin akan menghapus data Penyemprotan Jalan <b><?php echo $key->coordinate_name ?></b> ?
                    <input type="hidden" class="form-control" name="spraying_road_detail_id" value="<?php echo $key->spraying_road_detail_id?>">
                  </div>
                  <div class="modal-footer">
                    <button class="btn btn-danger" type="submit">Hapus</button>
                  <?php echo form_close(); ?>
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    
                  </div>
                </div>
              </div>
            </div>



            

            <!-- End Looping -->


            <?php $no++; } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->
<div class="container-fluid">
  <?php 
    if($this->session->flashdata('add')){ 
      $message = $this->session->flashdata('add');
      $heading = '#Tambah Penyemprotan';
    }else if($this->session->flashdata('update')){ 
      $message = $this->session->flashdata('update');
      $heading = '#Update Penyemprotan';
    }else if($this->session->flashdata('delete')){
      $message = $this->session->flashdata('delete');
      $heading = '#Delete Penyemprotan';  
    } 
  ?>
  <?php if(isset($message)){ ?>
  <script>
    $(document).ready(function(){
      $.toast({
        text : '<?php echo $message;?>',
        heading : '<?php echo $heading;?>',
        position : 'top-right',
        width : 'auto',
        showHideTransition : 'slide',
        icon: 'info',
        hideAfter: 5000
      })
    });
  </script>
  <?php } ?>
  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800">Data Penyemprotan Fasilitas Kota</h1>
  <p class="mb-4">Data berikut merupakan kumpulan Penyemprotan Disinfektan - Kota Kendari</p>
  <a href="<?php echo site_url('spraying')?>" class="btn btn-warning btn-icon-split btn-sm">  
    <span class="text">Data Penyemprotan Disinfektan Fasilitas Kota (Dinas Kesehatan & BPBD)</span>
  </a>
  <a href="<?php echo site_url('spraying_road')?>" class="btn btn-secondary btn-icon-split btn-sm">  
    <span class="text">Data Penyemprotan Disinfektan Jalan (Dinas Kebakaran)</span>
  </a>
  <hr>
  
  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <a href="#" class="btn btn-primary btn-icon-split btn-sm" data-toggle="modal" data-target="#sprayingModal">
        <span class="icon text-white-50">
          <i class="fas fa-plus"></i>
        </span>
        <span class="text">Tambah Data</span>
      </a>

      <!-- spraying Modal-->
      <div class="modal fade" id="sprayingModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Tambah Penyemprotan Baru</h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <?php echo form_open_multipart("spraying/input")?>
            <div class="modal-body">
              <div class="form-group">
                <label for=""><b>Lokasi Penyemprotan</b></label>
                <input type="text" class="form-control" placeholder="Masukkan Lokasi Penyemprotan..." name="spraying_location" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>Titik Kordinat Penyemprotan</b></label>
                <input type="text" class="form-control" placeholder="Masukkan Kordinat Penyemprotan..." name="spraying_coordinate" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>Tanggal Penyemprotan</b></label>
                <input type="date" class="form-control" placeholder="Masukkan Kordinat Penyemprotan..." name="spraying_date" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>Dinas Penyemprotan</b></label>
                <select name="spraying_opd" class="form-control" required>
                  <option value="">.:: Pilih Dinas ::.</option>
                  <option value="1">Dinas Kesehatan</option>
                  <option value="2">BPBD</option>
                </select>
              </div>
              
              <div class="form-group">
                <label for=""><b>Keterangan Penyemprotan</b></label>
                <textarea class="form-control" name="spraying_description" placeholder="Keterangan Penyemprotan..."></textarea>
              </div>
              <div class="form-group">
                <label for=""><b>Fasilitas Penyemprotan</b></label>
                <select name="facilities_id" class="form-control" required>
                  <option value="">.:: Pilih Fasilitas ::.</option>
                  <?php foreach ($facilities as $f){?>
                    <option value="<?php echo $f->facilities_id;?>"><?php echo $f->facilities_name;?></option>
                  <?php }?>
                </select>
              </div>
              <div class="form-group">
                <label for=""><b>Foto Penyemprotan</b></label>
                <input type="file" class="form-control" name="userfile">
              </div>
              
            </div>
            <div class="modal-footer">
              <button class="btn btn-primary" type="submit">Tambah</button>
            <?php echo form_close(); ?>
              <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
              
            </div>
          </div>
        </div>
      </div>


      <a href="<?php echo site_url('spraying')?>" class="btn btn-success btn-icon-split btn-sm">
        <span class="icon text-white-50">
          <i class="fa fa-refresh"></i>
        </span>
        <span class="text">Refresh Halaman</span>
      </a>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th style="width: 5%;">No</th>
              <th style="width: 19%;">#</th>
              <th>Lokasi</th>
              <th>Fasilitas</th>
              <th>OPD</th>
            </tr>
          </thead>
          
          <tbody>
            <?php $no=1; foreach($spraying as $key){?>
            <tr>
              <td><?php echo $no;?></td>
              <td>
                <a href="#" class="btn btn-info btn-icon-split btn-sm" data-toggle="modal" data-target="#sprayingDetailModal<?php echo $key->spraying_id?>">
                  <span class="text">
                    <i class="fa fa-image"></i>
                  </span>
                </a>
                <a href="#" class="btn btn-warning btn-icon-split btn-sm" data-toggle="modal" data-target="#sprayingEditModal<?php echo $key->spraying_id?>">
                  <span class="text">
                    <i class="fa fa-edit"></i>
                  </span>
                </a>
                <a href="#" class="btn btn-danger btn-icon-split btn-sm" data-toggle="modal" data-target="#sprayingRemoveModal<?php echo $key->spraying_id?>">
                  <span class="text">
                    <i class="fa fa-trash"></i>
                  </span>
                </a>


              </td>
              <td><?php echo $key->spraying_location?></td>
              <td><?php echo $key->facilities_name?></td>
              <td>
                <?php 
                  if($key->spraying_opd==1){
                    echo "Dinas Kesehatan";
                  }else{
                    echo "BPBD";
                  } 
                ?>
              </td>
            </tr>

            <!-- Looping Modal Area -->

            <!-- spraying Modal Edit-->
            <div class="modal fade" id="sprayingEditModal<?php echo $key->spraying_id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Penyemprotan</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                  </div>
                  <?php echo form_open_multipart("spraying/edit")?>
                  <div class="modal-body">
                    <div class="form-group">
                      <label for=""><b>Nama Penyemprotan</b></label>
                      <input type="hidden" class="form-control" name="spraying_id" value="<?php echo $key->spraying_id?>">
                      <input type="hidden" class="form-control" name="spraying_photo" value="<?php echo $key->spraying_photo?>">
                      <input type="text" class="form-control" placeholder="Masukkan Lokasi Penyemprotan..." name="spraying_location" value="<?php echo $key->spraying_location?>" required="required">
                    </div>
                    
                    <div class="form-group">
                      <label for=""><b>Titik Kordinat Penyemprotan</b></label>
                      <input type="text" class="form-control" placeholder="Masukkan Kordinat Penyemprotan..." name="spraying_coordinate" required="required" value="<?php echo $key->spraying_coordinate;?>">
                    </div>
                    <div class="form-group">
                      <label for=""><b>Tanggal Penyemprotan</b></label>
                      <input type="date" class="form-control" placeholder="Masukkan Kordinat Penyemprotan..." name="spraying_date" required="required" value="<?php echo $key->spraying_date;?>">
                    </div>
                    <div class="form-group">
                      <label for=""><b>Dinas Penyemprotan</b></label>
                      <select name="spraying_opd" class="form-control" required>
                        <option value="">.:: Pilih Dinas ::.</option>
                        <?php if($key->spraying_opd==1){?>
                        <option value="1" selected>Dinas Kesehatan</option>
                        <option value="2">BPBD</option>
                        <?php }else{ ?>
                        <option value="1">Dinas Kesehatan</option>
                        <option value="2" selected>BPBD</option>
                        <?php } ?>
                      </select>
                    </div>
                    
                    <div class="form-group">
                      <label for=""><b>Keterangan Penyemprotan</b></label>
                      <textarea class="form-control" name="spraying_description" placeholder="Keterangan Penyemprotan..."><?php echo $key->spraying_description; ?></textarea>
                    </div>
                    <div class="form-group">
                      <label for=""><b>Fasilitas Penyemprotan</b></label>
                      <select name="facilities_id" class="form-control" required>
                        <option value="">.:: Pilih Fasilitas ::.</option>
                        <?php foreach ($facilities as $fx){
                            if($fx->facilities_id==$key->facilities_id){
                        ?>
                          <option value="<?php echo $fx->facilities_id;?>" selected><?php echo $fx->facilities_name;?></option>
                        <?php }else{ ?>
                          <option value="<?php echo $fx->facilities_id;?>"><?php echo $fx->facilities_name;?></option>
                        <?php } }?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for=""><b>Foto Penyemprotan</b></label>
                      <input type="file" class="form-control" name="userfile">
                    </div>
                    
                  </div>
                  <div class="modal-footer">
                    <button class="btn btn-warning" type="submit">Edit</button>
                  <?php echo form_close(); ?>
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    
                  </div>
                </div>
              </div>
            </div>

            <!-- spraying Modal Remove-->
            <div class="modal fade" id="sprayingRemoveModal<?php echo $key->spraying_id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Hapus Penyemprotan</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                  </div>
                  <?php echo form_open("spraying/delete")?>
                  <div class="modal-body">
                    Apakah anda yakin akan menghapus data Penyemprotan <b><?php echo $key->spraying_name ?></b> ?
                    <input type="hidden" class="form-control" name="spraying_id" value="<?php echo $key->spraying_id?>">
                    <input type="hidden" class="form-control" name="spraying_location" value="<?php echo $key->spraying_location?>">
                    <input type="hidden" class="form-control" name="spraying_photo" value="<?php echo $key->spraying_photo?>">
                  </div>
                  <div class="modal-footer">
                    <button class="btn btn-danger" type="submit">Hapus</button>
                  <?php echo form_close(); ?>
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    
                  </div>
                </div>
              </div>
            </div>



            <!-- spraying Modal Remove-->
            <div class="modal fade" id="sprayingDetailModal<?php echo $key->spraying_id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Foto Penyemprotan</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                  </div>
                 
                  <div class="modal-body">
                    <center>
                      <img src="<?php echo base_url()?>upload/spraying/<?php echo $key->spraying_photo?>" width="300">
                      <hr> <b><?php echo $key->spraying_location?></b>
                    </center>
                  </div>
                  <div class="modal-footer">
                    
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    
                  </div>
                </div>
              </div>
            </div>

            <!-- End Looping -->


            <?php $no++; } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->
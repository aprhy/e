<div class="container-fluid">
  <?php 
    if($this->session->flashdata('add')){ 
      $message = $this->session->flashdata('add');
      $heading = '#Tambah Absen Pagi';
    }else if($this->session->flashdata('update')){ 
      $message = $this->session->flashdata('update');
      $heading = '#Update Absen Pagi';
    }else if($this->session->flashdata('delete')){
      $message = $this->session->flashdata('delete');
      $heading = '#Delete Absen Pagi';  
    } 
  ?>
  <?php if(isset($message)){ ?>
  <script>
    $(document).ready(function(){
      $.toast({
        text : '<?php echo $message;?>',
        heading : '<?php echo $heading;?>',
        position : 'top-right',
        width : 'auto',
        showHideTransition : 'slide',
        icon: 'info',
        hideAfter: 5000
      })
    });
  </script>
  <?php } ?>
  <!-- Page Heading -->
  <?php if($this->uri->segment(2)==""){?>
  <h1 class="h3 mb-2 text-gray-800">Data Absen Pagi Hari Ini </h1>
  <?php }elseif($this->uri->segment(2)=="allData"){ ?>
  <h1 class="h3 mb-2 text-gray-800">Semua Data Absen Pagi</h1>
  <?php }elseif($this->uri->segment(2)=="allDataDetail"){ ?>
  <h1 class="h3 mb-2 text-gray-800">Semua Data Absen Pagi : <b><?php echo tgl_indo($this->uri->segment(3));?></b></h1>
  <?php }elseif($this->uri->segment(2)=="sore"){ ?>
  <h1 class="h3 mb-2 text-gray-800">Data Absen Sore Hari Ini</h1>
  <?php }elseif($this->uri->segment(2)=="allDataSoreDetail"){ ?>
  <h1 class="h3 mb-2 text-gray-800">Semua Data Absen Sore : <b><?php echo tgl_indo($this->uri->segment(3))?></b></h1>
  <?php }elseif($this->uri->segment(2)=="allDataSore"){ ?>
  <h1 class="h3 mb-2 text-gray-800">Semua Data Absen Sore</h1>
  <?php }?>
  <p class="mb-4"><?php echo $this->session->userdata('skpd_id');?>Data berikut merupakan kumpulan Absen : <?php echo $nama_skpd[0]->nama?></p>
  <hr>

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      
      <?php if($this->uri->segment(2)==""){?>
        <a href="<?php echo site_url('attendance')?>" class="btn btn-danger btn-icon-split btn-sm">
          <span class="icon text-white-50">
            <i class="fa fa-calendar-check-o"></i>
          </span>
          <span class="text">Data Absen Pagi Hari Ini</span>
        </a>
        <a href="<?php echo site_url('attendance/allData')?>" class="btn btn-primary btn-icon-split btn-sm">
          <span class="icon text-white-50">
            <i class="fa fa-calendar-check-o"></i>
          </span>
          <span class="text">Semua Data Absen Pagi</span>
        </a>
      <?php }elseif($this->uri->segment(2)=="allData"){ ?>
        <a href="<?php echo site_url('attendance')?>" class="btn btn-danger btn-icon-split btn-sm">
          <span class="icon text-white-50">
            <i class="fa fa-calendar-check-o"></i>
          </span>
          <span class="text">Data Absen Pagi Hari Ini</span>
        </a>
        <a href="<?php echo site_url('attendance/allData')?>" class="btn btn-primary btn-icon-split btn-sm">
          <span class="icon text-white-50">
            <i class="fa fa-calendar-check-o"></i>
          </span>
          <span class="text">Semua Data Absen Pagi</span>
        </a>
      <?php }elseif($this->uri->segment(2)=="allDataDetail"){ ?>
        <a href="<?php echo site_url('attendance/allData')?>" class="btn btn-warning btn-icon-split btn-sm">
          <span class="icon text-white-50">
            <i class="fa fa-arrow-left"></i>
          </span>
          <span class="text">Kembali</span>
        </a>
        
      <?php }elseif($this->uri->segment(2)=="sore"){ ?>
        <a href="<?php echo site_url('attendance/sore')?>" class="btn btn-danger btn-icon-split btn-sm">
          <span class="icon text-white-50">
            <i class="fa fa-calendar-check-o"></i>
          </span>
          <span class="text">Data Absen Sore Hari Ini</span>
        </a>
        <a href="<?php echo site_url('attendance/allDataSore')?>" class="btn btn-primary btn-icon-split btn-sm">
          <span class="icon text-white-50">
            <i class="fa fa-calendar-check-o"></i>
          </span>
          <span class="text">Semua Data Absen Sore</span>
        </a>
      <?php }elseif($this->uri->segment(2)=="allDataSoreDetail"){ ?>
        
        <a href="<?php echo site_url('attendance/allDataSore')?>" class="btn btn-warning btn-icon-split btn-sm">
          <span class="icon text-white-50">
            <i class="fa fa-arrow-left"></i>
          </span>
          <span class="text">Kembali</span>
        </a>
      <?php }elseif($this->uri->segment(2)=="allDataSore"){ ?>
        <a href="<?php echo site_url('attendance/sore')?>" class="btn btn-danger btn-icon-split btn-sm">
          <span class="icon text-white-50">
            <i class="fa fa-calendar-check-o"></i>
          </span>
          <span class="text">Data Sore Hari Ini</span>
        </a>
        <a href="<?php echo site_url('attendance/allDataSore')?>" class="btn btn-primary btn-icon-split btn-sm">
          <span class="icon text-white-50">
            <i class="fa fa-calendar-check-o"></i>
          </span>
          <span class="text">Semua Data Absen Sore</span>
        </a>
      <?php }?>

      <?php if($this->session->userdata('group_id')==1){?>

      | 
      <a href="#" class="btn btn-danger btn-icon-split btn-sm" data-toggle="modal" data-target="#employeeModalFilter">
        <span class="icon text-white-50">
          <i class="fas fa-filter"></i>
        </span>
        <span class="text">Filter Berdasarkan SKPD</span>
      </a>

      <div class="modal fade" id="employeeModalFilter" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Filter Berdasarkan SKPD</h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <?php echo form_open_multipart("attendance/reindex")?>
            <div class="modal-body">
              
              
              <div class="form-group">
                <label for=""><b>SKPD</b></label>
                <select id="skpd" class="form-control" name="skpd" style="width:100%" required>
                  <option value="">.:: Pilih SKPD ::.</option>
                  <?php foreach($skpd as $s){ ?>
                  <option value="<?php echo $s->kd_skpd;?>"><?php echo $s->nama;?></option>
                  <?php } ?>
                </select>
                <input type="hidden" name="url_seg2" value="<?php echo $this->uri->segment(2);?>">
                <input type="hidden" name="url_seg3" value="<?php echo $this->uri->segment(3);?>">

              </div>
              
              
            </div>
            <div class="modal-footer">
              <button class="btn btn-danger" type="submit">Filter</button>
            <?php echo form_close(); ?>
              <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
              
            </div>
          </div>
        </div>
      </div>

      <?php }?>
      
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th style="width: 5%;">No</th>
              <th>Nama</th>
              <th>NIP</th>
              <th>Jam Absen</th>
              <th>Status</th>
              <th>Keterangan Lainnya</th>
              <th>Status Berkantor</th>
            </tr>
          </thead>
          
          <tbody>
            <?php $no=1; foreach($attendance as $key){?>
            <tr>
              <td><?php echo $no;?></td>
              <td><?php echo $key->nama?> <br> <span class="badge badge-primary"><?php echo $key->nama_skpd;?></span></td>
              <td><?php echo $key->nip?></td>
              <td><?php echo $key->checkin_time?></td>
              <td>
                <?php 
                  if($key->checkin_status==1){
                    echo '<span class="badge badge-success">Hadir</span>';
                  }elseif($key->checkin_status==2){
                    echo '<span class="badge badge-warning">Terlambat</span>';
                  }else{
                    echo '<span class="badge badge-danger">Alpa</span>';
                  }
                ?>
              </td>
              <td>
                <?php 
                  if($key->sick_status==0){
                    echo '<span class="badge badge-success">Sehat</span>';
                  }else{
                    echo '<span class="badge badge-danger">Sakit</span>';
                  }
                ?>
              </td>
              <td>
                <?php if($key->status==1){?>
                  <span class="badge badge-success">Kantor</span></td>
                <?php }elseif($key->status==2){?>
                  <span class="badge badge-danger">WFH</span></td>
                <?php }elseif($key->status==3){?>
                  <span class="badge badge-primary">Lapangan</span></td>
                <?php }else{?>
                  <span class="badge badge-info">Upacara</span></td>
                <?php }?>
            </tr>

            <!-- Looping Modal Area -->

            <!-- attendance Modal Edit-->
            <div class="modal fade" id="attendanceEditModal<?php echo $key->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Absen Pagi</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                  </div>
                  <?php echo form_open_multipart("attendance/edit")?>
                  <div class="modal-body">
                    <div class="form-group">
                      <label for=""><b>Nama Absen Pagi</b></label>
                      <input type="hidden" class="form-control" name="id" value="<?php echo $key->id?>">
                      <input type="text" class="form-control" placeholder="Masukkan Nama Absen Pagi..." name="nama" value="<?php echo $key->nama?>" required="required">
                    </div>
                    <div class="form-group">
                      <label for=""><b>Satuan Absen Pagi</b></label>
                      <input type="text" class="form-control" placeholder="Masukkan Satuan Absen Pagi..." name="nip" value="<?php echo $key->nip?>" required="required">
                    </div>
                    
                    
                  </div>
                  <div class="modal-footer">
                    <button class="btn btn-warning" type="submit">Edit</button>
                  <?php echo form_close(); ?>
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    
                  </div>
                </div>
              </div>
            </div>

            <!-- attendance Modal Remove-->
            <div class="modal fade" id="attendanceRemoveModal<?php echo $key->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Hapus Absen Pagi</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                  </div>
                  <?php echo form_open("attendance/delete")?>
                  <div class="modal-body">
                    Apakah anda yakin akan menghapus data Absen Pagi <b><?php echo $key->nama ?></b> ?
                    <input type="hidden" class="form-control" name="id" value="<?php echo $key->id?>">
                    <input type="hidden" class="form-control" name="nama" value="<?php echo $key->nama?>">
                  </div>
                  <div class="modal-footer">
                    <button class="btn btn-danger" type="submit">Hapus</button>
                  <?php echo form_close(); ?>
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    
                  </div>
                </div>
              </div>
            </div>



            
          

            <!-- End Looping -->


            <?php $no++; } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->
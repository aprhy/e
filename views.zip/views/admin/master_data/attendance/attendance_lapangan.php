<div class="container-fluid">
  <?php 
    if($this->session->flashdata('add')){ 
      $message = $this->session->flashdata('add');
      $heading = '#Tambah Absen Pagi Lapangan';
    }else if($this->session->flashdata('update')){ 
      $message = $this->session->flashdata('update');
      $heading = '#Update Absen Pagi Lapangan';
    }else if($this->session->flashdata('delete')){
      $message = $this->session->flashdata('delete');
      $heading = '#Delete Absen Pagi Lapangan';  
    } 
  ?>
  <?php if(isset($message)){ ?>
  <script>
    $(document).ready(function(){
      $.toast({
        text : '<?php echo $message;?>',
        heading : '<?php echo $heading;?>',
        position : 'top-right',
        width : 'auto',
        showHideTransition : 'slide',
        icon: 'info',
        hideAfter: 5000
      })
    });
  </script>
  <?php } ?>
  <!-- Page Heading allDataLapanganDetail-->
  <?php if($this->uri->segment(2)=="pagi_lapangan"){?>
  <h1 class="h3 mb-2 text-gray-800">Data Absen Pagi Lapangan Hari Ini </h1>
  <?php }elseif($this->uri->segment(2)=="allDataLapangan"){?>
  <h1 class="h3 mb-2 text-gray-800">Semua Data Absen Pagi Lapangan</h1>
  <?php }elseif($this->uri->segment(2)=="allDataLapanganDetail"){?>
  <h1 class="h3 mb-2 text-gray-800">Semua Data Absen Pagi Lapangan : <b><?php echo tgl_indo($this->uri->segment(3));?></b></h1>
  <?php }elseif($this->uri->segment(2)=="sore_lapangan"){?>
  <h1 class="h3 mb-2 text-gray-800">Data Absen Sore Lapangan Hari Ini </h1>
  <?php }elseif($this->uri->segment(2)=="allDataLapanganSore"){?>
  <h1 class="h3 mb-2 text-gray-800">Semua Data Absen Sore Lapangan</h1>
  <?php }elseif($this->uri->segment(2)=="allDataLapanganDetailSore"){?>
  <h1 class="h3 mb-2 text-gray-800">Semua Data Absen Sore Lapangan : <b><?php echo tgl_indo($this->uri->segment(3));?></b></h1>
  <?php } ?>
  <p class="mb-4">Data berikut merupakan kumpulan Absen Lapangan ASN : <?php echo $nama_skpd[0]->nama?></p>
  <hr>

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      
      <?php if($this->uri->segment(2)=='allDataLapanganDetail'){?>
        <a href="<?php echo site_url('attendance/allDataLapangan')?>" class="btn btn-warning btn-icon-split btn-sm">
          <span class="icon text-white-50">
            <i class="fa fa-arrow-left"></i>
          </span>
          <span class="text">Kembali</span>
        </a>
      <?php }elseif($this->uri->segment(2)=='pagi_lapangan' OR $this->uri->segment(2)=='allDataLapangan' ){?>
        <a href="<?php echo site_url('attendance/pagi_lapangan')?>" class="btn btn-danger btn-icon-split btn-sm">
          <span class="icon text-white-50">
            <i class="fa fa-calendar-check-o"></i>
          </span>
          <span class="text">Data Absen Pagi Lapangan Hari Ini</span>
        </a>
        <a href="<?php echo site_url('attendance/allDataLapangan')?>" class="btn btn-primary btn-icon-split btn-sm">
          <span class="icon text-white-50">
            <i class="fa fa-calendar-check-o"></i>
          </span>
          <span class="text">Semua Data Absen Pagi Lapangan</span>
        </a>
      <?php }elseif($this->uri->segment(2)=='allDataLapanganDetailSore'){?>
        <a href="<?php echo site_url('attendance/allDataLapanganSore')?>" class="btn btn-warning btn-icon-split btn-sm">
          <span class="icon text-white-50">
            <i class="fa fa-arrow-left"></i>
          </span>
          <span class="text">Kembali</span>
        </a>
      <?php }elseif($this->uri->segment(2)=='sore_lapangan' OR $this->uri->segment(2)=='allDataLapanganSore' ){?>
        <a href="<?php echo site_url('attendance/sore_lapangan')?>" class="btn btn-danger btn-icon-split btn-sm">
          <span class="icon text-white-50">
            <i class="fa fa-calendar-check-o"></i>
          </span>
          <span class="text">Data Absen Sore Lapangan Hari Ini</span>
        </a>
        <a href="<?php echo site_url('attendance/allDataLapanganSore')?>" class="btn btn-primary btn-icon-split btn-sm">
          <span class="icon text-white-50">
            <i class="fa fa-calendar-check-o"></i>
          </span>
          <span class="text">Semua Data Absen Sore Lapangan</span>
        </a>
      <?php } ?>

      <?php if($this->session->userdata('group_id')== 1){?>

      | 
      <a href="#" class="btn btn-danger btn-icon-split btn-sm" data-toggle="modal" data-target="#employeeModalFilter">
        <span class="icon text-white-50">
          <i class="fas fa-filter"></i>
        </span>
        <span class="text">Filter Berdasarkan SKPD</span>
      </a>

      <div class="modal fade" id="employeeModalFilter" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Filter Berdasarkan SKPD</h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <?php echo form_open_multipart("attendance/reindex")?>
            <div class="modal-body">
              
              
              <div class="form-group">
                <label for=""><b>SKPD</b></label>
                <select id="skpd" class="form-control" name="skpd" style="width:100%" required>
                  <option value="">.:: Pilih SKPD ::.</option>
                  <?php foreach($skpd as $s){ ?>
                  <option value="<?php echo $s->kd_skpd;?>"><?php echo $s->nama;?></option>
                  <?php } ?>
                </select>
                <input type="hidden" name="url_seg2" value="<?php echo $this->uri->segment(2);?>">
                <input type="hidden" name="url_seg3" value="<?php echo $this->uri->segment(3);?>">

              </div>
              
              
            </div>
            <div class="modal-footer">
              <button class="btn btn-danger" type="submit">Filter</button>
            <?php echo form_close(); ?>
              <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
              
            </div>
          </div>
        </div>
      </div>
      <?php } ?>


    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th style="width: 5%;">No</th>
              <th style="width: 5%;">#</th>
              <th>Nama</th>
              <th>NIP</th>
              <th>SKPD</th>
              <th>Jam Absen</th>
            </tr>
          </thead>
          
          <tbody>
            <?php $no=1; foreach($attendance as $key){?>
            <tr>
              <td><?php echo $no;?></td>
              <td>
               
                <a href="#" class="btn btn-primary btn-icon-split btn-sm" data-toggle="modal" data-target="#itemImageModal<?php echo $key->id_lap?>">
                  <span class="text">
                    <i class="fa fa-image"></i>
                  </span>
                </a>


              </td>
              <td><?php echo $key->nama?> <br> <span class="badge badge-primary"><?php echo $key->nama_skpd;?></td>
              <td><?php echo $key->nip?></td>
              <td><?php echo $key->nama_skpd?></td>
              <td><?php echo $key->checkin_time?></td>
            </tr>

            <!-- Looping Modal Area -->

            <!-- attendance Modal Edit-->
            <div class="modal fade" id="itemImageModal<?php echo $key->id_lap?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Foto Absen Pagi Lapangan</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                  </div>
                  
                  <div class="modal-body">
                    <center>
                    <img src="<?php echo base_url()?>upload/pegawai/foto_lapangan/<?php echo $key->foto_lapangan?>" width="300"><br><br>
                    Waktu Verifikasi : <?php echo $key->checkin_time;?>
                    </center>
                    
                  </div>
                  <div class="modal-footer">
                  
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Tutup</button>
                    
                  </div>
                </div>
              </div>
            </div>

           



            
          

            <!-- End Looping -->


            <?php $no++; } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->
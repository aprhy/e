<div class="container-fluid">
  <?php 
    if($this->session->flashdata('add')){ 
      $message = $this->session->flashdata('add');
      $heading = '#Tambah FORM IZIN PEGAWAI';
    }else if($this->session->flashdata('update')){ 
      $message = $this->session->flashdata('update');
      $heading = '#Update FORM IZIN PEGAWAI';
    }else if($this->session->flashdata('delete')){
      $message = $this->session->flashdata('delete');
      $heading = '#Delete FORM IZIN PEGAWAI';  
    } 
  ?>
  <?php if(isset($message)){ ?>
  <script>
    $(document).ready(function(){
      $.toast({
        text : '<?php echo $message;?>',
        heading : '<?php echo $heading;?>',
        position : 'top-right',
        width : 'auto',
        showHideTransition : 'slide',
        icon: 'info',
        hideAfter: 5000
      })
    });
  </script>
  <?php } ?>
  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800">Data FORM IZIN PEGAWAI</h1>
  <p class="mb-4">Data berikut merupakan kumpulan FORM IZIN PEGAWAI Kota Kendari</p>
  <hr>

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <a href="#" class="btn btn-primary btn-icon-split btn-sm" data-toggle="modal" data-target="#formizinModal">
        <span class="icon text-white-50">
          <i class="fas fa-plus"></i>
        </span>
        <span class="text">Tambah Data</span>
      </a>

      <!-- formizin Modal-->
      <div class="modal fade" id="formizinModal" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Tambah FORM IZIN PEGAWAI Baru</h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <?php echo form_open_multipart("attendance/input_izin")?>
            <div class="modal-body">
              <div class="form-group">
                <label for=""><b>Pegawai</b></label>
                <select id="skpd" class="form-control" name="pegawai" style="width:100%" required>
                  <option value="">.:: Pilih Pegawai ::.</option>
                  <?php foreach($employee as $s){ ?>
                  <option value="<?php echo $s->nip."-".$s->kd_skpd;?>"><?php echo $s->nip." - ".$s->nama;?></option>
                  <?php } ?>
                </select>
              </div>
              <div class="form-group">
                <label for=""><b>Status Izin</b></label>
                <select  class="form-control" name="izin_status" style="width:100%" required>
                  <option value="">.:: Pilih Status ::.</option>
                  <option value="1">1. CUTI SAKIT</option>
                  <option value="2">2. CUTI BESAR/ BERSALIN / KARNA HAL PENTING</option>
                  <option value="3">3. TANPA KETERANGAN (ALPA)</option>
                  <option value="4">4. SAKIT / IZIN DENGAN KETERANGAN</option>
                  <option value="5">5. LIBUR</option>
                </select>
              </div>
              <div class="form-group">
                <label for=""><b>Keterangan Izin</b></label>
                <input type="text" class="form-control" placeholder="Keterangan Izin..." name="keterangan" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>Dari Tanggal</b></label>
                <input type="date" class="form-control" name="tanggal" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>Sampai Tanggal</b></label>
                <input type="date" class="form-control" name="tanggal_akhir" required="required">
              </div>
              
              
            </div>
            <div class="modal-footer">
              <button class="btn btn-primary" type="submit">Tambah</button>
            <?php echo form_close(); ?>
              <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
              
            </div>
          </div>
        </div>
      </div>


      <a href="<?php echo site_url('attendance/formizin')?>" class="btn btn-success btn-icon-split btn-sm">
        <span class="icon text-white-50">
          <i class="fa fa-refresh"></i>
        </span>
        <span class="text">Refresh Halaman</span>
      </a>

      <a href="#" class="btn btn-danger btn-icon-split btn-sm" data-toggle="modal" data-target="#formizinModalFilter">
        <span class="icon text-white-50">
          <i class="fas fa-search"></i>
        </span>
        <span class="text">Filter Data</span>
      </a>

      <!-- formizin Modal-->
      <div class="modal fade" id="formizinModalFilter" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Filter FORM IZIN PEGAWAI</h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <?php echo form_open_multipart("attendance/formizin")?>
            <div class="modal-body">
              
              <div class="form-group">
                <label for=""><b>Tanggal Izin</b></label>
                <input type="date" class="form-control" name="tanggal" required="required">
              </div>
              
              
            </div>
            <div class="modal-footer">
              <button class="btn btn-primary" type="submit">Filter</button>
            <?php echo form_close(); ?>
              <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
              
            </div>
          </div>
        </div>
      </div>


    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th style="width: 5%;">No</th>
              <th style="width: 6%;">#</th>
              <th>NIP</th>
              <th>Nama</th>
              <th>SKPD</th>
              <th>Tanggal Izin</th>
              <th>Status Izin</th>
              <th>Keterangan Izin</th>
            </tr>
          </thead>
          
          <tbody>
            <?php $no=1; 
                  
                  foreach($formizin as $key){?>
            <tr>
              <td><?php echo $no;?></td>
              <td>
              
                <a href="#" class="btn btn-danger btn-icon-split btn-sm" data-toggle="modal" data-target="#formizinRemoveModal<?php echo $key->izin_id?>">
                  <span class="text">
                    <i class="fa fa-trash"></i>
                  </span>
                </a>


              </td>
              <td><?php echo $key->nip?></td>
              <td><?php echo $key->nama?></td>
              <td><?php echo $key->nama_skpd?></td>
              <td><?php echo $key->izin_date?></td>
              <td>
                <?php
                  if($key->izin_status==1){
                    echo "CUTI SAKIT";
                  }elseif($key->izin_status==2){
                    echo "CUTI BESAR/ BERSALIN / KARNA HAL PENTING";
                  }elseif($key->izin_status==3){
                    echo "TANPA KETERANGAN (ALPA)";
                  }elseif($key->izin_status==4){
                    echo "SAKIT / IZIN DENGAN KETERANGAN";
                  }elseif($key->izin_status==5){
                    echo "LIBUR";
                  }
                  
                ?>
              </td>
              <td><?php echo htmlspecialchars($key->keterangan);?></td>
            </tr>

            <!-- Looping Modal Area -->

          

            <!-- formizin Modal Remove-->
            <div class="modal fade" id="formizinRemoveModal<?php echo $key->izin_id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Hapus FORM IZIN PEGAWAI</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                  </div>
                  <?php echo form_open("attendance/delete_izin")?>
                  <div class="modal-body">
                    Apakah anda yakin akan menghapus data FORM IZIN PEGAWAI <b><?php echo $key->nama ?></b> ?
                    <input type="hidden" class="form-control" name="izin_id" value="<?php echo $key->izin_id?>">
                    <input type="hidden" class="form-control" name="nama" value="<?php echo $key->nama?>">
                  </div>
                  <div class="modal-footer">
                    <button class="btn btn-danger" type="submit">Hapus</button>
                  <?php echo form_close(); ?>
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    
                  </div>
                </div>
              </div>
            </div>



            
          

            <!-- End Looping -->


            <?php $no++; } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->
<div class="container-fluid">
  <?php 
    if($this->session->flashdata('add')){ 
      $message = $this->session->flashdata('add');
      $heading = '#Tambah Akun Pelanggar Area Kerja';
    }else if($this->session->flashdata('update')){ 
      $message = $this->session->flashdata('update');
      $heading = '#Update Akun Pelanggar Area Kerja';
    }else if($this->session->flashdata('delete')){
      $message = $this->session->flashdata('delete');
      $heading = '#Delete Akun Pelanggar Area Kerja';  
    } 
  ?>
  <?php if(isset($message)){ ?>
  <script>
    $(document).ready(function(){
      $.toast({
        text : '<?php echo $message;?>',
        heading : '<?php echo $heading;?>',
        position : 'top-right',
        width : 'auto',
        showHideTransition : 'slide',
        icon: 'info',
        hideAfter: 5000
      })
    });
  </script>
  <?php } ?>
  <!-- Page Heading -->
  <?php if($this->uri->segment(2)=='allDataViolatorDetail'){?>
  <h1 class="h3 mb-2 text-gray-800">Data Akun Pelanggar Area Kerja : <b><?php echo tgl_indo($this->uri->segment(3))?></b></h1>
  <?php }else{?>
    <h1 class="h3 mb-2 text-gray-800">Data Akun Pelanggar Area Kerja Hari Ini</h1>
  <?php }?>
  <p class="mb-4">Data berikut merupakan kumpulan Akun Pelanggar Area Kerja Kota Kendari</p>
  <hr>

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      
    <?php if($this->uri->segment(2)=='allDataViolatorDetail'){?>
      <a href="<?php echo site_url('employee/allDataViolator')?>" class="btn btn-warning btn-icon-split btn-sm">
        <span class="icon text-white-50">
          <i class="fa fa-arrow-left"></i>
        </span>
        <span class="text">Kembali</span>
      </a>
      
    <?php }else{?>
      <a href="<?php echo site_url('employee/violator')?>" class="btn btn-success btn-icon-split btn-sm">
        <span class="icon text-white-50">
          <i class="fa fa-refresh"></i>
        </span>
        <span class="text">Refresh Pelanggar Hari Ini</span>
      </a>
      <a href="<?php echo site_url('employee/allDataViolator')?>" class="btn btn-danger btn-icon-split btn-sm">
        <span class="icon text-white-50">
          <i class="fa fa-ban"></i>
        </span>
        <span class="text">Semua Data Pelanggar Per-Tanggal</span>
      </a>
    <?php }?>

      
    </div>
    <div class="card-body">
      <div class="table-responsive">
      
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th style="width: 5%;">No</th>
              <th style="width: 5%;">Tracking</th>
              <th style="width: 15%;">NIP</th>
              <th>Nama</th>
              <th>SKPD</th>
            </tr>
          </thead>
          
          <tbody>
            <?php $no=1; foreach($employee as $key){?>
            <tr>
              
              <td><?php echo $no;?></td>
              <td>
                <?php if($this->uri->segment(2)=='allDataViolatorDetail'){ ?>
                  <a href="<?php echo site_url('employee/map_violator/'.$key->nip."/".$this->uri->segment(3))?>" class="btn btn-danger btn-icon-split btn-sm">
                    <span class="text">
                      <i class="fa fa-map-marker"></i>
                    </span>
                  </a>
                <?php }else{?>
                  <a href="<?php echo site_url('employee/map_violator/'.$key->nip."/".date('Y-m-d'))?>" class="btn btn-danger btn-icon-split btn-sm">
                    <span class="text">
                      <i class="fa fa-map-marker"></i>
                    </span>
                  </a>
                <?php }?>
              


              </td>
              
              
              <td><?php echo $key->nip?></td>
              <td><?php echo $key->nama?></td>
              <td><?php echo $key->nama_skpd?></td>
              
            </tr>

            


            <?php $no++; } ?>
          </tbody>
        </table>
        
        <br><br>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->
<div class="container-fluid">
  <?php 
    if($this->session->flashdata('add')){ 
      $message = $this->session->flashdata('add');
      $heading = '#Tambah Akun Pelanggar Area Kerja';
    }else if($this->session->flashdata('update')){ 
      $message = $this->session->flashdata('update');
      $heading = '#Update Akun Pelanggar Area Kerja';
    }else if($this->session->flashdata('delete')){
      $message = $this->session->flashdata('delete');
      $heading = '#Delete Akun Pelanggar Area Kerja';  
    } 
  ?>
  <?php if(isset($message)){ ?>
  <script>
    $(document).ready(function(){
      $.toast({
        text : '<?php echo $message;?>',
        heading : '<?php echo $heading;?>',
        position : 'top-right',
        width : 'auto',
        showHideTransition : 'slide',
        icon: 'info',
        hideAfter: 5000
      })
    });
  </script>
  <?php } ?>
  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800">Data Akun Pelanggar Area Kerja</h1>
  <p class="mb-4">Data berikut merupakan kumpulan Akun Pelanggar Area Kerja Kota Kendari</p>
  <hr>

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      


      <a href="<?php echo site_url('employee/violator')?>" class="btn btn-success btn-icon-split btn-sm">
        <span class="icon text-white-50">
          <i class="fa fa-refresh"></i>
        </span>
        <span class="text">Refresh Pelanggar Hari Ini</span>
      </a>
      <a href="<?php echo site_url('employee/allDataViolator')?>" class="btn btn-danger btn-icon-split btn-sm">
        <span class="icon text-white-50">
          <i class="fa fa-ban"></i>
        </span>
        <span class="text">Semua Data Pelanggar Per-Tanggal</span>
      </a>
    </div>
    <div class="card-body">
      <div class="table-responsive">
      
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th style="width: 5%;">No</th>
              <th style="width: 15%;">#</th>
              <th>Tanggal Pelanggaran Area Kerja</th>
            </tr>
          </thead>
          
          <tbody>
            <?php $no=1; foreach($employee as $key){?>
            <tr>
              
              <td><?php echo $no;?></td>
              <td>
               
                <a href="<?php echo site_url('employee/allDataViolatorDetail/'.$key->today)?>" class="btn btn-primary btn-icon-split btn-sm">
                  <span class="text">
                    <i class="fa fa-list"></i> Cek Data Pelanggar
                  </span>
                </a>


              </td>
              
              
              <td><?php echo tgl_indo($key->today)?></td>
              
            </tr>

            


            <?php $no++; } ?>
          </tbody>
        </table>
        
        <br><br>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->
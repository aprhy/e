<div class="container-fluid">
  <?php $crdt = explode(',', $employee[0]->coordinate);?>
  <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC8aB4MpC1orBp300KQQAiVEnWdpry4OPg&callback=initMap"></script>
  <script>
    var markers = [
      ['<b>Ini Adalah titik WHF </b>', <?php echo $employee[0]->coordinate;?>      ],
    
      <?php foreach ($data_peta as $key) { ?>
      [
        '<?php echo "<b>Waktu Pelanggaran :</b><br>".$key->createdate."<br><br><b>Titik Kordinat :</b><br>".$key->coordinate_history."<br>" ?>', <?php echo $key->coordinate_history?>
      ],
    
      <?php } ?>
    ];

    

    function initMap() {
      var styledMapType = new google.maps.StyledMapType(
        [{
            elementType: 'geometry',
            stylers: [{
              color: '#ebe3cd'
            }]
          },
          {
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#523735'
            }]
          },
          {
            elementType: 'labels.text.stroke',
            stylers: [{
              color: '#f5f1e6'
            }]
          },
          {
            featureType: 'administrative',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#c9b2a6'
            }]
          },
          {
            featureType: 'administrative.land_parcel',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#dcd2be'
            }]
          },
          {
            featureType: 'administrative.land_parcel',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#ae9e90'
            }]
          },
          {
            featureType: 'landscape.natural',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'poi',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'poi',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#93817c'
            }]
          },
          {
            featureType: 'poi.park',
            elementType: 'geometry.fill',
            stylers: [{
              color: '#a5b076'
            }]
          },
          {
            featureType: 'poi.park',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#447530'
            }]
          },
          {
            featureType: 'road',
            elementType: 'geometry',
            stylers: [{
              color: '#f5f1e6'
            }]
          },
          {
            featureType: 'road.arterial',
            elementType: 'geometry',
            stylers: [{
              color: '#fdfcf8'
            }]
          },
          {
            featureType: 'road.highway',
            elementType: 'geometry',
            stylers: [{
              color: '#f8c967'
            }]
          },
          {
            featureType: 'road.highway',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#e9bc62'
            }]
          },
          {
            featureType: 'road.highway.controlled_access',
            elementType: 'geometry',
            stylers: [{
              color: '#e98d58'
            }]
          },
          {
            featureType: 'road.highway.controlled_access',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#db8555'
            }]
          },
          {
            featureType: 'road.local',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#806b63'
            }]
          },
          {
            featureType: 'transit.line',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'transit.line',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#8f7d77'
            }]
          },
          {
            featureType: 'transit.line',
            elementType: 'labels.text.stroke',
            stylers: [{
              color: '#ebe3cd'
            }]
          },
          {
            featureType: 'transit.station',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'water',
            elementType: 'geometry.fill',
            stylers: [{
              color: '#b9d3c2'
            }]
          },
          {
            featureType: 'water',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#92998d'
            }]
          },
          {
            featureType: 'poi',
            stylers: [{visibility: 'off'}]
          },
        ], {
          name: 'Peta Pelanggaran <?php echo $employee[0]->nama;?> : <?php echo tgl_indo($this->uri->segment(4))?>'
      });


      var myOptions = {
        center: new google.maps.LatLng(<?php echo $employee[0]->coordinate;?>),
        zoom: 11,
        mapTypeControlOptions: {
          mapTypeIds: [
            'styled_map','satellite'
          ]
        }
      };


      

      var mapCanvas = document.getElementById('map-canvas'); 
      var map = new google.maps.Map(mapCanvas, myOptions);

      
      map.mapTypes.set('styled_map', styledMapType);
      map.setMapTypeId('styled_map');
     
      var infowindow = new google.maps.InfoWindow(), marker, i;
      /* http://maps.google.com/mapfiles/kml/pal3/icon48.png */
      
      for (i = 0; i < markers.length; i++) {  
        pos = new google.maps.LatLng(markers[i][1], markers[i][2]);
        if(i==0){
          marker = new google.maps.Marker({
              position: pos,
              map: map,
              icon : 'http://maps.google.com/mapfiles/kml/pal3/icon48.png'
          });
        }else{
          marker = new google.maps.Marker({
            position: pos,
            map: map,
            icon : 'http://maps.google.com/mapfiles/kml/pal4/icon15.png'
          });
        }
        google.maps.event.addListener(marker, 'click', (function(marker, i) {
          return function() {
              infowindow.setContent(markers[i][0]);
              infowindow.open(map, marker);
          }
        })(marker, i));
      }
      
      
      var directionsService = new google.maps.DirectionsService();
      var directionsDisplay = new google.maps.DirectionsRenderer({map: map, suppressMarkers: true});
      directionsDisplay.setMap(map);


      var directionsService00 = new google.maps.DirectionsService();
      var directionsDisplay00 = new google.maps.DirectionsRenderer({map: map, suppressMarkers: true});
      directionsDisplay00.setMap(map);

      var request00 = {
      origin: '<?php echo $employee[0]->coordinate;?>', 
      destination: '<?php echo $data_peta[0]->coordinate_history?>',
      travelMode: google.maps.DirectionsTravelMode.DRIVING
      };



      directionsService00.route(request00, function(response, status) {
        if (status == google.maps.DirectionsStatus.OK) {
          directionsDisplay00.setDirections(response);
        }
      });

      <?php for($ii=0;$ii<(count($data_peta)-1);$ii++){?>

        var directionsService<?php echo $ii?> = new google.maps.DirectionsService();
        var directionsDisplay<?php echo $ii?> = new google.maps.DirectionsRenderer({map: map, suppressMarkers: true});
        directionsDisplay<?php echo $ii?>.setMap(map);

        var request<?php echo $ii?> = {
        origin: '<?php echo $data_peta[$ii]->coordinate_history?>', 
        destination: '<?php echo $data_peta[($ii+1)]->coordinate_history?>',
        travelMode: google.maps.DirectionsTravelMode.DRIVING
        };



        directionsService<?php echo $ii?>.route(request<?php echo $ii?>, function(response, status) {
          if (status == google.maps.DirectionsStatus.OK) {
            directionsDisplay<?php echo $ii?>.setDirections(response);
          }
        });

      <?php }?>

    }
  </script>
  <!-- Page Heading -->
  
  <h1 class="h3 mb-2 text-gray-800">Data Tracking Pelanggaran Area Kerja : <b><?php echo $employee[0]->nama?></b></h1>
  <p class="mb-4">Pelanggaran pada tanggal <?php echo '<span class="badge badge-danger">'.tgl_indo($this->uri->segment(4)).'</span>'?></p>
  <hr>

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      
    
      <a href="<?php echo site_url('employee/allDataViolator')?>" class="btn btn-warning btn-icon-split btn-sm">
        <span class="icon text-white-50">
          <i class="fa fa-arrow-left"></i>
        </span>
        <span class="text">Kembali</span>
      </a>
      
      
      
    </div>
    <div class="card-body">
      <div id="map-canvas"></div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->
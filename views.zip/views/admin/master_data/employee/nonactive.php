<div class="container-fluid">
  <?php 
    if($this->session->flashdata('add')){ 
      $message = $this->session->flashdata('add');
      $heading = '#Tambah Pegawai/ASN';
    }else if($this->session->flashdata('update')){ 
      $message = $this->session->flashdata('update');
      $heading = '#Update Pegawai/ASN';
    }else if($this->session->flashdata('delete')){
      $message = $this->session->flashdata('delete');
      $heading = '#Delete Pegawai/ASN';  
    } 
  ?>
  <?php if(isset($message)){ ?>
  <script>
    $(document).ready(function(){
      $.toast({
        text : '<?php echo $message;?>',
        heading : '<?php echo $heading;?>',
        position : 'top-right',
        width : 'auto',
        showHideTransition : 'slide',
        icon: 'info',
        hideAfter: 5000
      })
    });
  </script>
  <?php } ?>
  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800">Data Pegawai/ASN Non-Aktif</h1>
  <hr>

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <a href="<?php echo site_url('employee/nonactive')?>" class="btn btn-success btn-icon-split btn-sm">
        <span class="icon text-white-50">
          <i class="fa fa-refresh"></i>
        </span>
        <span class="text">Refresh Halaman</span>
      </a>



    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th style="width: 5%;">No</th>
              <th style="width: 5%;">#</th>
              <th>NIP</th>
              <th>Nama</th>
              <th>SKPD Teraekhir</th>
              <th>Status</th>
              <th>Keterangan</th>
            </tr>
          </thead>
          
          <tbody>
            <?php $no=1; foreach($employee as $key){?>
            <tr>
              <td><?php echo $no;?></td>
              <td>
                <a href="#" class="btn btn-danger btn-icon-split btn-sm" data-toggle="modal" data-target="#delete<?php echo $key->id?>">
                  <span class="text">
                    <i class="fa fa-trash"></i> Hapus
                  </span>
                </a>
              </td>
              <td><?php echo $key->nip?></td>
              <td><?php echo $key->nama?></td>
              <td><?php echo $key->nama_skpd?></td>
              <td><?php echo $key->status_pegawai?></td>
              <td><?php echo $key->keterangan?></td>
            </tr>

              <div class="modal fade" id="delete<?php echo $key->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Hapus Data</h5>
                      <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                    <?php echo form_open("employee/delete")?>
                    <div class="modal-body">
                      Apakah anda yakin akan menghapus data Pegawai <b><?php echo $key->nama ?></b> ?
                      <input type="hidden" class="form-control" name="id" value="<?php echo $key->id?>">
                      <input type="hidden" class="form-control" name="nip" value="<?php echo $key->nip?>">
                      <input type="hidden" class="form-control" name="kd_skpd" value="<?php echo $key->kd_skpd?>">
                      
                      <hr><br>
                      Dengan ini berarti anda menyutujui melakukan penghapusan
                      
                    </div>
                    <div class="modal-footer">
                      <button class="btn btn-danger" type="submit">Hapus</button>
                    <?php echo form_close(); ?>
                      <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                      
                    </div>
                  </div>
                </div>
              </div>


            <?php $no++; } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->
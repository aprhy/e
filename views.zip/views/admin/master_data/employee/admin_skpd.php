<div class="container-fluid">
  <?php 
    if($this->session->flashdata('add')){ 
      $message = $this->session->flashdata('add');
      $heading = '#Tambah Akun Admin SKPD';
      $icon = 'info';
    }else if($this->session->flashdata('update')){ 
      $message = $this->session->flashdata('update');
      $heading = '#Update Akun Admin SKPD';
      $icon = 'info';
    }else if($this->session->flashdata('delete')){
      $message = $this->session->flashdata('delete');
      $heading = '#Delete Akun Admin SKPD';  
      $icon = 'info';
    } else if($this->session->flashdata('update_gagal')){
      $message = $this->session->flashdata('update_gagal');
      $heading = '#Update Akun Absensi Pegawai';  
      $icon = 'error';
    } 
  ?>
  <?php if(isset($message)){ ?>
  <script>
    $(document).ready(function(){
      $.toast({
        text : '<?php echo $message;?>',
        heading : '<?php echo $heading;?>',
        position : 'top-right',
        width : 'auto',
        showHideTransition : 'slide',
        icon: '<?php echo $icon;?>',
        hideAfter: 5000
      })
    });
  </script>
  <?php } ?>
  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800">Data Akun Admin SKPD</h1>
  <p class="mb-4">Data Admin SKPD</p>
  

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <a href="#" class="btn btn-primary btn-icon-split btn-sm" data-toggle="modal" data-target="#employeeModal">
        <span class="icon text-white-50">
          <i class="fas fa-plus"></i>
        </span>
        <span class="text">Tambah Data</span>
      </a>

      <!-- employee Modal-->
      <div class="modal fade" id="employeeModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Tambah Akun Admin SKPD Baru</h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <?php echo form_open_multipart("employee/input_admin_skpd")?>
            <div class="modal-body">
              <div class="form-group">
                <label for=""><b>NIP</b></label>
                <input type="text" class="form-control" placeholder="NIP Admin SKPD..." name="nip" required="required">
              </div>
              
              
              <hr>
              <div class="form-group">
                <label for=""><b>Username</b></label>
                <input type="text" class="form-control" placeholder="Username Admin SKPD..." name="username" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>Password</b></label>
                <input type="text" class="form-control" placeholder="Password Admin SKPD..." name="password" required="required">
              </div>
              
              
              
            </div>
            <div class="modal-footer">
              <button class="btn btn-primary" type="submit">Tambah</button>
            <?php echo form_close(); ?>
              <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
              
            </div>
          </div>
        </div>
      </div>


      <a href="<?php echo site_url('employee/admin_skpd')?>" class="btn btn-success btn-icon-split btn-sm">
        <span class="icon text-white-50">
          <i class="fa fa-refresh"></i>
        </span>
        <span class="text">Refresh Halaman</span>
      </a>  | 
      <a href="<?php echo site_url('report/print_admin_skpd')?>" class="btn btn-danger btn-icon-split btn-sm">
        <span class="icon text-white-50">
          <i class="fa fa-print"></i>
        </span>
        <span class="text">Cetak Data</span>
      </a> 
      
    </div>
    <div class="card-body">
      <div class="table-responsive">
      
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th style="width: 5%;">No</th>
              <th style="width: 10%;">#</th>
              <th>NIP</th>
              <th>Nama</th>
              <th>Username</th>
              <th>SKPD</th>
            </tr>
          </thead>
          
          <tbody>
            <?php $no=1; foreach($employee as $key){?>
            <tr>
              
              <td><?php echo $no;?></td>
              <td>
               
                <a href="#" class="btn btn-warning btn-icon-split btn-sm" data-toggle="modal" data-target="#employeeEditModal<?php echo $key->id?>">
                  <span class="text">
                    <i class="fa fa-edit"></i>
                  </span>
                </a>
                <a href="#" class="btn btn-danger btn-icon-split btn-sm" data-toggle="modal" data-target="#employeeRemoveModal<?php echo $key->id?>">
                  <span class="text">
                    <i class="fa fa-trash"></i>
                  </span>
                </a>


              </td>
              
              
              <td><?php echo $key->nip?></td>
              <td><?php echo $key->nama?></td>
              <td><?php echo $key->username?></td>
              <td><?php echo $key->nama_skpd?></td>
              
            </tr>

            <!-- Looping Modal Area -->

            <!-- employee Modal Edit-->
            <div class="modal fade" id="employeeEditModal<?php echo $key->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Akun Admin SKPD</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                  </div>
                  <?php echo form_open_multipart("employee/edit_admin_skpd")?>
                  <div class="modal-body">
                    <div class="form-group">
                      <label for=""><b>NIP</b></label>
                      <input type="text" class="form-control" placeholder="NIP Admin SKPD..." name="nip" required="required" value="<?php echo $key->nip?>" readonly>
                      <input type="hidden" class="form-control" name="id" required="required" value="<?php echo $key->id?>">
                    </div>
                    
                    
                    <hr>
                    <div class="form-group">
                      <label for=""><b>Username</b></label>
                      <input type="text" class="form-control" placeholder="Username Admin SKPD..." name="username" required="required" value="<?php echo $key->username?>">
                      <input type="hidden" class="form-control" placeholder="Username Admin SKPD..." name="username_old" required="required" value="<?php echo $key->username?>">
                    </div>
                    <div class="form-group">
                      <label for=""><b>Password</b></label>
                      <input type="text" class="form-control" placeholder="Password Admin SKPD..." name="password">
                    </div>
                    
                    
                  </div>
                  <div class="modal-footer">
                    <button class="btn btn-warning" type="submit">Edit</button>
                  <?php echo form_close(); ?>
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    
                  </div>
                </div>
              </div>
            </div>

            <!-- employee Modal Remove-->
            <div class="modal fade" id="employeeRemoveModal<?php echo $key->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Hapus Akun Admin SKPD</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                  </div>
                  <?php echo form_open("employee/delete_admin_skpd")?>
                  <div class="modal-body">
                    Apakah anda yakin akan menghapus data Akun Admin SKPD <b><?php echo $key->nama ?></b> ?
                    <input type="hidden" class="form-control" name="id" value="<?php echo $key->id?>">
                    <input type="hidden" class="form-control" name="nip" value="<?php echo $key->nip?>">
                    <input type="hidden" class="form-control" name="nama" value="<?php echo $key->nama?>">
                  </div>
                  <div class="modal-footer">
                    <button class="btn btn-danger" type="submit">Hapus</button>
                  <?php echo form_close(); ?>
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                    
                  </div>
                </div>
              </div>
            </div>



            <!-- End Looping -->


            <?php $no++; } ?>
          </tbody>
        </table>
        
        <br><br>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->
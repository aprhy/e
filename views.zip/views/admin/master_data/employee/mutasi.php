<div class="container-fluid">
  <?php 
    if($this->session->flashdata('add')){ 
      $message = $this->session->flashdata('add');
      $heading = '#Tambah Pegawai/ASN';
    }else if($this->session->flashdata('update')){ 
      $message = $this->session->flashdata('update');
      $heading = '#Update Pegawai/ASN';
    }else if($this->session->flashdata('delete')){
      $message = $this->session->flashdata('delete');
      $heading = '#Delete Pegawai/ASN';  
    } 
  ?>
  <?php if(isset($message)){ ?>
  <script>
    $(document).ready(function(){
      $.toast({
        text : '<?php echo $message;?>',
        heading : '<?php echo $heading;?>',
        position : 'top-right',
        width : 'auto',
        showHideTransition : 'slide',
        icon: 'info',
        hideAfter: 5000
      })
    });
  </script>
  <?php } ?>
  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800">Data Pegawai/ASN Mutasi</h1>
  <!-- <p class="mb-4">Data SKPD : <b><?php echo $nama_skpd[0]->nama;?></b></p> -->
  <hr>

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      

     
      


      <a href="<?php echo site_url('employee/list_mutasi')?>" class="btn btn-success btn-icon-split btn-sm">
        <span class="icon text-white-50">
          <i class="fa fa-refresh"></i>
        </span>
        <span class="text">Refresh Halaman</span>
      </a>

      <a href="<?php echo site_url('report/print_mutasi')?>" class="btn btn-danger btn-icon-split btn-sm">
        <span class="icon text-white-50">
          <i class="fa fa-print"></i>
        </span>
        <span class="text">Cetak Data Mutasi</span>
      </a>



    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th style="width: 5%;">No</th>
              <th style="width: 30%;">#</th>
              <th>NIP</th>
              <th>Nama</th>
              <th>Asal SKPD</th>
            </tr>
          </thead>
          
          <tbody>
            <?php $no=1; foreach($employee as $key){?>
            <tr>
              <td><?php echo $no;?></td>
              <td>
                <?php if($this->session->userdata('group_id')==1){?>
                <a href="#" class="btn btn-danger btn-icon-split btn-sm" data-toggle="modal" data-target="#employeenonActiveModal<?php echo $key->id?>">
                  <span class="text">
                    <i class="fa fa-user-times"></i> NonAktif
                  </span>
                </a> | 
                <a href="#" class="btn btn-primary btn-icon-split btn-sm" data-toggle="modal" data-target="#employeeMutasiModal<?php echo $key->id?>">
                  <span class="text">
                    <i class="fa fa-legal"></i> Tetapkan SKPD Baru
                  </span>
                </a>
                <?php }elseif($this->session->userdata('group_id')==99){?>
                <a href="#" class="btn btn-danger btn-icon-split btn-sm" data-toggle="modal" data-target="#employeeMutasiSKPDModal<?php echo $key->id?>">
                  <span class="text">
                    <i class="fa fa-legal"></i> Mutasi ke SKPD Saya
                  </span>
                </a>
                <?php }?>
              </td>
              <td><?php echo $key->nip?></td>
              <td><?php echo $key->nama?></td>
              <td><?php echo $key->skpd_name?></td>
            </tr>

              

            
              

              <!-- employee Modal Remove-->
              <div class="modal fade" id="employeeMutasiModal<?php echo $key->id?>" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Mutasi Pegawai</h5>
                      <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                    <?php echo form_open("employee/mutasi")?>
                    <div class="modal-body">
                      Apakah anda yakin akan memutasi data Pegawai <b><?php echo $key->nama ?></b> ?
                      <input type="hidden" class="form-control" name="id" value="<?php echo $key->id?>">
                      <input type="hidden" class="form-control" name="nip" value="<?php echo $key->nip?>">
                      
                      <hr><br>
                      
                      <div class="form-group">
                        <label for=""><b>SKPD Mutasi</b></label>
                        <select id="skpd" class="form-control" name="kd_skpd" required style="width:100%">
                          <option value="">.:: Pilih SKPD ::.</option>
                          <?php foreach($skpd as $ss){ 
                            if($key->kd_skpd == $ss->kd_skpd){
                          ?>
                          <option value="<?php echo $ss->kd_skpd;?>" selected><?php echo $ss->nama;?></option>
                            <?php }else{?>
                          <option value="<?php echo $ss->kd_skpd;?>"><?php echo $ss->nama;?></option>
                          <?php } }?>
                        </select>
                      </div>
                    </div>
                    <div class="modal-footer">
                      <button class="btn btn-danger" type="submit">Mutasi</button>
                    <?php echo form_close(); ?>
                      <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                      
                    </div>
                  </div>
                </div>
              </div>

              <div class="modal fade" id="employeenonActiveModal<?php echo $key->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Non Aktifkan Pegawai</h5>
                      <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                    <?php echo form_open("employee/doNonActive")?>
                    <div class="modal-body">
                      Apakah anda yakin akan menon-aktifkan pegawai atas nama : <b><?php echo $key->nama?></b>
                      <div class="form-group">
                        <!-- <label for=""><b>Nama Pegawai/ASN</b></label> -->
                        <input type="hidden" class="form-control" placeholder="Masukkan Nama Pegawai/ASN..." name="nip" required="required" value="<?php echo $key->nip?>">
                        <input type="hidden" class="form-control" placeholder="Masukkan Nama Pegawai/ASN..." name="nama" required="required" value="<?php echo $key->nama?>">
                        <input type="hidden" class="form-control" placeholder="Masukkan Nama Pegawai/ASN..." name="id" required="required" value="<?php echo $key->id?>">
                      </div>
                      <hr>
                      <div class="form-group">
                        <label for=""><b>Alasan Penon-Aktifan Pegawai</b></label>
                        <input type="text" class="form-control" placeholder="Keterangan/Alasan Penon-aktifan Pegawai..." name="keterangan">
                      </div>
                      
                    </div>
                    <div class="modal-footer">
                      <button class="btn btn-danger" type="submit">Non-Aktifkan</button>
                    <?php echo form_close(); ?>
                      <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                      
                    </div>
                  </div>
                </div>
              </div>


              <div class="modal fade" id="employeeMutasiSKPDModal<?php echo $key->id?>" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Mutasi Pegawai Ke SKPD Saya</h5>
                      <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                    <?php echo form_open("employee/mutasi")?>
                    <div class="modal-body">
                      Apakah anda yakin akan memutasi data Pegawai <b><?php echo $key->nama ?></b> ?
                      <input type="hidden" class="form-control" name="id" value="<?php echo $key->id?>">
                      <input type="hidden" class="form-control" name="nip" value="<?php echo $key->nip?>">
                      <input type="hidden" class="form-control" name="kd_skpd" value="<?php echo $this->session->userdata('skpd_id')?>">

                      
                      <hr><br>
                      
                      
                    </div>
                    <div class="modal-footer">
                      <button class="btn btn-danger" type="submit">Mutasi</button>
                    <?php echo form_close(); ?>
                      <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                      
                    </div>
                  </div>
                </div>
              </div>



            <?php $no++; } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->
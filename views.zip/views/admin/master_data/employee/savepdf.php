<?php
require_once('./vendor/autoload.php');

use Spipu\Html2Pdf\Html2Pdf;
use Spipu\Html2Pdf\Exception\Html2PdfException;
use Spipu\Html2Pdf\Exception\ExceptionFormatter;


$htmlContent ='';
//$img_url = base_url('asset/kendari.png');
//OLD SETTING
/* for($i=0; $i < count($a);$i++){
  $temp = '<page style="font-size:6pt;">
		<div style="margin-top:5px">
    <img style="width: 21mm;height:auto;margin-left:10px" src="'.base_url()."upload/qrpasien/pasien-".md5($a[$i][0]).".png".'">';
    
    if($a[$i][1]){
      $temp .='<img style="width: 21mm;height:auto;margin-left:10px" src="'.base_url()."upload/qrpasien/pasien-".md5($a[$i][1]).".png".'">';
    }
    
    $temp .='
		<p style="margin-left:20px">NIK:'.$a[$i][0].'. &nbsp;&nbsp;NIK: '.$a[$i][1].'</p>
		</div>
	</page>

  ';
  $htmlContent = $htmlContent.''.$temp;
} */


/* for($i=0; $i < count($a);$i++){
  $temp = '<page style="font-size:6pt;">
		<div style="margin-top:5px">
    <img style="width: 21mm;height:auto;margin-left:10px" src="'.base_url()."upload/qrpasien/pasien-".md5($a[$i]).".png".'">
    <img style="width: 21mm;height:auto;margin-left:10px" src="'.base_url()."upload/qrpasien/pasien-".md5($a[$i]).".png".'">
		<p style="margin-left:20px">NIK:'.$a[$i].'</p>
		</div>
	</page>

  ';
  $htmlContent = $htmlContent.''.$temp;
} */

for($i=0; $i < count($a);$i++){
  $n = explode('-',$a[$i]);
  $temp = '
  <page style="font-size:5pt;">
    <table style="width:100%">
      <tr>
        <td style="width:50%"><img style="width: 19mm;height:auto;margin-left:0px" src="'."./upload/pegawai/qrcode/".$n[0].".png".'"></td>
        <td style="width:40%;word-wrap: break-all">'.$n[0].' <br>'.$n[1].'<br><br>'.$n[2].'</td>
      </tr>
    </table>
    
	</page>

  ';
  $htmlContent = $htmlContent.''.$temp;
}

try {
    ob_start();
    echo $htmlContent;
    $content = ob_get_clean();
    $html2pdf = new Html2Pdf('L', array(60,30), 'en', true,'UTF-8', array(0, 7, 0, 0));
    $html2pdf->pdf->SetDisplayMode('fullpage');
    $html2pdf->writeHTML($content);
    $html2pdf->output('qrcode_asn.pdf');
} catch (Html2PdfException $e) {
    $html2pdf->clean();
    $formatter = new ExceptionFormatter($e);
    echo $formatter->getHtmlMessage();
}
?>

<div class="container-fluid">
  <?php 
    if($this->session->flashdata('add')){ 
      $message = $this->session->flashdata('add');
      $heading = '#Tambah Pegawai/ASN';
    }else if($this->session->flashdata('update')){ 
      $message = $this->session->flashdata('update');
      $heading = '#Update Pegawai/ASN';
    }else if($this->session->flashdata('delete')){
      $message = $this->session->flashdata('delete');
      $heading = '#Delete Pegawai/ASN';  
    } 
  ?>
  <?php if(isset($message)){ ?>
  <script>
    $(document).ready(function(){
      $.toast({
        text : '<?php echo $message;?>',
        heading : '<?php echo $heading;?>',
        position : 'top-right',
        width : 'auto',
        showHideTransition : 'slide',
        icon: 'info',
        hideAfter: 5000
      })
    });
  </script>
  <?php } ?>
  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800">Data Pegawai/ASN</h1>
  <p class="mb-4">Data SKPD : <b><?php echo $nama_skpd[0]->nama;?></b></p>
  <hr>

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
    <?php if($this->session->userdata('group_id')==1){?>
      <a href="#" class="btn btn-primary btn-icon-split btn-sm" data-toggle="modal" data-target="#employeeModal">
        <span class="icon text-white-50">
          <i class="fas fa-plus"></i>
        </span>
        <span class="text">Tambah Data</span>
      </a>

     
      <div class="modal fade" id="employeeModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Tambah Pegawai/ASN Baru</h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <?php echo form_open_multipart("employee/input")?>
            <div class="modal-body">
              <div class="form-group">
                <label for=""><b>Nama Pegawai/ASN</b></label>
                <input type="text" class="form-control" placeholder="Masukkan Nama Pegawai/ASN..." name="nama" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>NIP</b></label>
                <input type="text" class="form-control" placeholder="Masukkan NIP Pegawai/ASN..." name="nip" required="required">
              </div>
              <div class="form-group">
                <label for=""><b>Jenis Kelamin</b></label>
                <select class="form-control" name="kelamin" required>
                  <option value="">.:: Pilih Jenis Kelamin ::.</option>
                  <option value="L">Laki-Laki</option>
                  <option value="P">Perempuan</option>
                </select>
              </div>
              <div class="form-group">
                <label for=""><b>Alamat</b></label>
                <input type="text" class="form-control" placeholder="Masukkan Alamat Pegawai/ASN..." name="alamat">
              </div>
              <div class="form-group">
                <label for=""><b>Golongan</b></label>
                <input type="text" class="form-control" placeholder="Masukkan Golongan Pegawai/ASN..." name="gol_terakhir">
              </div>
              <div class="form-group">
                <label for=""><b>SKPD</b></label>
                <select class="form-control" name="kd_skpd" required>
                  <option value="">.:: Pilih SKPD ::.</option>
                  <?php foreach($skpd as $s){ ?>
                  <option value="<?php echo $s->kd_skpd;?>"><?php echo $s->nama;?></option>
                  <?php } ?>
                </select>
              </div>
              
              
            </div>
            <div class="modal-footer">
              <button class="btn btn-primary" type="submit">Tambah</button>
            <?php echo form_close(); ?>
              <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
              
            </div>
          </div>
        </div>
      </div>


      <a href="<?php echo site_url('employee')?>" class="btn btn-success btn-icon-split btn-sm">
        <span class="icon text-white-50">
          <i class="fa fa-refresh"></i>
        </span>
        <span class="text">Refresh Halaman</span>
      </a> | 

      <a href="#" class="btn btn-danger btn-icon-split btn-sm" data-toggle="modal" data-target="#employeeModalFilter">
        <span class="icon text-white-50">
          <i class="fas fa-filter"></i>
        </span>
        <span class="text">Filter Berdasarkan SKPD</span>
      </a>

      <a href="#" class="btn btn-danger btn-icon-split btn-sm" data-toggle="modal" data-target="#employeeModalSearch">
        <span class="icon text-white-50">
          <i class="fas fa-search"></i>
        </span>
        <span class="text">Pencarian Menyeluruh</span>
      </a>

      <div class="modal fade" id="employeeModalFilter" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Filter Berdasarkan SKPD</h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <?php echo form_open_multipart("employee/reindex")?>
            <div class="modal-body">
              
              
              <div class="form-group">
                <label for=""><b>SKPD</b></label>
                <select id="skpd" class="form-control" name="skpd" style="width:100%" required>
                  <option value="">.:: Pilih SKPD ::.</option>
                  <?php foreach($skpd as $s){ ?>
                  <option value="<?php echo $s->kd_skpd;?>"><?php echo $s->nama;?></option>
                  <?php } ?>
                </select>
              </div>
              
              
            </div>
            <div class="modal-footer">
              <button class="btn btn-danger" type="submit">Filter</button>
            <?php echo form_close(); ?>
              <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
              
            </div>
          </div>
        </div>
      </div>


      <div class="modal fade" id="employeeModalSearch" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Pencarian Pegawai Menyeluruh</h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <?php echo form_open_multipart("employee/searchemployee")?>
            <div class="modal-body">
              
              
              <div class="form-group">
                <label for=""><b>Kata Kunci</b></label>
                <input type="text" name="key" placeholder="Cari berdasarkan NIP atau Nama Pegawai" class="form-control">
              </div>
              
              
            </div>
            <div class="modal-footer">
              <button class="btn btn-danger" type="submit">Cari</button>
            <?php echo form_close(); ?>
              <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
              
            </div>
          </div>
        </div>
      </div>

    <?php } ?>

    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th style="width: 5%;">No</th>
              <th style="width: 25%;">#</th>
              <th>NIP</th>
              <th style="width: 25%;">Nama</th>
              <th>SKPD</th>
              <th>Bagian</th>
            </tr>
          </thead>
          
          <tbody>
            <?php $no=1; foreach($employee as $key){?>
            <tr>
              <td><?php echo $no;?></td>
              <td>
                <?php if($this->session->userdata('group_id')==1){?>
                <a href="#" class="btn btn-danger btn-icon-split btn-sm" data-toggle="modal" data-target="#employeenonActiveModal<?php echo $key->id?>">
                  <span class="text">
                    <i class="fa fa-user-times"></i> NonAktif
                  </span>
                </a> | 
                <a href="#" class="btn btn-warning btn-icon-split btn-sm" data-toggle="modal" data-target="#employeeEditModal<?php echo $key->id?>">
                  <span class="text">
                    <i class="fa fa-edit"></i>
                  </span>
                </a>
                <?php } ?>
                <a href="#" class="btn btn-success btn-icon-split btn-sm" data-toggle="modal" data-target="#employeeMutasiModal<?php echo $key->id?>">
                  <span class="text">
                    <i class="fa fa-legal"></i> Mutasi
                  </span>
                </a>
              </td>
              <td><?php echo $key->nip?></td>
              <td><?php echo $key->nama?></td>
              <td><?php echo $key->nama_skpd?></td>
              <td><?php echo $key->bagian_bidang?></td>
            </tr>

              

            
              <div class="modal fade" id="employeeEditModal<?php echo $key->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Update Data Pegawai</h5>
                      <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                    <?php echo form_open("employee/edit")?>
                    <div class="modal-body">
                      <div class="form-group">
                        <label for=""><b>Nama Pegawai/ASN</b></label>
                        <input type="text" class="form-control" placeholder="Masukkan Nama Pegawai/ASN..." name="nama" required="required" value="<?php echo $key->nama?>">
                        <input type="hidden" class="form-control" placeholder="Masukkan Nama Pegawai/ASN..." name="id" required="required" value="<?php echo $key->id?>">
                      </div>
                      <div class="form-group">
                        <label for=""><b>NIP</b></label>
                        <input type="text" class="form-control" placeholder="Masukkan NIP Pegawai/ASN..." name="nip" required="required" value="<?php echo $key->nip?>">
                        <input type="hidden" class="form-control" name="old_nip" required="required" value="<?php echo $key->nip?>">
                      </div>
                      <div class="form-group">
                        <label for=""><b>Jenis Kelamin</b></label>
                        <select class="form-control" name="kelamin" required>
                          <option value="">.:: Pilih Jenis Kelamin ::.</option>
                          <?php if($key->kelamin=='L'){?>
                            <option value="L" selected>Laki-Laki</option>
                            <option value="P">Perempuan</option>
                          <?php }else{ ?>
                            <option value="L">Laki-Laki</option>
                            <option value="P" selected>Perempuan</option>
                          <?php } ?>
                        </select>
                      </div>
                      <div class="form-group">
                        <label for=""><b>Alamat</b></label>
                        <input type="text" class="form-control" placeholder="Masukkan Alamat Pegawai/ASN..." name="alamat" value="<?php echo $key->alamat?>">
                      </div>
                      <div class="form-group">
                        <label for=""><b>Golongan</b></label>
                        <input type="text" class="form-control" placeholder="Masukkan Golongan Pegawai/ASN..." name="gol_terakhir" value="<?php echo $key->gol_terakhir?>">
                      </div>
                      <div class="form-group">
                        <label for=""><b>SKPD</b></label>
                        <select class="form-control" name="kd_skpd" required>
                          <option value="">.:: Pilih SKPD ::.</option>
                          <?php foreach($skpd as $ss){ 
                            if($key->kd_skpd == $ss->kd_skpd){
                          ?>
                          <option value="<?php echo $ss->kd_skpd;?>" selected><?php echo $ss->nama;?></option>
                            <?php }else{ ?>
                          <option value="<?php echo $ss->kd_skpd;?>"><?php echo $ss->nama;?></option>
                          <?php } } ?>
                        </select>
                      </div>
                    </div>
                    <div class="modal-footer">
                      <button class="btn btn-warning" type="submit">Edit</button>
                    <?php echo form_close(); ?>
                      <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                      
                    </div>
                  </div>
                </div>
              </div>

              <div class="modal fade" id="employeenonActiveModal<?php echo $key->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Non Aktifkan Pegawai</h5>
                      <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                    <?php echo form_open("employee/doNonActive")?>
                    <div class="modal-body">
                      Apakah anda yakin akan menon-aktifkan pegawai atas nama : <b><?php echo $key->nama?></b>
                      <div class="form-group">
                        <!-- <label for=""><b>Nama Pegawai/ASN</b></label> -->
                        <input type="hidden" class="form-control" placeholder="Masukkan Nama Pegawai/ASN..." name="nip" required="required" value="<?php echo $key->nip?>">
                        <input type="hidden" class="form-control" placeholder="Masukkan Nama Pegawai/ASN..." name="nama" required="required" value="<?php echo $key->nama?>">
                        <input type="hidden" class="form-control" placeholder="Masukkan Nama Pegawai/ASN..." name="id" required="required" value="<?php echo $key->id?>">
                      </div>
                      <hr>
                      <div class="form-group">
                        <label for=""><b>Alasan Penon-Aktifan Pegawai</b></label>
                        <input type="text" class="form-control" placeholder="Keterangan/Alasan Penon-aktifan Pegawai..." name="keterangan">
                      </div>
                      
                    </div>
                    <div class="modal-footer">
                      <button class="btn btn-danger" type="submit">Non-Aktifkan</button>
                    <?php echo form_close(); ?>
                      <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                      
                    </div>
                  </div>
                </div>
              </div>

              <!-- employee Modal Remove-->
              <div class="modal fade" id="employeeMutasiModal<?php echo $key->id?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Mutasi Pegawai</h5>
                      <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                    <?php echo form_open("employee/mutasiFromSKPD")?>
                    <div class="modal-body">
                      Apakah anda yakin akan memutasi data Pegawai <b><?php echo $key->nama ?></b> ?
                      <input type="hidden" class="form-control" name="id" value="<?php echo $key->id?>">
                      <input type="hidden" class="form-control" name="nip" value="<?php echo $key->nip?>">
                      <input type="hidden" class="form-control" name="kd_skpd" value="<?php echo $key->kd_skpd?>">
                      
                      <hr><br>
                      Dengan ini berarti anda menyutujui melakukan mutasi dengan dasar surat perintah untuk memutasi di dinas anda.
                      <!-- <div class="form-group">
                        <label for=""><b>SKPD Mutasi</b></label>
                        <select class="form-control" name="kd_skpd" required>
                          <option value="">.:: Pilih SKPD ::.</option>
                          <?php foreach($skpd as $ss){ 
                            if($key->kd_skpd == $ss->kd_skpd){
                          ?>
                          <option value="<?php echo $ss->kd_skpd;?>" selected><?php echo $ss->nama;?></option>
                            <?php }else{?>
                          <option value="<?php echo $ss->kd_skpd;?>"><?php echo $ss->nama;?></option>
                          <?php } }?>
                        </select>
                      </div> -->
                    </div>
                    <div class="modal-footer">
                      <button class="btn btn-danger" type="submit">Mutasi</button>
                    <?php echo form_close(); ?>
                      <button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button>
                      
                    </div>
                  </div>
                </div>
              </div>



            <?php $no++; } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->
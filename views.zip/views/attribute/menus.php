<body id="page-top" class="sidebar-toggled fontPoppins">
    <div class="preloader">
			<div class="loading">
				<img src="<?php echo base_url();?>assets/img/load.gif" width="80">
				<p><b>Harap Tunggu</b></p>
			</div>
		</div>
  <?php require './assets/plugin-new/fungsi_indotgl.php';?>
  <div id="wrapper">
    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion toggled" id="accordionSidebar">
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo base_url()?>home">
        <div class="sidebar-brand-icon ">
          <i class="fa fa-globe"></i>
        </div>
        <div class="sidebar-brand-text mx-3"><?php echo $settings_app[0]->setting_short_appname?></div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item">
        <a class="nav-link" href="<?php echo base_url()?>home">
          <i class="fa fa-fw fa-home"></i>
          <span>Beranda</span></a>
      </li>
      <hr class="sidebar-divider d-none d-md-block">
      
      <!-- Admin SKPD -->
      <?php if($this->session->userdata('group_id')==99){?>
        <div class="sidebar-heading">
          Data Sistem
        </div>
        
        

        <li class="nav-item">
          <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#dataArsips" aria-expanded="true" aria-controls="dataArsip">
            <i class="fa fa-fw fa-list"></i>
            <span>Data Pegawai</span>
          </a>
          <div id="dataArsips" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              <h6 class="collapse-header">List Data:</h6>
              <a class="collapse-item" href="<?php echo site_url('employee/index/'.$this->session->userdata('skpd_id'))?>">Data Pegawai</a>
              <a class="collapse-item" href="<?php echo site_url('employee/account/'.$this->session->userdata('skpd_id'))?>">Akun Pegawai</a>

            </div>
          </div>
        </li>

        <li class="nav-item">
          <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#dataAabsen" aria-expanded="true" aria-controls="dataAabsen">
            <i class="fa fa-fw fa-calendar-check-o"></i>
            <span>Data Absensi</span>
          </a>
          <div id="dataAabsen" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              <h6 class="collapse-header">List Data:</h6>
              <a class="collapse-item" href="<?php echo site_url('attendance')?>">Absen Pagi</a>
              <a class="collapse-item" href="<?php echo site_url('attendance/pagi_lapangan')?>">Absen Pagi Lapangan</a>
              <hr>
              <a class="collapse-item" href="<?php echo site_url('attendance/sore')?>">Absen Sore</a>
              <a class="collapse-item" href="<?php echo site_url('attendance/sore_lapangan')?>">Absen Sore Lapangan</a>
            </div>
          </div>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('attendance/notattendance')?>">
            <i class="fa fa-fw fa-calendar-times-o"></i>
            <span>Pegawai Belum Absensi</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('employee/list_mutasi')?>">
            <i class="fa fa-fw fa-legal"></i>
            <span>Daftar Mutasi Pegawai</span></a>
        </li>
        
        
        <hr class="sidebar-divider d-none d-md-block">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('attendance/formizin')?>">
            <i class="fa fa-fw fa-ticket"></i>
            <span>Form Izin, Sakit, Cuti</span>
          </a>
        </li>
        <hr class="sidebar-divider d-none d-md-block">
        <div class="sidebar-heading">
          Setting
        </div>

        <li class="nav-item">
          <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#dataReport" aria-expanded="true" aria-controls="dataReport">
            <i class="fa fa-fw fa-print"></i>
            <span>Laporan</span>
          </a>
          <div id="dataReport" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
              <h6 class="collapse-header">List Data:</h6>
              <a class="collapse-item" href="<?php echo site_url('report/employee')?>">Laporan Pegawai</a>
              <a class="collapse-item" href="<?php echo site_url('report/monthly_attendance')?>">Laporan Absensi Bulanan</a>
              <a class="collapse-item" href="<?php echo site_url('report/monthly_skpd')?>">Rekap Absensi Bulanan SKPD</a>
              <hr>
              <a class="collapse-item" href="<?php echo site_url('report/attendance')?>">Laporan Absensi Harian Pagi</a>
              <a class="collapse-item" href="<?php echo site_url('report/attendance_sore')?>">Laporan Absensi Harian Sore</a>

            </div>
          </div>
        </li>

      <?php }?>


      <?php if($this->session->userdata('group_id')==1){?>
      
      <div class="sidebar-heading">
        Data Sistem
      </div>
      
      

      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#dataArsips" aria-expanded="true" aria-controls="dataArsip">
          <i class="fa fa-fw fa-list"></i>
          <span>Data Pegawai</span>
        </a>
        <div id="dataArsips" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">List Data:</h6>
            <a class="collapse-item" href="<?php echo site_url('employee')?>">List Pegawai</a>
            <a class="collapse-item" href="<?php echo site_url('employee/account')?>">Akun Pegawai</a>
            <a class="collapse-item" href="<?php echo site_url('employee/nonactive')?>" style="color:red">Pegawai Non-Aktif</a>
            <hr>
            <a class="collapse-item" href="<?php echo site_url('employee/admin_skpd')?>">Akun Admin SKPD</a>

          </div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#dataAabsen" aria-expanded="true" aria-controls="dataAabsen">
          <i class="fa fa-fw fa-calendar-check-o"></i>
          <span>Data Absensi</span>
        </a>
        <div id="dataAabsen" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">List Data:</h6>
            <a class="collapse-item" href="<?php echo site_url('attendance')?>">Absen Pagi</a>
            <a class="collapse-item" href="<?php echo site_url('attendance/pagi_lapangan')?>">Absen Pagi Lapangan</a>
            <hr>
            <a class="collapse-item" href="<?php echo site_url('attendance/sore')?>">Absen Sore</a>
            <a class="collapse-item" href="<?php echo site_url('attendance/sore_lapangan')?>">Absen Sore Lapangan</a>
          </div>
        </div>
      </li>
      <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('attendance/notattendance')?>">
            <i class="fa fa-fw fa-calendar-times-o"></i>
            <span>Pegawai Belum Absensi</span>
          </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('employee/list_mutasi')?>">
          <i class="fa fa-fw fa-legal"></i>
          <span>Daftar Mutasi Pegawai</span></a>
      </li>
      
      <hr class="sidebar-divider d-none d-md-block">
      <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('attendance/formizin')?>">
            <i class="fa fa-fw fa-ticket"></i>
            <span>Form Izin, Sakit, Cuti</span>
          </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('employee/violator')?>">
          <i class="fa fa-fw fa-ban"></i>
          <span>Pelanggar Area Kerja</span></a>
      </li>
      <hr class="sidebar-divider d-none d-md-block">
      <div class="sidebar-heading">
        Setting
      </div>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo site_url('home/grafik')?>">
          <i class="fa fa-fw fa-bar-chart"></i>
          <span>Grafik</span></a>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#dataReport" aria-expanded="true" aria-controls="dataReport">
          <i class="fa fa-fw fa-print"></i>
          <span>Laporan</span>
        </a>
        <div id="dataReport" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">List Data:</h6>
            <a class="collapse-item" href="<?php echo site_url('report/employee')?>">Laporan Pegawai</a>
            <a class="collapse-item" href="<?php echo site_url('report/monthly_attendance')?>">Laporan Absensi Bulanan</a>
            <a class="collapse-item" href="<?php echo site_url('report/monthly_skpd')?>">Rekap Absensi Bulanan SKPD</a>
            <hr>
            <a class="collapse-item" href="<?php echo site_url('report/attendance')?>">Laporan Absensi Harian Pagi</a>
            <a class="collapse-item" href="<?php echo site_url('report/attendance_sore')?>">Laporan Absensi Harian Sore</a>

          </div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#dataUmum" aria-expanded="true" aria-controls="dataUmum">
          <i class="fa fa-fw fa-map-pin"></i>
          <span>Data Umum</span>
        </a>
        <div id="dataUmum" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">List Data Umum:</h6>
            <a class="collapse-item" href="<?php echo site_url('skpd')?>">SKPD</a>
            <a class="collapse-item" href="<?php echo site_url('group')?>">Group</a>
            <a class="collapse-item" href="<?php echo site_url('user')?>">User</a>
            <hr>
            <a class="collapse-item" href="<?php echo site_url('rules')?>">Aturan Jam Absen</a>
          </div>
        </div>
      </li>
      
      <hr class="sidebar-divider d-none d-md-block">


      <?php } ?>
      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <img src="<?php echo base_url()?>upload/setting/<?php echo $settings_app[0]->setting_logo?>" height="40">&nbsp;&nbsp;<b><?php echo strtoupper($settings_app[0]->setting_appname)?></b><br>

          
          <ul class="navbar-nav ml-auto">
            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo strtoupper($this->session->userdata('user_name'))?></span>
                <?php if($this->session->userdata('user_photo')!=""){?>
                <img class="img-profile rounded-circle" src="<?php echo base_url()?>upload/user/<?php echo $this->session->userdata('user_photo');?>" style="border-radius: 50%" alt="User profile picture" height="200">
                <?php }else{ ?>
                <img class="img-profile rounded-circle" src="<?php echo base_url()?>upload/user/default_image.png" style="border-radius: 50%" alt="User profile picture" height="200">
                <?php } ?>
                
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
              <?php if($this->session->userdata('group_id')==1){?>  
                <a class="dropdown-item" href="<?php echo site_url('user/profile')?>">
                  <i class="fa fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Profile
                </a>
                <a class="dropdown-item" href="<?php echo site_url('setting')?>">
                  <i class="fa fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                  Settings
                </a>
                <a class="dropdown-item" href="<?php echo site_url('setting/log')?>">
                  <i class="fa fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                  Activity Log
                </a>
                <div class="dropdown-divider"></div>
                <?php } ?>
                
                <a class="dropdown-item" href="<?php echo site_url('home/logout');?>" data-toggle="modal" data-target="#logoutModal">
                  <i class="fa fa-key fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>
          </ul>
        </nav>
        <!-- End of Topbar -->
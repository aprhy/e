<!-- Begin Page Content -->
<div class="container-fluid">
  
  <!-- Page Heading -->
  <h1 class="h3 mb-4 text-gray-800">Beranda </h1>
  <?php if($this->session->userdata('group_id')==99){?>
    <p class="mb-4">Data Admin SKPD : <b><?php echo $this->session->userdata('user_skpd');?></b></p>
    <div class="row">

    <div class="col-xl-6 col-md-4 mb-4">
      <div class="card border-left-primary shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total ASN Terdaftar Pengawasan</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $asn?></div>
            </div>
            <div class="col-auto">
              <i class="fas fa-users fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-xl-6 col-md-4 mb-4">
      <div class="card border-left-primary shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Absensi Hari Ini</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo ($absen + $absen_lapangan)*1?></div>
            </div>
            <div class="col-auto">
              <i class="fas fa-users fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-xl-4 col-md-4 mb-4">
      <div class="card border-left-danger shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Total Tidak Absen Hari Ini</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $asn - (($absen + $absen_lapangan)*1);?></div>
            </div>
            <div class="col-auto">
              <i class="fas fa-users fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>


    

  </div>
  <?php }?>
  <hr>
  
  <?php if($this->session->userdata('group_id')==1){?>
  

  <div class="row">
    <div class="col-xl-12 col-md-12 mb-4">

      <?php
        if($this->session->flashdata('absensi')){
          echo "<span class='text-danger'>".$this->session->flashdata('absensi')."</span><hr>";
        }
      ?>


      <a href="#" class="btn btn-success btn-icon-split btn-sm" data-toggle="modal" data-target="#employeeModal">
        <span class="icon text-white-50">
          <i class="fas fa-search"></i>
        </span>
        <span class="text">Pencarian Data Pegawai (Global Data)</span>
      </a>

      
      <div class="modal fade" id="employeeModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Ketikkan Nama atau NIP Pegawai yang akan dicari</h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            
            <div class="modal-body">
              <div class="form-group">
                
                <input type="text" id="employee" class="form-control" placeholder="NIP atau Nama Pegawai..." name="nip" required="required">
              </div>
              <hr>
              <span id="daftar"></span>
              
              
            </div>
            
          </div>
        </div>
      </div>
      

      <a href="#" class="btn btn-danger btn-icon-split btn-sm" data-toggle="modal" data-target="#employeeModalTanggalMerah">
        <span class="icon text-white-50">
          <i class="fas fa-calendar"></i>
        </span>
        <span class="text">Absen Libur Tanggal Merah</span>
      </a>

      
      <div class="modal fade" id="employeeModalTanggalMerah" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Absen Libur Tanggal Merah</h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            
            <div class="modal-body">
              <?php echo form_open("attendance/libur_tanggal_merah")?>
              <div class="form-group">
                <span class="text-danger">*perhatian, untuk penentuan tanggal merah pastikan adalah benar tanggal merah sesuai kalender tahun berjalan</span>
                <input type="date" class="form-control" name="tanggal" required="required">
              </div>
              <button class="btn btn-primary" type="submit" >Libur Tanggal Merah</button>
              <?php echo form_close(); ?>
              
              
            </div>
            
          </div>
        </div>
      </div>
      
      <!--Tambah Cetak Upacara -->
      &nbsp; | <a href="#" class="btn btn-warning btn-icon-split btn-sm" data-toggle="modal" data-target="#employeeModalUpacara">
        <span class="icon text-white-50">
          <i class="fas fa-flag"></i>
        </span>
        <span class="text">Cetak Laporan Upacara</span>
      </a>

      
      <div class="modal fade" id="employeeModalUpacara" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Cetak Laporan Upacara</h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            
            <div class="modal-body">
              <?php echo form_open("report/print_daily_ceremony")?>
              <div class="form-group">
                <span class="text-danger">*Pilih tanggal untuk mencetak data pegawai yang mengikuti upacara</span>
                <input type="date" class="form-control" name="tanggal" required="required">
              </div>
              <button class="btn btn-primary" type="submit" >Cetak Laporan Upacara</button>
              <?php echo form_close(); ?>
              
              
            </div>
            
          </div>
        </div>
      </div>



    </div>
  </div>


  <div class="row">

    <div class="col-md-3 mb-4">
      <div class="card border-left-primary shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total ASN Terdaftar Pengawasan</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $asn?></div>
            </div>
            <div class="col-auto">
              <i class="fas fa-users fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-md-3 mb-4">
      <div class="card border-left-primary shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Absensi Hari Ini</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo ($absen + $absen_lapangan)*1?></div>
            </div>
            <div class="col-auto">
              <i class="fas fa-users fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-md-3 mb-4">
      <div class="card border-left-danger shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Total Tidak Absen Hari Ini</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $asn - (($absen + $absen_lapangan)*1);?></div>
            </div>
            <div class="col-auto">
              <i class="fas fa-users fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>


    <!--<div class="col-md-3 mb-4">-->
    <!--  <div class="card border-left-danger shadow h-100 py-2">-->
    <!--    <div class="card-body">-->
    <!--      <div class="row no-gutters align-items-center">-->
    <!--        <div class="col mr-2">-->
    <!--          <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Total Pelanggar Area Kerja (WFH) Hari Ini</div>-->
    <!--          <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $violator;?></div>-->
    <!--        </div>-->
    <!--        <div class="col-auto">-->
    <!--          <i class="fas fa-users fa-2x text-gray-300"></i>-->
    <!--        </div>-->
    <!--      </div>-->
    <!--    </div>-->
    <!--  </div>-->
    <!--</div>-->
    
    <div class="col-md-3 mb-4">
      <div class="card border-left-info shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Absen Upacara Hari Ini</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $upacara;?></div>
            </div>
            <div class="col-auto">
              <i class="fas fa-users fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>

  <!-- <div class="row">
    
    <div class="col-xl-6 col-md-6 mb-4">
      <div class="card border-left-warning shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Group</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $group?></div>
            </div>
            <div class="col-auto">
              <i class="fas fa-users fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-xl-6 col-md-6 mb-4">
      <div class="card border-left-info shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-info text-uppercase mb-1">User/Pengguna Sistem</div>
              <div class="row no-gutters align-items-center">
                <div class="col-auto">
                  <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?php echo $user?></div>
                </div>
              </div>
            </div>
            <div class="col-auto">
              <i class="fas fa-user fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>



  </div>
  -->
  
<?php }?>
  
  

  <script type="text/javascript">
    function getkecamatan(angka){
      var kecamatan = angka;
      console.log(kecamatan);
      $.ajax({
        success:function(){
          
          location.href='<?php echo base_url()?>home/index/'+angka;
          
        }
      });
    }
  </script>

</div>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="author" content="">
  <meta name="keywords" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Covid-19 Kota Kendari</title>
  <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url();?>assets/new-front/images/newkdi.png">
  <script src="<?php echo base_url();?>assets/new-front/js/libs/jquery-1.10.2.min.js"></script>
  <script src="<?php echo base_url();?>assets/new-front/js/libs/jquery-ui.min.js"></script>
  <script src="<?php echo base_url();?>assets/new-front/js/libs/bootstrap.min.js"></script>
  <link href="<?php echo base_url();?>assets/new-front/css/bootstrap.css" media="screen" rel="stylesheet">
  <link href="<?php echo base_url();?>assets/new-front/style.css" media="screen" rel="stylesheet">
  <script src="<?php echo base_url();?>assets/new-front/js/general.js"></script>
  <script src="<?php echo base_url();?>assets/new-front/js/jquery.customInput.js"></script>
  <script src="<?php echo base_url();?>assets/new-front/js/jquery.powerful-placeholder.min.js"></script>
  <script>
    jQuery(document).ready(function ($) {
      if ($("[placeholder]").size() > 0) {
        $.Placeholder.init();
      }
    });
  </script>
  <script src="<?php echo base_url();?>assets/new-front/js/jquery.carouFredSel-6.2.1-packed.js"></script>
  <link href="<?php echo base_url();?>assets/new-front/css/prettyPhoto.css" rel="stylesheet">
  <script src="<?php echo base_url();?>assets/new-front/js/jquery.prettyPhoto.js"></script>
  <link href="<?php echo base_url();?>assets/new-front/css/video-js.css" rel="stylesheet">
  <script src="<?php echo base_url();?>assets/new-front/js/video.js"></script>
  <link href="<?php echo base_url();?>assets/new-front/css/jplayer.css" rel="stylesheet">
  <script src="<?php echo base_url();?>assets/new-front/js/jquery.jplayer.min.js"></script>
  <script src="<?php echo base_url();?>assets/new-front/js/jplayer.playlist.min.js"></script>
  <script src="<?php echo base_url();?>assets/new-front/js/jquery-ui.multidatespicker.js"></script>
  <script src="<?php echo base_url();?>assets/new-front/js/jquery.slider.bundle.js"></script>
  <script src="<?php echo base_url();?>assets/new-front/js/jquery.slider.js"></script>
  <link href="<?php echo base_url();?>assets/new-front/css/jslider.css" rel="stylesheet">
  <script type="text/javascript" src="https://www.google.com/jsapi"></script>
  <script src="<?php echo base_url();?>assets/new-front/js/nicEdit.js"></script>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/new-front/css/chosen.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/new-front/css/hover.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/new-front/css/chosen.css">
  <script src="<?php echo base_url();?>assets/new-front/js/chosen.jquery.min.js"></script>
  <style type="text/css">
    body {
      background: url('<?php echo base_url();?>/assets/img/bg-tiga.png') no-repeat center center fixed; 
      -webkit-background-size: cover;
      -moz-background-size: cover;
      -o-background-size: cover;
      background-size: cover;
    }
  </style>
</head>

<body>

  <div class="">
    <?php include './assets/plugin-new/fungsi_indotgl.php';?>
    <div class="content">
      <!--container-->
      <div class="container-fluid" style="margin-left: 30px;margin-right: 30px;">
        <center>
          <img src="<?php echo base_url();?>assets/new-front/images/newkdi.png" width="80"><br>
          <h1 style="color: white; margin-bottom: 20px">Covid-19 Kota Kendari<br><?php echo tgl_indo(date('Y-m-d'))?></h1>
        </center>
        <br>
        <div class="row">
          <div class="col-md-12">
            <a href="<?php echo site_url('front/peta_kasus')?>" class="hvr-float">
              <div class="widget-container widget-profile boxed" >
                <center><br><img src="<?php echo base_url();?>assets/new-front/images/geolocalization.png" width="50" alt="" /></center>
                <div class="inner">
                  <h5 class="profile-title"><span>Kasus Covid-19 Kendari</span></h5>
                  <span class="profile-subtitle">Satgas Covid-19 Kendari</span>
                </div>
              </div>
            </a>
          </div>
          <div class="col-md-3">
            <a href="<?php echo site_url('front/peta_penyemprotan_fasilitas')?>" class="hvr-float">
              <div class="widget-container widget-profile boxed ">
                <center><br><img src="<?php echo base_url();?>assets/new-front/images/geolocalization.png" width="50" alt="" /></center>
                <div class="inner">
                  <h5 class="profile-title"><span>Penyemprotan Disinfektan <br>di Fasilitas Kota</span></h5>
                  <span class="profile-subtitle">Satgas Covid-19 Kendari</span>
                </div>
              </div>
            </a>
          </div>
          <div class="col-md-3">
            <a href="<?php echo site_url('front/peta_penyemprotan_jalan')?>" class="hvr-float">
              <div class="widget-container widget-profile boxed ">
                <center><br><img src="<?php echo base_url();?>assets/new-front/images/geolocalization.png" width="50" alt="" /></center>
                <div class="inner">
                  <h5 class="profile-title"><span>Penyemprotan Disinfektan <br>di Jalanan Kota</span></h5>
                  <span class="profile-subtitle">Satgas Covid-19 Kendari</span>
                </div>
              </div>
            </a>
          </div>
          <div class="col-md-3">
            <a href="<?php echo site_url('front/peta_penyemprotan_titik_masuk')?>" class="hvr-float">
              <div class="widget-container widget-profile boxed ">
                <center><br><img src="<?php echo base_url();?>assets/new-front/images/geolocalization.png" width="50" alt="" /></center>
                <div class="inner">
                  <h5 class="profile-title"><span>Pemeriksaan <br> Titik Masuk</span></h5>
                  <span class="profile-subtitle">Satgas Covid-19 Kendari</span>
                </div>
              </div>
            </a>
          </div>
          <div class="col-md-3">
            <a href="<?php echo site_url('front/peta_aktivitas_penanggulangan')?>" class="hvr-float">
              <div class="widget-container widget-profile boxed ">
                <center><br><img src="<?php echo base_url();?>assets/new-front/images/geolocalization.png" width="50" alt="" /></center>
                <div class="inner">
                  <h5 class="profile-title"><span>Aktivitas Penanggulangan &<br>Pencegahan Covid-19</span></h5>
                  <span class="profile-subtitle">Satgas Covid-19 Kendari</span>
                </div>
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>
    
  </div>
</body>

</html>
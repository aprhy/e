<html>
<head>
  <title>Peta Persebaran Covid-19 Kota Kendari</title>
  <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url();?>assets/new-front/images/newkdi.png">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/new-front/css/bootstrap.min.css">
  <link href="<?php echo base_url();?>assets/new-front/style.css" media="screen" rel="stylesheet">
  <?php include './assets/plugin-new/fungsi_indotgl.php';?>
  <style>
    html,
    body {
      height: 100%;
      margin: 0;
      padding: 0;
    }

    .containers,
    .containers>div,
    .containers>div #map-canvas {
      height: inherit;
    }

    
    #over_map { position: absolute; top: 10px; left: 10px; z-index: 99; }
    #over_map_string { position: absolute; bottom: 30px; left: 10px; z-index: 99; }

    .bottom0.panel-group {
      margin-bottom: 0;
      width: 80%;
    }

    .notifications-scroll-area {
      height: 390px;
      position: relative;
      overflow: auto;
    }

    #legend {
      font-family: Arial, sans-serif;
      background: #fff;
      padding: 10px;
      margin: 10px;
      border: 1px solid #000;
    }

    #legend h3 {
      margin-top: 0;
    }

    #legend img {
      vertical-align: middle;
    }
  </style>
  
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC8aB4MpC1orBp300KQQAiVEnWdpry4OPg"></script>
  <script>
         
  
    function initializeMap() {

      var styledMapType = new google.maps.StyledMapType(
        [{
            elementType: 'geometry',
            stylers: [{
              color: '#ebe3cd'
            }]
          },
          {
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#523735'
            }]
          },
          {
            elementType: 'labels.text.stroke',
            stylers: [{
              color: '#f5f1e6'
            }]
          },
          {
            featureType: 'administrative',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#c9b2a6'
            }]
          },
          {
            featureType: 'administrative.land_parcel',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#dcd2be'
            }]
          },
          {
            featureType: 'administrative.land_parcel',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#ae9e90'
            }]
          },
          {
            featureType: 'landscape.natural',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'poi',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'poi',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#93817c'
            }]
          },
          {
            featureType: 'poi.park',
            elementType: 'geometry.fill',
            stylers: [{
              color: '#a5b076'
            }]
          },
          {
            featureType: 'poi.park',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#447530'
            }]
          },
          {
            featureType: 'road',
            elementType: 'geometry',
            stylers: [{
              color: '#f5f1e6'
            }]
          },
          {
            featureType: 'road.arterial',
            elementType: 'geometry',
            stylers: [{
              color: '#fdfcf8'
            }]
          },
          {
            featureType: 'road.highway',
            elementType: 'geometry',
            stylers: [{
              color: '#f8c967'
            }]
          },
          {
            featureType: 'road.highway',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#e9bc62'
            }]
          },
          {
            featureType: 'road.highway.controlled_access',
            elementType: 'geometry',
            stylers: [{
              color: '#e98d58'
            }]
          },
          {
            featureType: 'road.highway.controlled_access',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#db8555'
            }]
          },
          {
            featureType: 'road.local',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#806b63'
            }]
          },
          {
            featureType: 'transit.line',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'transit.line',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#8f7d77'
            }]
          },
          {
            featureType: 'transit.line',
            elementType: 'labels.text.stroke',
            stylers: [{
              color: '#ebe3cd'
            }]
          },
          {
            featureType: 'transit.station',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'water',
            elementType: 'geometry.fill',
            stylers: [{
              color: '#b9d3c2'
            }]
          },
          {
            featureType: 'water',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#92998d'
            }]
          },
          {
            featureType: 'poi',
            stylers: [{visibility: 'off'}]
          },
        ], {
          name: 'Kendari Covid-19 Map : <?php echo tgl_indo(date('Y-m-d'))?>'
      });


      var myOptions = {
        center: new google.maps.LatLng(-3.984096, 122.554565),
        zoom: 13,
        mapTypeControlOptions: {
          mapTypeIds: [
            'styled_map','satellite'
          ]
        }
      };

      var mapCanvas = document.getElementById('map-canvas'); 
      var map = new google.maps.Map(mapCanvas, myOptions);
      
      map.mapTypes.set('styled_map', styledMapType);
      map.setMapTypeId('styled_map');

    }
     
     
    google.maps.event.addDomListener(window, 'load');
    
  </script>

  <script src="<?php echo base_url();?>assets/new-front/js/jquery.min.js"></script>
  <script src="<?php echo base_url();?>assets/new-front/js/bootstrap.min.js"></script>
 

  
</head>

<body onload="initializeMap()">
    
  <div class="containers">
    <div>
      <div id="map-canvas">
        
      </div>
      
    </div>
  </div>
  
  <a href="<?php echo base_url();?>" id="over_map" class="btn btn-icon btn-red" style="margin-left: 0px;margin-top: 50px"><span> Kembali</span></a>

  <h1 id="over_map_string">Silahkan pilih data yang ingin di cek jalur penyemprotannya pada data dibawah</h1>
  <div class="footer navbar-fixed-bottom">
    <div class="panel-group bottom0" id="accordion" role="tablist" aria-multiselectable="true">
      <div class="panel panel-primary">
        <div class="panel-heading" role="tab" id="headingOne" style="cursor: pointer" data-toggle="collapse"
          data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          <h4 class="panel-title">
            <i class="fa fa-info"></i>&nbsp;&nbsp;Data Penyemprotan Disinfektan di Jalanan Kota
          </h4>
        </div>
        <div id="collapseOne" class="panel-collapse collapse notifications-scroll-area" role="tabpanel"
          aria-labelledby="headingOne">
          <div class="panel-body ">
            

            <!--  -->
            <div class="tabs-framed tabs-small boxed">
              <ul class="tabs clearfix">
                  <li class="active"><a href="#tabel" data-toggle="tab">Data Tabel</a></li>
                  <!-- <li><a href="#grafik" data-toggle="tab">Data Grafik</a></li> -->
              </ul>

              <div class="tab-content">
                
                <div class="tab-pane fade in active" id="tabel">
                  <div class="price-item style4">
                    <div class="price-content clearfix">
                        
                      <table class="table table-striped table-bordered table-hover table-condensed">
                        <thead>
                          
                          <tr>
                            <th>No</th>
                            <th>OPD Penanggung Jawab</th>
                            <th>Lokasi Penyemprotan</th>
                            <th>Tanggal Penyemprotan</th>
                            <th>Aksi</th>
                            
                          </tr>
                          
                        
                        </thead>
                        <tbody>
                          <?php $no=1; foreach($pemeriksaan as $pmk){?>
                          <tr>
                            <td><?php echo $no;?></td>
                            <td>Dinas Kebakaran</td>
                            <td><?php echo $pmk->spraying_road_location;?></td>
                            <td><?php echo tgl_indo($pmk->spraying_road_date);?></td>
                            <td><a href="<?php echo site_url('front/peta_penyemprotan_jalan_detail/'.$pmk->spraying_road_id)?>">Cek Jalur</a></td>
                          </tr>
                          <?php $no++;} ?>

                        </tbody>
                      </table>
                    </div>
                    
                  </div>
                </div>

                <div class="tab-pane fade" id="grafik">
                  <div class="price-item style4">
                    <div class="price-content clearfix">
                      
                      
                    </div>
                    
                  </div>
                </div>

                  
 
              </div>
          </div>
          <!--/ Tabs -->
          </div>
        </div>
      </div>
    </div>
  </div>


  

</body>

</html>
<html>
<head>
  <title>Peta Persebaran Covid-19 Kota Kendari</title>
  <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url();?>assets/new-front/images/newkdi.png">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/new-front/css/bootstrap.min.css">
  <link href="<?php echo base_url();?>assets/new-front/style.css" media="screen" rel="stylesheet">
  <?php include './assets/plugin-new/fungsi_indotgl.php';?>
  <style>
    html,
    body {
      height: 100%;
      margin: 0;
      padding: 0;
    }

    .containers,
    .containers>div,
    .containers>div #map-canvas {
      height: inherit;
    }

    
    #over_map { position: absolute; top: 10px; left: 10px; z-index: 99; }
    #over_map_widget { position: absolute; bottom: 50px; left: 10px; z-index: 99; }

    .bottom0.panel-group {
      margin-bottom: 0;
      width: 80%;
    }

    .notifications-scroll-area {
      height: 390px;
      position: relative;
      overflow: auto;
    }

    #legend {
      font-family: Arial, sans-serif;
      background: #fff;
      padding: 10px;
      margin: 10px;
      border: 1px solid #000;
    }

    #legend h3 {
      margin-top: 0;
    }

    #legend img {
      vertical-align: middle;
    }
  </style>
  
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC8aB4MpC1orBp300KQQAiVEnWdpry4OPg"></script>
  <script>
         
    var markers = [
      <?php foreach ($kasus as $key) { 

        if($key->cases_positif > 0){
          $icon = base_url()."assets/img/red32.png";
        }else{
          if($key->cases_pdp_process > 0){
            $icon = base_url()."assets/img/orange32.png";
          }else{
            if($key->cases_odp_process > 0){
              $icon = base_url()."assets/img/yellow32.png";
            }else{
              $icon = base_url()."assets/img/green32.png";
            }
          }
        }



          $odp_proses = '<span style="color:#fce721">'.$key->cases_odp_process.'</span>';
          $pdp_proses = '<span style="color:orange">'.$key->cases_pdp_process.'</span>';
          $positif    = '<span style="color:red">'.$key->cases_positif.'</span>';
        
      ?>
      [
        '<?php echo "<b>Nama Kecamatan :</b> <br>".$key->sub_district_name."<br> <br>KASUS : <br><br>[ODP] Total ODP : ".$key->cases_odp." <br>[ODP] Selesai Pemantauan : ".$key->cases_odp_finish."<br>[ODP] Masih Pemantauan : ".$odp_proses."<br><hr>[PDP] Total PDP : ".$key->cases_odp." <br>[PDP] Selesai Pengawasan : ".$key->cases_pdp_finish."<br>[PDP] Masih Pengawasan : ".$pdp_proses."<br>[PDP] Positif : ".$positif."<br>"?>'
          
          
          , <?php echo $key->sub_district_coordinate?>, '<?php echo $icon?>'
      ],
    
      <?php } ?>
    ];
        
    
    function initializeMap() {

      var styledMapType = new google.maps.StyledMapType(
        [{
            elementType: 'geometry',
            stylers: [{
              color: '#ebe3cd'
            }]
          },
          {
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#523735'
            }]
          },
          {
            elementType: 'labels.text.stroke',
            stylers: [{
              color: '#f5f1e6'
            }]
          },
          {
            featureType: 'administrative',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#c9b2a6'
            }]
          },
          {
            featureType: 'administrative.land_parcel',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#dcd2be'
            }]
          },
          {
            featureType: 'administrative.land_parcel',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#ae9e90'
            }]
          },
          {
            featureType: 'landscape.natural',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'poi',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'poi',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#93817c'
            }]
          },
          {
            featureType: 'poi.park',
            elementType: 'geometry.fill',
            stylers: [{
              color: '#a5b076'
            }]
          },
          {
            featureType: 'poi.park',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#447530'
            }]
          },
          {
            featureType: 'road',
            elementType: 'geometry',
            stylers: [{
              color: '#f5f1e6'
            }]
          },
          {
            featureType: 'road.arterial',
            elementType: 'geometry',
            stylers: [{
              color: '#fdfcf8'
            }]
          },
          {
            featureType: 'road.highway',
            elementType: 'geometry',
            stylers: [{
              color: '#f8c967'
            }]
          },
          {
            featureType: 'road.highway',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#e9bc62'
            }]
          },
          {
            featureType: 'road.highway.controlled_access',
            elementType: 'geometry',
            stylers: [{
              color: '#e98d58'
            }]
          },
          {
            featureType: 'road.highway.controlled_access',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#db8555'
            }]
          },
          {
            featureType: 'road.local',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#806b63'
            }]
          },
          {
            featureType: 'transit.line',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'transit.line',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#8f7d77'
            }]
          },
          {
            featureType: 'transit.line',
            elementType: 'labels.text.stroke',
            stylers: [{
              color: '#ebe3cd'
            }]
          },
          {
            featureType: 'transit.station',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'water',
            elementType: 'geometry.fill',
            stylers: [{
              color: '#b9d3c2'
            }]
          },
          {
            featureType: 'water',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#92998d'
            }]
          },
          {
            featureType: 'poi',
            stylers: [{visibility: 'off'}]
          },
        ], {
          name: 'Kendari Covid-19 Map : <?php echo tgl_indo(date('Y-m-d'))?>'
      });


      var myOptions = {
        center: new google.maps.LatLng(-3.984096, 122.554565),
        zoom: 12,
        mapTypeControlOptions: {
          mapTypeIds: [
            'styled_map','satellite'
          ]
        }
      };

      var mapCanvas = document.getElementById('map-canvas'); 
      var map = new google.maps.Map(mapCanvas, myOptions);
      
      map.mapTypes.set('styled_map', styledMapType);
      map.setMapTypeId('styled_map');
     
      var infowindow = new google.maps.InfoWindow(), marker, i;
      
      
      for (i = 0; i < markers.length; i++) {  
        pos = new google.maps.LatLng(markers[i][1], markers[i][2]);
        marker = new google.maps.Marker({
            position: pos,
            map: map,
            icon : markers[i][3]
        });
        google.maps.event.addListener(marker, 'click', (function(marker, i) {
          return function() {
              infowindow.setContent(markers[i][0]);
              infowindow.open(map, marker);
          }
        })(marker, i));
      }

      var legend = document.getElementById('legend');
      var icons = {
        green: {
          name: 'Tanpa Kasus',
          icon: '<?php echo base_url();?>assets/img/green32.png'
        },
        yellow: {
          name: 'Ada ODP',
          icon: '<?php echo base_url();?>assets/img/yellow32.png'
        },
        orange: {
          name: 'Ada PDP',
          icon: '<?php echo base_url();?>assets/img/orange32.png'
        },
        red: {
          name: 'Covid-19',
          icon: '<?php echo base_url();?>assets/img/red32.png'
        }

      };
      for (var key in icons) {
        var type = icons[key];
        var name = type.name;
        var icon = type.icon;
        var div = document.createElement('div');
        div.innerHTML = '<img src="' + icon + '"> ' + name;
        legend.appendChild(div);
      }
      map.controls[google.maps.ControlPosition.RIGHT_TOP].push(legend);

    }
     
     
    google.maps.event.addDomListener(window, 'load');
    
  </script>

  <script src="<?php echo base_url();?>assets/new-front/js/jquery.min.js"></script>
  <script src="<?php echo base_url();?>assets/new-front/js/bootstrap.min.js"></script>
 

  
</head>

<body onload="initializeMap()">
    
  <div class="containers">
    <div>
      <div id="map-canvas">
        
      </div>
      <div id="legend"><h3><center><b>LEGENDA</b></center></h3><hr></div>
    </div>
  </div>


    <!-- WIDGET -->
        <div class="col-md-3" id="over_map_widget">
            <div id="carouselFade" class="carousel slide carousel-fade" data-ride="carousel" style="margin-top:5px;">
              <div class="carousel-inner slider-inner" role="listbox" style="width:100%;height:165px;background:white;border-radius:5px;">
                <div class="item active slider-item">
                  <br><br>
                  <center>
                    <b>TOTAL ORANG DALAM PEMANTAUAN [ODP]</b><br>
                    <span style="font-size:60px"><?php echo $widget[0]->total_odp?></span>
                    <br><hr>
                    <i>Source: Data SATGAS Covid-19 Kendari</i>
                  </center>
                </div>

                <div class="item slider-item">
                  <br><br>
                  <center>
                    <b>SELESAI DALAM PEMANTAUAN [ODP]</b><br>
                    <span style="color: #32a852;font-size:60px"><?php echo $widget[0]->total_odp_finish?></span>
                    <br><hr>
                    <i>Source: Data SATGAS Covid-19 Kendari</i>
                  </center>
                </div>

                <div class="item slider-item">
                  <br><br>
                  <center>
                    <b>MASIH DALAM PEMANTAUAN [ODP]</b><br>
                    <span style="color: yellow;font-size:60px"><?php echo $widget[0]->total_odp_process?></span>
                    <br><hr>
                    <i>Source: Data SATGAS Covid-19 Kendari</i>
                  </center>
                </div>
                <div class="item slider-item">
                  <br><br>
                  <center>
                    <b>TOTAL PASIEN DALAM PENGAWASAN [PDP]</b><br>
                    <span style="font-size:60px"><?php echo $widget[0]->total_pdp?></span>
                    <br><hr>
                    <i>Source: Data SATGAS Covid-19 Kendari</i>
                  </center>
                </div>
                <div class="item slider-item">
                  <br><br>
                  <center>
                    <b>SELESAI DALAM PENGAWASAN [PDP]</b><br>
                    <span style="color: #32a852;font-size:60px"><?php echo $widget[0]->total_pdp_finish?></span>
                    <br><hr>
                    <i>Source: Data SATGAS Covid-19 Kendari</i>
                  </center>
                </div>
                <div class="item slider-item">
                  <br><br>
                  <center>
                    <b>MASIH DALAM PENGAWASAN [PDP]</b><br>
                    <span style="color: #FA6121;font-size:60px"><?php echo $widget[0]->total_pdp_process?></span>
                    <br><hr>
                    <i>Source: Data SATGAS Covid-19 Kendari</i>
                  </center>
                </div>
                <div class="item slider-item">
                  <br><br>
                  <center>
                    <b>POSITIF COVID-19</b><br>
                    <span style="color: #f54242;font-size:60px"><?php echo $widget[0]->total_positif?></span>
                    <br><hr>
                    <i>Source: Data SATGAS Covid-19 Kendari</i>
                  </center>
                </div>
                
                

              </div>
          </div>
        </div>

    <!--  -->

  
  <a href="<?php echo base_url();?>" id="over_map" class="btn btn-icon btn-red" style="margin-left: 0px;margin-top: 50px"><span> Kembali</span></a>
  <div class="footer navbar-fixed-bottom">
    <div class="panel-group bottom0" id="accordion" role="tablist" aria-multiselectable="true">
      <div class="panel panel-primary">
        <div class="panel-heading" role="tab" id="headingOne" style="cursor: pointer" data-toggle="collapse"
          data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          <h4 class="panel-title">
            <i class="fa fa-info"></i>&nbsp;&nbsp;Data Kasus Covid-19 di Kota Kendari
          </h4>
        </div>
        <div id="collapseOne" class="panel-collapse collapse notifications-scroll-area" role="tabpanel"
          aria-labelledby="headingOne">
          <div class="panel-body ">
            

            <!--  -->
            <div class="tabs-framed tabs-small boxed">
              <ul class="tabs clearfix">
                  <li class="active"><a href="#tabel" data-toggle="tab">Data Tabel</a></li>
                  <li><a href="#grafik" data-toggle="tab">Data Grafik</a></li>
              </ul>

              <div class="tab-content">
                
                <div class="tab-pane fade in active" id="tabel">
                  <div class="price-item style4">
                    <div class="price-content clearfix">
                        
                      <table class="table table-striped table-bordered table-hover table-condensed">
                        <thead>
                          <tr>

                            <th>No</th>
                            <th>Kecamatan</th>
                            <th>Total ODP</th>
                            <th>Selesai Pemantauan</th>
                            <th style="background-color:yellow;color:black;">Proses Pemantauan</th>
                            <th>Total PDP</th>
                            <th>Selesai Pengawasan</th>
                            <th style="background-color:orange;color:black;">Proses Pengawasan</th>
                            <th style="background-color:red;color:black;">Positif Covid-19</th>
                            
                          </tr>
                        
                        </thead>
                        <tbody>
                          <?php 
                            $total_odp=0;$total_odp_finish=0;$total_odp_process=0;
                            $total_pdp=0;$total_pdp_finish=0;$total_pdp_process=0;$total_positif=0;
                            $no=1; foreach($kasus as $cx){?>
                          <tr>
                            <td><?php echo $no;?></td>
                            <td><?php echo $cx->sub_district_name;?></td>
                            <td><?php echo $cx->cases_odp;?></td>
                            <td><?php echo $cx->cases_odp_finish;?></td>
                            <td style="background-color:yellow;color:black;"><?php echo $cx->cases_odp_process;?></td>
                            <td><?php echo $cx->cases_pdp;?></td>
                            <td><?php echo $cx->cases_pdp_finish;?></td>
                            <td style="background-color:orange;color:black;"><?php echo $cx->cases_pdp_process;?></td>
                            <td style="background-color:red;color:black;"><?php echo $cx->cases_positif;?></td>
                            
                          </tr>
                          <?php 
                              $total_odp          =$total_odp+$cx->cases_odp;
                              $total_odp_finish   =$total_odp_finish + $cx->cases_odp_finish;
                              $total_odp_process  =$total_odp_process + $cx->cases_odp_process;

                              $total_pdp          =$total_pdp+$cx->cases_pdp;
                              $total_pdp_finish   =$total_pdp_finish + $cx->cases_pdp_finish;
                              $total_pdp_process  =$total_pdp_process + $cx->cases_pdp_process;
                              $total_positif      =$total_positif + $cx->cases_positif;
                              $no++;}
                          ?>
                          <tr>
                            <td colspan="2">#Total</td>
                            <td><?php echo $total_odp;?></td>
                            <td><?php echo $total_odp_finish;?></td>
                            <td style="background-color:yellow;color:black;"><?php echo $total_odp_process;?></td>
                            <td><?php echo $total_pdp;?></td>
                            <td><?php echo $total_pdp_finish;?></td>
                            <td style="background-color:orange;color:black;"><?php echo $total_pdp_process;?></td>
                            <td style="background-color:red;color:black;"><?php echo $total_positif;?></td>
                          </tr>

                        </tbody>
                      </table>
                    </div>
                    
                  </div>
                </div>

                <div class="tab-pane fade" id="grafik">
                  <div class="price-item style4">
                    <div class="price-content clearfix">
                      <script src="https://code.highcharts.com/highcharts.js"></script>
                      <script src="https://code.highcharts.com/modules/data.js"></script>
                      <script src="https://code.highcharts.com/modules/exporting.js"></script>
                      <script src="https://code.highcharts.com/modules/accessibility.js"></script>  
                      <div id="dinkes" style="height:240px;width:100%"></div>
                      <script>
                        Highcharts.chart('dinkes', {
                          chart: {
                              type: 'column'
                          },
                          title: {
                              text: 'Total Kasus Covid-19 Per-Kecamatan'
                          },
                          subtitle: {
                              text: 'Source: Kota Kendari'
                          },
                          xAxis: {
                              categories: [
                                  <?php foreach($kasus as $f){?>
                                  '<?php echo $f->sub_district_name?>',
                                  <?php } ?>
                              ],
                              crosshair: true
                          },
                          yAxis: {
                              min: 0,
                              title: {
                                  text: 'Total Kasus'
                              }
                          },
                          tooltip: {
                              headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                              pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                                  '<td style="padding:0"><b>{point.y:f} Kasus</b></td></tr>',
                              footerFormat: '</table>',
                              shared: true,
                              useHTML: true
                          },
                          plotOptions: {
                              column: {
                                  pointPadding: 0.2,
                                  borderWidth: 0
                              }
                          },
                          series: [
                            
                            {
                              name: 'ODP',
                              color: 'yellow',
                              data: [<?php for($odp_c=0;$odp_c<=10;$odp_c++){echo $kasus[$odp_c]->cases_odp_process.",";}?>]

                            },
                            {
                              name: 'PDP',
                              color: 'Orange',
                              data: [<?php for($pdp_c=0;$pdp_c<=10;$pdp_c++){echo $kasus[$pdp_c]->cases_pdp_process.",";}?>]

                            },
                            {
                              name: 'Positif Covid-19',
                              color: 'red',
                              data: [<?php for($pos_c=0;$pos_c<=10;$pos_c++){echo $kasus[$pos_c]->cases_positif.",";}?>]

                            },
                          ]
                      });
                      
                      </script>
                      
                    </div>
                    
                  </div>
                </div>

                  
 
              </div>
          </div>
          <!--/ Tabs -->
          </div>
        </div>
      </div>
    </div>
  </div>


  

</body>

</html>
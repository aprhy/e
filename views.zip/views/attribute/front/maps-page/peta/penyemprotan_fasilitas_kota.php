<html>
<head>
  <title>Peta Persebaran Covid-19 Kota Kendari</title>
  <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url();?>assets/new-front/images/newkdi.png">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/new-front/css/bootstrap.min.css">
  <link href="<?php echo base_url();?>assets/new-front/style.css" media="screen" rel="stylesheet">
  <?php include './assets/plugin-new/fungsi_indotgl.php';?>
  <style>
    html,
    body {
      height: 100%;
      margin: 0;
      padding: 0;
    }

    .containers,
    .containers>div,
    .containers>div #map-canvas {
      height: inherit;
    }

    
    #over_map { position: absolute; top: 10px; left: 10px; z-index: 99; }

    .bottom0.panel-group {
      margin-bottom: 0;
      width: 80%;
    }

    .notifications-scroll-area {
      height: 390px;
      position: relative;
      overflow: auto;
    }

    #legend {
      font-family: Arial, sans-serif;
      background: #fff;
      padding: 10px;
      margin: 10px;
      border: 1px solid #000;
    }

    #legend h3 {
      margin-top: 0;
    }

    #legend img {
      vertical-align: middle;
    }
  </style>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC8aB4MpC1orBp300KQQAiVEnWdpry4OPg"></script>
  <script>
         
    var markers = [
      <?php foreach ($penyemprotan as $key) { 
        if($key->facilities_id==1){
          $icon = 'http://maps.google.com/mapfiles/kml/pal2/icon13.png';
        }elseif($key->facilities_id==2){
          $icon = 'http://maps.google.com/mapfiles/kml/pal2/icon14.png';
        }elseif($key->facilities_id==3){
          $icon = 'http://maps.google.com/mapfiles/kml/pal3/icon48.png';
        }elseif($key->facilities_id==4){
          $icon = 'http://maps.google.com/mapfiles/kml/pal3/icon44.png';
        }elseif($key->facilities_id==5){
          $icon = 'http://maps.google.com/mapfiles/kml/pal2/icon2.png';
        }elseif($key->facilities_id==6){
          $icon = 'http://maps.google.com/mapfiles/kml/pal2/icon50.png';
        }else{
          $icon = 'http://maps.google.com/mapfiles/kml/pal2/icon1.png';
        }

        $status = '<span style="color:blue">'.$key->facilities_name.'</span>';
        $img = '<img src="'.base_url().'/upload/spraying/'.$key->spraying_photo.'" height="200px" >';
        if($key->spraying_opd == 1){
          $opd = "Dinas Kesehatan";
        }else{
          $opd = "BPBD";
        }
        
      ?>
      [
        '<?php echo "<b>Nama Lokasi :</b> <br>".$key->spraying_location."<br> <br><b>Kordinat :</b> <br>".$key->spraying_coordinate."<br><br> <b>Tanggal Penyemprotan :</b> <br>".tgl_indo($key->spraying_date)." <br><br> <b>Kategori Fasilitas :</b><br> ".$status."<br><br><b>OPD Penanggung Jawab :</b> <br>".$opd."<br><br><b>Gambar :</b> <br> ".$img ;?>', 
        <?php echo $key->spraying_coordinate?>, 
        '<?php echo $icon?>'
      ],
    
      <?php } ?>
    ];
        
    
    function initializeMap() {

      var styledMapType = new google.maps.StyledMapType(
        [{
            elementType: 'geometry',
            stylers: [{
              color: '#ebe3cd'
            }]
          },
          {
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#523735'
            }]
          },
          {
            elementType: 'labels.text.stroke',
            stylers: [{
              color: '#f5f1e6'
            }]
          },
          {
            featureType: 'administrative',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#c9b2a6'
            }]
          },
          {
            featureType: 'administrative.land_parcel',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#dcd2be'
            }]
          },
          {
            featureType: 'administrative.land_parcel',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#ae9e90'
            }]
          },
          {
            featureType: 'landscape.natural',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'poi',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'poi',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#93817c'
            }]
          },
          {
            featureType: 'poi.park',
            elementType: 'geometry.fill',
            stylers: [{
              color: '#a5b076'
            }]
          },
          {
            featureType: 'poi.park',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#447530'
            }]
          },
          {
            featureType: 'road',
            elementType: 'geometry',
            stylers: [{
              color: '#f5f1e6'
            }]
          },
          {
            featureType: 'road.arterial',
            elementType: 'geometry',
            stylers: [{
              color: '#fdfcf8'
            }]
          },
          {
            featureType: 'road.highway',
            elementType: 'geometry',
            stylers: [{
              color: '#f8c967'
            }]
          },
          {
            featureType: 'road.highway',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#e9bc62'
            }]
          },
          {
            featureType: 'road.highway.controlled_access',
            elementType: 'geometry',
            stylers: [{
              color: '#e98d58'
            }]
          },
          {
            featureType: 'road.highway.controlled_access',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#db8555'
            }]
          },
          {
            featureType: 'road.local',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#806b63'
            }]
          },
          {
            featureType: 'transit.line',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'transit.line',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#8f7d77'
            }]
          },
          {
            featureType: 'transit.line',
            elementType: 'labels.text.stroke',
            stylers: [{
              color: '#ebe3cd'
            }]
          },
          {
            featureType: 'transit.station',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'water',
            elementType: 'geometry.fill',
            stylers: [{
              color: '#b9d3c2'
            }]
          },
          {
            featureType: 'water',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#92998d'
            }]
          },
          {
            featureType: 'poi',
            stylers: [{visibility: 'off'}]
          },
        ], {
          name: 'Kendari Covid-19 Map : <?php echo tgl_indo(date('Y-m-d'))?>'
      });


      var myOptions = {
        center: new google.maps.LatLng(-3.984096, 122.554565),
        zoom: 14,
        mapTypeControlOptions: {
          mapTypeIds: [
            'styled_map','satellite'
          ]
        }
      };

      var mapCanvas = document.getElementById('map-canvas'); 
      var map = new google.maps.Map(mapCanvas, myOptions);
      
      map.mapTypes.set('styled_map', styledMapType);
      map.setMapTypeId('styled_map');
     
      var infowindow = new google.maps.InfoWindow(), marker, i;
      
      
      for (i = 0; i < markers.length; i++) {  
        pos = new google.maps.LatLng(markers[i][1], markers[i][2]);
        marker = new google.maps.Marker({
            position: pos,
            map: map,
            icon : markers[i][3]
        });
        google.maps.event.addListener(marker, 'click', (function(marker, i) {
          return function() {
              infowindow.setContent(markers[i][0]);
              infowindow.open(map, marker);
          }
        })(marker, i));
      }

      var legend = document.getElementById('legend');
      var icons = {
        fasilitas_umum: {
          name: 'Fasilitas Umum',
          icon: 'http://maps.google.com/mapfiles/kml/pal2/icon13.png'
        },
        perkantoran: {
          name: 'Perkantoran',
          icon: 'http://maps.google.com/mapfiles/kml/pal2/icon14.png'
        },
        rumah: {
          name: 'Rumah Warga(ODP/PDP)',
          icon: 'http://maps.google.com/mapfiles/kml/pal3/icon48.png'
        },
        sarana_ibadah: {
          name: 'Sarana Ibadah',
          icon: 'http://maps.google.com/mapfiles/kml/pal3/icon44.png'
        },
        sarana_pendidikan: {
          name: 'Sarana Pendidikan',
          icon: 'http://maps.google.com/mapfiles/kml/pal2/icon2.png'
        },
        pertokoan: {
          name: 'Pertokoan',
          icon: 'http://maps.google.com/mapfiles/kml/pal2/icon50.png'
        },
        pemukiman: {
          name: 'Pemukiman',
          icon: 'http://maps.google.com/mapfiles/kml/pal2/icon1.png'
        }

      };
      for (var key in icons) {
        var type = icons[key];
        var name = type.name;
        var icon = type.icon;
        var div = document.createElement('div');
        div.innerHTML = '<img src="' + icon + '"> ' + name;
        legend.appendChild(div);
      }
      map.controls[google.maps.ControlPosition.RIGHT_TOP].push(legend);

    }
     
     
    google.maps.event.addDomListener(window, 'load');
    
  </script>

  <script src="<?php echo base_url();?>assets/new-front/js/jquery.min.js"></script>
  <script src="<?php echo base_url();?>assets/new-front/js/bootstrap.min.js"></script>
 

  
</head>

<body onload="initializeMap()">
    
  <div class="containers">
    <div>
      <div id="map-canvas">
        
      </div>
      <div id="legend"><h3><center><b>LEGENDA</b></center></h3><hr></div>
    </div>
  </div>
  
  <a href="<?php echo base_url();?>" id="over_map" class="btn btn-icon btn-red" style="margin-left: 0px;margin-top: 50px"><span> Kembali</span></a>
  <div class="footer navbar-fixed-bottom">
    <div class="panel-group bottom0" id="accordion" role="tablist" aria-multiselectable="true">
      <div class="panel panel-primary">
        <div class="panel-heading" role="tab" id="headingOne" style="cursor: pointer" data-toggle="collapse"
          data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          <h4 class="panel-title">
            <i class="fa fa-info"></i>&nbsp;&nbsp;Data Penyemprotan Disinfektan di Fasilitas Kota
          </h4>
        </div>
        <div id="collapseOne" class="panel-collapse collapse notifications-scroll-area" role="tabpanel"
          aria-labelledby="headingOne">
          <div class="panel-body ">
            

            <!--  -->
            <div class="tabs-framed tabs-small boxed">
              <ul class="tabs clearfix">
                  <li class="active"><a href="#tabel" data-toggle="tab">Data Tabel</a></li>
                  <li><a href="#grafik" data-toggle="tab">Data Grafik</a></li>
              </ul>

              <div class="tab-content">
                
                <div class="tab-pane fade in active" id="tabel">
                  <div class="price-item style4">
                    <div class="price-content clearfix">
                        
                      <table class="table table-striped table-bordered table-hover table-condensed">
                        <thead>
                          
                          <tr>
                            <th rowspan="2">NO</th>
                            <th rowspan="2">OPD</th>
                            <th colspan="7"><center>Penyemprotan Disinfektan</center></th>
                          </tr>
                          <tr>
                          
                            <th>Fasilitas Umum</th>
                            <th>Perkantoran</th>
                            <th>Rumah Warga(ODP/PDP)</th>
                            <th>Sarana Ibadah</th>
                            <th>Sarana Pendidikan</th>
                            <th>Pemukiman</th>
                            <th>Pertokoan</th>
                            
                          </tr>
                        
                        </thead>
                        <tbody>
                          <tr>
                            <td>1</td>
                            <td>Dinas Kesehatan</td>
                            <?php foreach($spraying as $dk){?>
                            <td><?php echo $dk->jumlah?></td>
                            <?php } ?>
                            
                          </tr>
                          <tr>
                            <td>2</td>
                            <td>BPBD</td>
                            <?php foreach($spraying as $bp){?>
                            <td><?php echo $bp->jumlah_bpbd?></td>
                            <?php } ?>
                          </tr>

                        </tbody>
                      </table>
                    </div>
                    
                  </div>
                </div>

                <div class="tab-pane fade" id="grafik">
                  <div class="price-item style4">
                    <div class="price-content clearfix">
                      <script src="https://code.highcharts.com/highcharts.js"></script>
                      <script src="https://code.highcharts.com/modules/data.js"></script>
                      <script src="https://code.highcharts.com/modules/exporting.js"></script>
                      <script src="https://code.highcharts.com/modules/accessibility.js"></script>  
                      <div id="dinkes" style="height:240px;"></div>
                      <script>
                        Highcharts.chart('dinkes', {
                          chart: {
                              type: 'column'
                          },
                          title: {
                              text: 'Total Penyemprotan Disinfektan di Fasilitas Kota'
                          },
                          subtitle: {
                              text: 'Source: Kota Kendari'
                          },
                          xAxis: {
                              categories: [
                                  <?php foreach($facilities as $f){?>
                                  '<?php echo $f->facilities_name?>',
                                  <?php } ?>
                              ],
                              crosshair: true
                          },
                          yAxis: {
                              min: 0,
                              title: {
                                  text: 'Total Penyemprotan Disinfektan'
                              }
                          },
                          tooltip: {
                              headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                              pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                                  '<td style="padding:0"><b>{point.y:f} Penyemprotan</b></td></tr>',
                              footerFormat: '</table>',
                              shared: true,
                              useHTML: true
                          },
                          plotOptions: {
                              column: {
                                  pointPadding: 0.2,
                                  borderWidth: 0
                              }
                          },
                          series: [{
                              name: 'Dinas Kesehatan',
                              color: '#2124db',
                              data: [<?php $no=1; foreach($spraying as $dinkes){ echo $dinkes->jumlah.",";}?>]

                          },
                          {
                              name: 'BPBD',
                              color: '#b621db',
                              data: [<?php $no=1; foreach($spraying as $bpbd){ echo $bpbd->jumlah_bpbd.",";}?>]

                          }]
                      });
                      
                      </script>
                      
                    </div>
                    
                  </div>
                </div>

                  
 
              </div>
          </div>
          <!--/ Tabs -->
          </div>
        </div>
      </div>
    </div>
  </div>


  

</body>

</html>
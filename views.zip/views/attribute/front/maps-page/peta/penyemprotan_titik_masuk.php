<html>
<head>
  <title>Peta Persebaran Covid-19 Kota Kendari</title>
  <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url();?>assets/new-front/images/newkdi.png">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/new-front/css/bootstrap.min.css">
  <link href="<?php echo base_url();?>assets/new-front/style.css" media="screen" rel="stylesheet">
  <?php include './assets/plugin-new/fungsi_indotgl.php';?>
  <style>
    html,
    body {
      height: 100%;
      margin: 0;
      padding: 0;
    }

    .containers,
    .containers>div,
    .containers>div #map-canvas {
      height: inherit;
    }

    
    #over_map { position: absolute; top: 10px; left: 10px; z-index: 99; }

    .bottom0.panel-group {
      margin-bottom: 0;
      width: 80%;
    }

    .notifications-scroll-area {
      height: 390px;
      position: relative;
      overflow: auto;
    }

    #legend {
      font-family: Arial, sans-serif;
      background: #fff;
      padding: 10px;
      margin: 10px;
      border: 1px solid #000;
    }

    #legend h3 {
      margin-top: 0;
    }

    #legend img {
      vertical-align: middle;
    }
  </style>
  <?php $total_minibus=0;$total_truck=0;$total_bus=0;$total_penumpang=0;?>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC8aB4MpC1orBp300KQQAiVEnWdpry4OPg"></script>
  <script>
         
    var markers = [
      <?php foreach ($pemeriksaan as $key) { 
         $total_minibus=$total_minibus + $key->mini_bus;
         $total_truck=$total_truck + $key->truck;
         $total_bus=$total_bus + $key->bus;
         $total_penumpang=$total_penumpang + $key->penumpang;

         $img = '<img src="'.base_url().'/upload/inspection/vehicle/'.$key->inspection_vehicle_photo.'" height="200px" >';
        
      ?>
      [
        '<?php echo "<b>Nama Lokasi :</b> <br>".$key->inspection_vehicle_location."<br> <br><b>Kordinat Lokasi :</b> <br>".$key->inspection_vehicle_coordinate."<br><br> <b>Tanggal Pemeriksaan :</b> <br>".tgl_indo($key->inspection_vehicle_date)." <br><br> <b>OPD Penanggung Jawan :</b><br> Dinas Perhubungan <br><br><b>Pemeriksaan & Penyemprotan :</b><br>Mini-Bus : ".$key->mini_bus." <br>Truck : ".$key->truck."<br>Bus : ".$key->bus."<br>Penumpang : ".$key->penumpang." <br><br><b>Gambar :</b> <br> ".$img ;?>', <?php echo $key->inspection_vehicle_coordinate?>
      ],
    
      <?php } ?>
    ];
        
    
    function initializeMap() {

      var styledMapType = new google.maps.StyledMapType(
        [{
            elementType: 'geometry',
            stylers: [{
              color: '#ebe3cd'
            }]
          },
          {
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#523735'
            }]
          },
          {
            elementType: 'labels.text.stroke',
            stylers: [{
              color: '#f5f1e6'
            }]
          },
          {
            featureType: 'administrative',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#c9b2a6'
            }]
          },
          {
            featureType: 'administrative.land_parcel',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#dcd2be'
            }]
          },
          {
            featureType: 'administrative.land_parcel',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#ae9e90'
            }]
          },
          {
            featureType: 'landscape.natural',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'poi',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'poi',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#93817c'
            }]
          },
          {
            featureType: 'poi.park',
            elementType: 'geometry.fill',
            stylers: [{
              color: '#a5b076'
            }]
          },
          {
            featureType: 'poi.park',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#447530'
            }]
          },
          {
            featureType: 'road',
            elementType: 'geometry',
            stylers: [{
              color: '#f5f1e6'
            }]
          },
          {
            featureType: 'road.arterial',
            elementType: 'geometry',
            stylers: [{
              color: '#fdfcf8'
            }]
          },
          {
            featureType: 'road.highway',
            elementType: 'geometry',
            stylers: [{
              color: '#f8c967'
            }]
          },
          {
            featureType: 'road.highway',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#e9bc62'
            }]
          },
          {
            featureType: 'road.highway.controlled_access',
            elementType: 'geometry',
            stylers: [{
              color: '#e98d58'
            }]
          },
          {
            featureType: 'road.highway.controlled_access',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#db8555'
            }]
          },
          {
            featureType: 'road.local',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#806b63'
            }]
          },
          {
            featureType: 'transit.line',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'transit.line',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#8f7d77'
            }]
          },
          {
            featureType: 'transit.line',
            elementType: 'labels.text.stroke',
            stylers: [{
              color: '#ebe3cd'
            }]
          },
          {
            featureType: 'transit.station',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'water',
            elementType: 'geometry.fill',
            stylers: [{
              color: '#b9d3c2'
            }]
          },
          {
            featureType: 'water',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#92998d'
            }]
          },
          {
            featureType: 'poi',
            stylers: [{visibility: 'off'}]
          },
        ], {
          name: 'Kendari Covid-19 Map : <?php echo tgl_indo(date('Y-m-d'))?>'
      });


      var myOptions = {
        center: new google.maps.LatLng(-3.984096, 122.554565),
        zoom: 12,
        mapTypeControlOptions: {
          mapTypeIds: [
            'styled_map','satellite'
          ]
        }
      };

      var mapCanvas = document.getElementById('map-canvas'); 
      var map = new google.maps.Map(mapCanvas, myOptions);
      
      map.mapTypes.set('styled_map', styledMapType);
      map.setMapTypeId('styled_map');
     
      var infowindow = new google.maps.InfoWindow(), marker, i;
      
      
      for (i = 0; i < markers.length; i++) {  
        pos = new google.maps.LatLng(markers[i][1], markers[i][2]);
        marker = new google.maps.Marker({
            position: pos,
            map: map,
            icon : 'http://maps.google.com/mapfiles/kml/pal5/icon4.png'
        });
        google.maps.event.addListener(marker, 'click', (function(marker, i) {
          return function() {
              infowindow.setContent(markers[i][0]);
              infowindow.open(map, marker);
          }
        })(marker, i));
      }

      var legend = document.getElementById('legend');
      var icons = {
        titik_masuk: {
          name: 'Titik Masuk',
          icon: 'http://maps.google.com/mapfiles/kml/pal5/icon4.png'
        }

      };
      for (var key in icons) {
        var type = icons[key];
        var name = type.name;
        var icon = type.icon;
        var div = document.createElement('div');
        div.innerHTML = '<img src="' + icon + '"> ' + name;
        legend.appendChild(div);
      }
      map.controls[google.maps.ControlPosition.RIGHT_TOP].push(legend);

    }
     
     
    google.maps.event.addDomListener(window, 'load');
    
  </script>

  <script src="<?php echo base_url();?>assets/new-front/js/jquery.min.js"></script>
  <script src="<?php echo base_url();?>assets/new-front/js/bootstrap.min.js"></script>
 

  
</head>

<body onload="initializeMap()">
    
  <div class="containers">
    <div>
      <div id="map-canvas">
        
      </div>
      <div id="legend"><h3><center><b>LEGENDA</b></center></h3><hr></div>
    </div>
  </div>
  
  <a href="<?php echo base_url();?>" id="over_map" class="btn btn-icon btn-red" style="margin-left: 0px;margin-top: 50px"><span> Kembali</span></a>
  <div class="footer navbar-fixed-bottom">
    <div class="panel-group bottom0" id="accordion" role="tablist" aria-multiselectable="true">
      <div class="panel panel-primary">
        <div class="panel-heading" role="tab" id="headingOne" style="cursor: pointer" data-toggle="collapse"
          data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          <h4 class="panel-title">
            <i class="fa fa-info"></i>&nbsp;&nbsp;Data Pemeriksaan Titik Masuk
          </h4>
        </div>
        <div id="collapseOne" class="panel-collapse collapse notifications-scroll-area" role="tabpanel"
          aria-labelledby="headingOne">
          <div class="panel-body ">
            

            <!--  -->
            <div class="tabs-framed tabs-small boxed">
              <ul class="tabs clearfix">
                  <li class="active"><a href="#tabel" data-toggle="tab">Data Tabel</a></li>
                  <li><a href="#grafik" data-toggle="tab">Data Grafik</a></li>
              </ul>

              <div class="tab-content">
                
                <div class="tab-pane fade in active" id="tabel">
                  <div class="price-item style4">
                    <div class="price-content clearfix">
                        
                      <table class="table table-striped table-bordered table-hover table-condensed">
                        <thead>
                          
                          <tr>
                            <th rowspan="2">NO</th>
                            <th rowspan="2">OPD</th>
                            <th colspan="7"><center>Pemeriksaan Titik Masuk</center></th>
                          </tr>
                          <tr>
                          
                            <th>Mini Bus</th>
                            <th>Truk</th>
                            <th>Bus</th>
                            <th>Penumpang</th>
                            
                          </tr>
                        
                        </thead>
                        <tbody>
                          <tr>
                            <td>1</td>
                            <td>Dinas Perhubungan</td>
                            <td><?php echo $total_minibus;?></td>
                            <td><?php echo $total_truck;?></td>
                            <td><?php echo $total_bus;?></td>
                            <td><?php echo $total_penumpang;?></td>
                            
                          </tr>

                        </tbody>
                      </table>
                    </div>
                    
                  </div>
                </div>

                <div class="tab-pane fade" id="grafik">
                  <div class="price-item style4">
                    <div class="price-content clearfix">
                      <script src="https://code.highcharts.com/highcharts.js"></script>
                      <script src="https://code.highcharts.com/modules/data.js"></script>
                      <script src="https://code.highcharts.com/modules/exporting.js"></script>
                      <script src="https://code.highcharts.com/modules/accessibility.js"></script>  
                      <div id="grf1" style="height:240px;width:40%;float:left"></div>
                      <div id="grf2" style="height:240px;width:60%"></div>
                      <script>
                        Highcharts.chart('grf1', {
                          chart: {
                              type: 'column'
                          },
                          title: {
                              text: 'Total Pemeriksaan Titik Masuk Kota Berdasarkan Kendaraan'
                          },
                          subtitle: {
                              text: 'Source: Kota Kendari'
                          },
                          xAxis: {
                              categories: [
                                  
                              ],
                              crosshair: true
                          },
                          yAxis: {
                              min: 0,
                              title: {
                                  text: 'Total Penyemprotan Disinfektan'
                              }
                          },
                          tooltip: {
                              headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                              pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                                  '<td style="padding:0"><b>{point.y:f} Penyemprotan</b></td></tr>',
                              footerFormat: '</table>',
                              shared: true,
                              useHTML: true
                          },
                          plotOptions: {
                              column: {
                                  pointPadding: 0.2,
                                  borderWidth: 0
                              }
                          },
                          series: [{
                              name: 'Mini Bus',
                              color: '#9613c2',
                              data: [<?php echo ($total_minibus);?>]

                          },
                          {
                              name: 'Truk',
                              color: '#1356c2',
                              data: [<?php echo $total_truck;?>]

                          },
                          {
                              name: 'Bus',
                              color: '#11bd22',
                              data: [<?php echo $total_bus;?>]

                          }]
                      });
                      
                      </script>

                      <script>
                        Highcharts.chart('grf2', {
                          chart: {
                              type: 'column'
                          },
                          title: {
                              text: 'Total Pemeriksaan Titik Masuk Kota Berdasarkan Kelompok'
                          },
                          subtitle: {
                              text: 'Source: Kota Kendari'
                          },
                          xAxis: {
                              categories: [
                                  
                              ],
                              crosshair: true
                          },
                          yAxis: {
                              min: 0,
                              title: {
                                  text: 'Total Penyemprotan Disinfektan'
                              }
                          },
                          tooltip: {
                              headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                              pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                                  '<td style="padding:0"><b>{point.y:f} Penyemprotan</b></td></tr>',
                              footerFormat: '</table>',
                              shared: true,
                              useHTML: true
                          },
                          plotOptions: {
                              column: {
                                  pointPadding: 0.2,
                                  borderWidth: 0
                              }
                          },
                          series: [{
                              name: 'Kendaraan',
                              color: '#e60e19',
                              data: [<?php echo ($total_minibus+$total_truck+$total_bus);?>]

                          },
                          {
                              name: 'Penumpang',
                              color: '#d8e30b',
                              data: [<?php echo $total_penumpang;?>]

                          }]
                      });
                      
                      </script>
                      
                    </div>
                    
                  </div>
                </div>

                  
 
              </div>
          </div>
          <!--/ Tabs -->
          </div>
        </div>
      </div>
    </div>
  </div>


  

</body>

</html>
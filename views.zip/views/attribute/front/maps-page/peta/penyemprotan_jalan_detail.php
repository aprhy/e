<html>
<head>
  <title>Peta Persebaran Covid-19 Kota Kendari</title>
  <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url();?>assets/new-front/images/newkdi.png">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/new-front/css/bootstrap.min.css">
  <link href="<?php echo base_url();?>assets/new-front/style.css" media="screen" rel="stylesheet">
  <?php include './assets/plugin-new/fungsi_indotgl.php';?>
  <style>
    html,
    body {
      height: 100%;
      margin: 0;
      padding: 0;
    }

    .containers,
    .containers>div,
    .containers>div #map-canvas {
      height: inherit;
    }

    
    #over_map { position: absolute; top: 10px; left: 10px; z-index: 99; }
    #over_map_img { position: absolute; bottom: 50px; left: 10px; z-index: 99; }

    .bottom0.panel-group {
      margin-bottom: 0;
      width: 80%;
    }

    .notifications-scroll-area {
      height: 390px;
      position: relative;
      overflow: auto;
    }

    #legend {
      font-family: Arial, sans-serif;
      background: #fff;
      padding: 10px;
      margin: 10px;
      border: 1px solid #000;
    }

    #legend h3 {
      margin-top: 0;
    }

    #legend img {
      vertical-align: middle;
    }
  </style>
  
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC8aB4MpC1orBp300KQQAiVEnWdpry4OPg"></script>
  <script>
         
    var markers = [
      <?php foreach ($pemeriksaan_detail as $key) { ?>
      [
        '<?php echo "<b>Nama Titik Semprot :</b><br>".$key->coordinate_name."<br><br><b>Titik Kordinat :</b><br>".$key->coordinate."<br><br><b>Tanggal Semprot :</b><br>".tgl_indo($pemeriksaan[0]->spraying_road_date) ?>', <?php echo $key->coordinate?>
      ],
    
      <?php } ?>
    ];
        
    
    function initializeMap() {

      var styledMapType = new google.maps.StyledMapType(
        [{
            elementType: 'geometry',
            stylers: [{
              color: '#ebe3cd'
            }]
          },
          {
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#523735'
            }]
          },
          {
            elementType: 'labels.text.stroke',
            stylers: [{
              color: '#f5f1e6'
            }]
          },
          {
            featureType: 'administrative',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#c9b2a6'
            }]
          },
          {
            featureType: 'administrative.land_parcel',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#dcd2be'
            }]
          },
          {
            featureType: 'administrative.land_parcel',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#ae9e90'
            }]
          },
          {
            featureType: 'landscape.natural',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'poi',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'poi',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#93817c'
            }]
          },
          {
            featureType: 'poi.park',
            elementType: 'geometry.fill',
            stylers: [{
              color: '#a5b076'
            }]
          },
          {
            featureType: 'poi.park',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#447530'
            }]
          },
          {
            featureType: 'road',
            elementType: 'geometry',
            stylers: [{
              color: '#f5f1e6'
            }]
          },
          {
            featureType: 'road.arterial',
            elementType: 'geometry',
            stylers: [{
              color: '#fdfcf8'
            }]
          },
          {
            featureType: 'road.highway',
            elementType: 'geometry',
            stylers: [{
              color: '#f8c967'
            }]
          },
          {
            featureType: 'road.highway',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#e9bc62'
            }]
          },
          {
            featureType: 'road.highway.controlled_access',
            elementType: 'geometry',
            stylers: [{
              color: '#e98d58'
            }]
          },
          {
            featureType: 'road.highway.controlled_access',
            elementType: 'geometry.stroke',
            stylers: [{
              color: '#db8555'
            }]
          },
          {
            featureType: 'road.local',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#806b63'
            }]
          },
          {
            featureType: 'transit.line',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'transit.line',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#8f7d77'
            }]
          },
          {
            featureType: 'transit.line',
            elementType: 'labels.text.stroke',
            stylers: [{
              color: '#ebe3cd'
            }]
          },
          {
            featureType: 'transit.station',
            elementType: 'geometry',
            stylers: [{
              color: '#dfd2ae'
            }]
          },
          {
            featureType: 'water',
            elementType: 'geometry.fill',
            stylers: [{
              color: '#b9d3c2'
            }]
          },
          {
            featureType: 'water',
            elementType: 'labels.text.fill',
            stylers: [{
              color: '#92998d'
            }]
          },
          {
            featureType: 'poi',
            stylers: [{visibility: 'off'}]
          },
        ], {
          name: 'Kendari Covid-19 Map : <?php echo tgl_indo(date('Y-m-d'))?>'
      });


      var myOptions = {
        center: new google.maps.LatLng(<?php echo $pemeriksaan_detail[0]->coordinate;?>),
        zoom: 11,
        mapTypeControlOptions: {
          mapTypeIds: [
            'styled_map','satellite'
          ]
        }
      };


      

      var mapCanvas = document.getElementById('map-canvas'); 
      var map = new google.maps.Map(mapCanvas, myOptions);

      
      map.mapTypes.set('styled_map', styledMapType);
      map.setMapTypeId('styled_map');
     
      var infowindow = new google.maps.InfoWindow(), marker, i;
      
      
      for (i = 0; i < markers.length; i++) {  
        pos = new google.maps.LatLng(markers[i][1], markers[i][2]);
        marker = new google.maps.Marker({
            position: pos,
            map: map,
            icon : 'http://maps.google.com/mapfiles/kml/pal5/icon15.png'
        });
        google.maps.event.addListener(marker, 'click', (function(marker, i) {
          return function() {
              infowindow.setContent(markers[i][0]);
              infowindow.open(map, marker);
          }
        })(marker, i));
      }

      var legend = document.getElementById('legend');
      var icons = {
        titik_jalan: {
          name: 'Titik Penyemprotan Jalan',
          icon: 'http://maps.google.com/mapfiles/kml/pal5/icon15.png'
        }

      };
      for (var key in icons) {
        var type = icons[key];
        var name = type.name;
        var icon = type.icon;
        var div = document.createElement('div');
        div.innerHTML = '<img src="' + icon + '"> ' + name;
        legend.appendChild(div);
      }
      map.controls[google.maps.ControlPosition.RIGHT_TOP].push(legend);

      var directionsService = new google.maps.DirectionsService();
      var directionsDisplay = new google.maps.DirectionsRenderer({map: map, suppressMarkers: true});
      directionsDisplay.setMap(map);

      <?php for($ii=0;$ii<(count($pemeriksaan_detail)-1);$ii++){?>

        var directionsService<?php echo $ii?> = new google.maps.DirectionsService();
        var directionsDisplay<?php echo $ii?> = new google.maps.DirectionsRenderer({map: map, suppressMarkers: true});
        directionsDisplay<?php echo $ii?>.setMap(map);

      var request<?php echo $ii?> = {

      origin: '<?php echo $pemeriksaan_detail[$ii]->coordinate?>', 

      destination: '<?php echo $pemeriksaan_detail[($ii+1)]->coordinate?>',

      travelMode: google.maps.DirectionsTravelMode.DRIVING

      };



      directionsService<?php echo $ii?>.route(request<?php echo $ii?>, function(response, status) {

      if (status == google.maps.DirectionsStatus.OK) {

        directionsDisplay<?php echo $ii?>.setDirections(response);

      }

      });

    <?php }?>

    }
     
     
    google.maps.event.addDomListener(window, 'load');
    
  </script>

  <script src="<?php echo base_url();?>assets/new-front/js/jquery.min.js"></script>
  <script src="<?php echo base_url();?>assets/new-front/js/bootstrap.min.js"></script>
 

  
</head>

<body onload="initializeMap()">
    
  <div class="containers">
    <div>
      <div id="map-canvas">
        
      </div>
      <div id="legend"><h3><center><b>LEGENDA</b></center></h3><hr></div>
    </div>
  </div>
  
  <a href="<?php echo site_url('front/peta_penyemprotan_jalan');?>" id="over_map" class="btn btn-icon btn-red" style="margin-left: 0px;margin-top: 50px"><span> Kembali ke Data Jalan</span></a>

  <img src="<?php echo base_url();?>upload/spraying/road/<?php echo $pemeriksaan[0]->spraying_road_photo?>" height="200" id="over_map_img" >

  <div class="footer navbar-fixed-bottom">
    <div class="panel-group bottom0" id="accordion" role="tablist" aria-multiselectable="true">
      <div class="panel panel-primary">
        <div class="panel-heading" role="tab" id="headingOne" style="cursor: pointer" data-toggle="collapse"
          data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          <h4 class="panel-title">
            <i class="fa fa-info"></i>&nbsp;&nbsp;Titik Penyemprotan Jalan di : <?php echo $pemeriksaan[0]->spraying_road_location;?>
          </h4>
        </div>
        <div id="collapseOne" class="panel-collapse collapse notifications-scroll-area" role="tabpanel"
          aria-labelledby="headingOne">
          <div class="panel-body ">
            

            <!--  -->
            <div class="tabs-framed tabs-small boxed">
              <ul class="tabs clearfix">
                  <li class="active"><a href="#tabel" data-toggle="tab">Data Tabel</a></li>
                  <li><a href="#grafik" data-toggle="tab">Data Grafik</a></li>
              </ul>

              <div class="tab-content">
                
                <div class="tab-pane fade in active" id="tabel">
                  <div class="price-item style4">
                    <div class="price-content clearfix">
                        
                      <table class="table table-striped table-bordered table-hover table-condensed">
                        <thead>
                          <tr>
                            <th>No</th>
                            <th>Nama Titik Penyemprotan</th>
                            <th>Kordinat</th>
                            
                          </tr>
                        
                        </thead>
                        <tbody>
                          <?php $no=1; foreach($pemeriksaan_detail as $pdx){?>
                          <tr>
                            <td><?php echo $no;?></td>
                            <td><?php echo $pdx->coordinate_name;?></td>
                            <td><?php echo $pdx->coordinate;?></td>
                          </tr>
                          <?php $no++;}?>

                        </tbody>
                      </table>
                    </div>
                    
                  </div>
                </div>

                <div class="tab-pane fade" id="grafik">
                  <div class="price-item style4">
                    <div class="price-content clearfix">
                      
                      Tidak Ada Grafik
                    </div>
                    
                  </div>
                </div>

                  
 
              </div>
          </div>
          <!--/ Tabs -->
          </div>
        </div>
      </div>
    </div>
  </div>


  

</body>

</html>